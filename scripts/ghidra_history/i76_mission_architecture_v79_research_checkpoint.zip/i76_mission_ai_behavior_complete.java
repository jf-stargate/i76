// @category I76
// Read-only full AI behavior state table export with separate selection/exit/transition channels.
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.Function;
import java.io.*;
import java.util.Locale;

public class i76_mission_ai_behavior_complete extends GhidraScript {
  private static final long BASE=0x004C3E50L, STRIDE=0x1354L;
  private static String hex(long v){return String.format(Locale.ROOT,"%08X",v&0xffffffffL);}
  private long u32(long a) throws Exception{return Integer.toUnsignedLong(currentProgram.getMemory().getInt(toAddr(a)));}
  private String fn(long a){if(a==0)return "NULL";Function f=currentProgram.getFunctionManager().getFunctionAt(toAddr(a));return f==null?"UNDEFINED":f.getName();}
  private static String clean(String s){return s.replace('\t',' ').replace('\r',' ').replace('\n',' ');}
  private void emit(PrintWriter o,int state,long b,String kind,int slot,long address,long value,String target,String note){o.printf(Locale.ROOT,"%d\t%s\t%s\t%d\t%s\t%s\t%s\t%s%n",state,hex(b),kind,slot,hex(address),hex(value),clean(target),clean(note));}
  @Override public void run() throws Exception {
    String[] args=getScriptArgs(); if(args.length<1)throw new IllegalArgumentException("output required");
    if(!"a640ea0097dbb62e0c77b7f2847c7161".equalsIgnoreCase(currentProgram.getExecutableMD5()))throw new IllegalStateException("Unexpected program MD5");
    try(PrintWriter o=new PrintWriter(new File(args[0]),"UTF-8")){
      o.println("state\tbase\tkind\tslot\taddress\tvalue\tfunction_or_target\tnote");
      for(int i=0;i<34;i++){
        long b=BASE+STRIDE*i;
        if(u32(b)!=i)throw new IllegalStateException("state index mismatch at "+hex(b)+": "+u32(b));
        long u=u32(b+4),e=u32(b+8);
        emit(o,i,b,"update",0,b+4,u,fn(u),"");
        emit(o,i,b,"on_enter",0,b+8,e,fn(e),"");
        int sc=(int)u32(b+0x0c),tc=(int)u32(b+0x38),ec=(int)u32(b+0x8c);
        if(sc<0||sc>10||tc<0||tc>10||ec<0||ec>10)throw new IllegalStateException("Invalid counts at "+i+": "+sc+"/"+tc+"/"+ec);
        emit(o,i,b,"selector_count",0,b+0xc,sc,Integer.toString(sc),"candidate precondition count, contiguous 4-byte pointers");
        for(int j=0;j<sc;j++){long a=b+0x10+4*j,v=u32(a);emit(o,i,b,"selector_predicate",j,a,v,fn(v),"all selected candidate predicates must return nonzero");}
        emit(o,i,b,"transition_count",0,b+0x38,tc,Integer.toString(tc),"8-byte pairs, first successful condition selects transition");
        for(int j=0;j<tc;j++){
          long a=b+0x3c+8*j,v=u32(a),target=u32(a+4);
          emit(o,i,b,"transition_predicate",j,a,v,fn(v),"target state "+target);
          emit(o,i,b,"transition_target",j,a+4,target,Long.toString(target),"first matching transition");
        }
        emit(o,i,b,"exit_trigger_count",0,b+0x8c,ec,Integer.toString(ec),"0x1D8-stride triggers; first nonzero initiates exit");
        for(int j=0;j<ec;j++){long a=b+0x90+0x1d8L*j,v=u32(a);emit(o,i,b,"exit_trigger",j,a,v,fn(v),"first nonzero exit trigger");}
      }
      emit(o,34,BASE+STRIDE*34,"first_nonrecord_probe",0,BASE+STRIDE*34,u32(BASE+STRIDE*34),"NOT_SEQUENCE_ID","first word is not 34; next data region");
    }
    println("I76_MISSION_AI_FULL_TABLE_OK "+args[0]);
  }
}
