# v79 — complete AI behavior table and mission-event arbitration boundary

**Evidence:** Ghidra 12.1.4 headless processing the user-supplied `i76.exe(1).gzf` in read-only mode, established semantic symbols, and the original retail PE (MD5 `a640ea0097dbb62e0c77b7f2847c7161`). Date: 2026-10-20. Reproducible scripts: `i76_mission_behavior_table_scope.java`, `i76_mission_ai_behavior_complete.java`, `i76_mission_missing_predicate_probe.java`. Source outputs: `v79_behavior_rows.tsv`, `v79_full_ai_behaviors.tsv`, `v79_predicate_evaluators.txt`, `v79_undefined_predicates.txt`.

## Finding 1. The full state table has 34 records, not 12 (high confidence)

Ghidra recovered contiguous 0-based records `0..33` beginning at VA `004C3E50`, each exactly `0x1354` bytes apart. The 34th index (`33`) starts at `004EBC24` and has the expected record ID and valid update/on-enter function pointers. The next putative row base (`004ECF78`) begins with `6F6C6672`, **not** ID `34`; its adjacent words decode as non-pointer data. All 101 enumerated explicit transition targets are within `0..33`. These three cross-checks jointly provide high confidence in the table boundary.

The v78 script sampled the first **12** records and its 7 `clsnDmg` predicate entries in that subset were correct. The table is actually 34 states. Only seven of the **51 exit-trigger pointers** in all 34 states point to `0041C2C0`, and those occur in states 1, 3, 4, 5, 6, 8, and 9. Do not read `7/12` as a statement about the complete table.

Observed record offsets, relative to row `004C3E50 + index*0x1354`:

| Offset | Role | Scope |
|---|---|---|
| `+0x00` | Row ID | Consecutive `0..33` |
| `+0x04` | Per-state update callback | Executed by `00412830` |
| `+0x08` | State-enter callback | Optional; invoked on state entry |
| `+0x0C` / `+0x10` | Selection/precondition count and contiguous 4-byte predicate pointers | 30 pointers in 34 records |
| `+0x38` / `+0x3C` | Transition count and 8-byte `{predicate pointer, target ID}` entries | 101 condition/target pairs |
| `+0x8C` / `+0x90` | Exit-trigger count and 0x1D8-stride trigger-pointer entries | 51 slots, including one NULL initial-state placeholder |

The row pointer/target file is exhaustive **for this 34-row static table**, not for all possible gameplay callback tables or all callbacks made by each referenced function.

## Finding 2. Three distinct predicate semantics (machine-code supported, high confidence)

Decompilation of `00412680` (`compute_fsm_aggression_sum`) and `00412830` (`update_vehicle_ai_target_and_attack_state`) demonstrates three separate control channels. Preserve the distinction in mission-runtime semantics:

- **Weighted candidate selection:** `00412680` weights and randomly picks candidates; for a selected candidate, contiguous `+0x10` predicates must **all return nonzero** to accept it. The first zero rejects that candidate and the routine may try another. This is not the same list as event-driven exit triggers. The routine may return fallback state ID `0x0F` when none qualifies; see control flow for the cap on attempts.
- **Current-state exit triggers:** `00412830` reads `+0x8C` count and `+0x90`, advances by `0x1D8`, and continues *while the callback returns zero*. A nonzero exit-trigger result takes the state-exit/reselection path; priority is the first satisfied slot in array order. This channel contains the seven non-consuming `clsnDmg` current-epoch checks (`0041C2C0`).
- **Conditional transitions:** `00412830` reads `+0x38` count and `+0x3C` pairs, advances by eight bytes, and tests in table order until the first callback returns nonzero. Its paired target ID is pushed as a nested state, invoking that state's entry/update callbacks, subject to the observed stack-depth condition (`AI+A93C < 0x31`). Thus the transition table is first-match, not a weighted lottery.

The difference is consequential for event arbitration: the AI non-consuming `clsnDmg` predicate is in the exit-trigger channel, whereas FSM host predicates such as `isRammed` (`0040B800`) **clear** their corresponding event marker upon success. An AI check after FSM consumption would not see that marker. Cross-system ordering in a particular running mission remains a **conditional inference**, not an observed dynamic trace.

## Finding 3. Two indirect callback entry points need function-boundary repairs

The 30 candidate-selection predicate pointers contain seven uses of addresses at which the user's Ghidra program has **no defined function start or containing function**:

- `00417500` — five data-table references from the AI behavior list. Ghidra disassembles instructions at that exact address ending in `RET` at `0041750D`; it calls `00458A90` with one argument. Strong candidate for a separately defined short function.
- `00417060` — two data-table references, with a valid multi-instruction disassembly and internal branches. Appears to be a longer function requiring an explicit ownership/boundary review.

These are function-model gaps, not evidence that the bytes are invalid or that the callbacks cannot execute. The code was **not** renamed or defined in the user's project; investigate them in a copy before applying repairs.

## Finding 4. Behavior states exceed the v78 combat-only subset

Records 17–30 contain numerous path-seeking, A* pathfinding and driving/turnaround callbacks, alongside combat behavior in earlier records. Records 31–33 have `fsm_make_vehicle_sit` as their update callback. Consequently an FSM command can select AI state IDs that cross mission-script boundaries into navigation, pursuit, or scripted stopping. Mission research should document those interfaces without attempting to reverse every navigation implementation before their mission-visible contracts are understood.

## Interpretation limits / next questions

No state-transition probability or actual state visitation was measured. Numeric target IDs are table indices, but which transitions execute in any given game frame depends on callbacks, AI object state, and runtime ordering. The two undefined-function-start candidates require boundary resolution. The `AI+A6E4/E8/EC` last-damage-source pointers still require lifetime analysis across unregistration and refcount release. The full FSM host command API requires a side-effect and callback lifecycle inventory; *that*, not speculative AI implementation, is the immediate mission-execution goal.

## Static validation summary

See `v79_structural_validation.json`. Findings validated: 34 contiguous IDs, table termination probe, 101 in-range targets, 30 selection predicates, 51 exit triggers, seven `0041C2C0` exit callbacks, and two distinct disassembled-but-undefined predicate targets. Static checks were run after successful Ghidra headless execution; these do not constitute gameplay behavioral tests.
