// @category I76
// Read only lookups of two pointer-table entries that are not defined function starts.
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.address.Address;
import ghidra.program.model.symbol.Reference;
import java.io.*;
public class i76_mission_missing_predicate_probe extends GhidraScript {
  @Override public void run() throws Exception {
    String[] a=getScriptArgs(); if(a.length<1) throw new IllegalArgumentException("out required");
    try(PrintWriter w=new PrintWriter(new File(a[0]),"UTF-8")){
      for(String sa:new String[]{"00417060","00417500"}){
        Address addr=toAddr(sa);
        Function here=currentProgram.getFunctionManager().getFunctionAt(addr);
        Function containing=currentProgram.getFunctionManager().getFunctionContaining(addr);
        w.println("=== "+sa+" start="+(here==null?"NONE":here.getName())+" containing="+(containing==null?"NONE":containing.getName()+" @"+containing.getEntryPoint())+" ===");
        Instruction inst=currentProgram.getListing().getInstructionAt(addr);
        for(int i=0;i<26 && inst!=null;i++){
          w.println(inst.getAddress()+" "+inst.toString());
          inst=inst.getNext();
        }
        w.println("Refs to address:");
        for(Reference r:currentProgram.getReferenceManager().getReferencesTo(addr))w.println("from="+r.getFromAddress()+" type="+r.getReferenceType());
      }
    }
  }
}
