// I76 mission architecture - read-only Ghidra table-boundary and predicate evaluator audit
// @category I76
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileResults;
import ghidra.program.model.listing.Function;
import ghidra.program.model.address.Address;
import ghidra.program.model.mem.Memory;
import java.io.*;
import java.util.Locale;

public class i76_mission_behavior_table_scope extends GhidraScript {
  private static final long BASE=0x004C3E50L, STRIDE=0x1354L;
  private static String h(long v){return String.format(Locale.ROOT,"%08X",v&0xffffffffL);}
  private int r32(long va) throws Exception {return currentProgram.getMemory().getInt(toAddr(va));}
  private String name(long addr){
    if(addr==0)return "NULL";
    Function f=currentProgram.getFunctionManager().getFunctionAt(toAddr(addr));
    return f==null?"?":f.getName();
  }
  @Override public void run() throws Exception {
    String[] args=getScriptArgs();
    if(args.length<1)throw new IllegalArgumentException("output basename required");
    String out=args[0];
    String md5=currentProgram.getExecutableMD5();
    if(!"a640ea0097dbb62e0c77b7f2847c7161".equalsIgnoreCase(md5))throw new IllegalStateException("Unexpected executable: "+md5);
    try(PrintWriter w=new PrintWriter(new File(out+"_behavior_rows.tsv"), "UTF-8")){
      w.println("index\tbase\trow_id\tupdate_ptr\tupdate_name\tentry_ptr\tentry_name\tselector_pred_count\ttransition_count\texit_pred_count\texit_pred0\texit_pred0_name\ttransition0_target\ttransition0_test\ttransition0_test_name");
      for(int i=0;i<46;i++){
        long b=BASE+STRIDE*i;
        try{
          long id=Integer.toUnsignedLong(r32(b));
          long update=Integer.toUnsignedLong(r32(b+4));
          long enter=Integer.toUnsignedLong(r32(b+8));
          int sCount=r32(b+0xC);
          int transitions=r32(b+0x38);
          int exitCount=r32(b+0x8C);
          long exit0=Integer.toUnsignedLong(r32(b+0x90));
          long trans0=Integer.toUnsignedLong(r32(b+0x3C));
          int transTarget=r32(b+0x40);
          w.printf(Locale.ROOT,"%d\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%d\t%d\t%s\t%s\t%d\t%s\t%s%n",i,h(b),h(id),h(update),name(update),h(enter),name(enter),sCount,transitions,exitCount,h(exit0),name(exit0),transTarget,h(trans0),name(trans0));
        }catch(Exception e){w.printf("%d\t%s\tERROR %s%n",i,h(b),e.getMessage());}
      }
    }
    try(PrintWriter w=new PrintWriter(new File(out+"_predicate_evaluators.txt"), "UTF-8")){
      DecompInterface di=new DecompInterface();
      if(!di.openProgram(currentProgram))throw new IllegalStateException("Decompiler unavailable");
      for(String a: new String[]{"00412680","00412830","0041C2C0","0040B800","0040B990","0040AFF0","00409980"}) {
        Function f=currentProgram.getFunctionManager().getFunctionAt(toAddr(a));
        w.println("======== "+a+" "+(f==null?"NOT DEFINED":f.getName())+" ========");
        if(f!=null){
          DecompileResults d=di.decompileFunction(f,80,monitor);
          if(d.decompileCompleted()&&d.getDecompiledFunction()!=null)w.println(d.getDecompiledFunction().getC());
          else w.println("DECOMP_ERROR "+d.getErrorMessage());
        }
      }
      di.dispose();
    }
    println("I76_MISSION_TABLE_SCOPE_OK: "+out);
  }
}
