# Interstate '76 — Mission Execution Architecture Research Charter

**Research phase:** Reverse engineering only. **Target:** retail `i76.exe` (`a640ea0097dbb62e0c77b7f2847c7161` MD5), existing imported Ghidra program `i76.exe(1)`. **Date:** 2026-10-20. **Tooling:** Ghidra 12.1.4 headless plus independent PE/x86 analysis; existing symbol names, data types, and comments as the default semantic baseline.

## Objective

Establish the highest reasonable evidence-based confidence in how the original engine loads, schedules, executes, and resolves mission scripts, including interactions with world objects, AI behavior, vehicle damage, timers, objective state, and game modes. **Do not create a replacement runtime or embark on reconstruction/reimplementation as part of this phase.** Focus validation on discerning original behavior and producing testable contracts for the later reconstruction phase.

## Research workstreams

1. **Mission load/initialization:** BWD2 FSM serialization, table allocation, command prototype resolution, object identity binding, initial execution-node creation, relocation, teardown/reset paths, and error handling.
2. **Token VM and scheduler:** complete token kind semantics, operand/frame conventions, branch/yield/return behavior, scheduling and node lifetime, task ordering, potential dynamic creation, execution budgets, and fault behavior.
3. **Host-command ABI and contracts:** all 96 command IDs with argument types, return/result semantics, side effects, downstream call chains, synchronous/asynchronous behavior, and which states they change.
4. **World-object identity and lifetime:** mission actor rows, dynamic `NoLabel` entries, registration/unregistration callbacks, refcounts, reference invalidation, dangling source-pointer potential, and rebind behavior.
5. **Events and AI boundary:** physical ingress into event ledger, current/previous epoch predicates and consumption, AI behavior table/transition arbitration, objective/vehicle action integration, and inter-node contention.
6. **Frame/time/mode integration:** ordering within the game loop, variable vs fixed-step segments, timers, suspension/mode gates, scripted objective transitions, and callbacks from audio/media/animation services where mission-visible.

Engine subsystems such as navigation, drivetrain, rendering, and networking are **dependencies**, not independent diversionary objectives; inspect as deeply as necessary to establish mission-visible contracts, defer other internals.

## Confidence and provenance standard

- **Executable-verified:** directly supported by particular machine-code instructions and/or bytes, with virtual addresses, control-flow gates, and original PE identity.
- **Ghidra corroborated:** confirmed in the latest imported user's program with names, function boundaries, data table reads, and decompilation; explicitly distinguish a decompiler reconstruction from the instructions.
- **Behaviorally validated:** observed via controlled execution, target-side instrumentation, or independently tested deterministic traces. State exact test scope. Static assertions alone do not confer this status.
- **Inferred:** logical consequence of known rules, but dependent on a runtime ordering, pointer-lifetime, or world-state assumption; explicitly mark the assumption.
- **Unknown:** insufficient evidence; enumerate what would falsify leading explanations.

All findings should distinguish the base retail binary from AIO or other patched variants. Protect the authoritative user's Ghidra database; Ghidra headless research scripts run `-readOnly -noanalysis` by default. Any experimental function creation or renames must be in an isolated analysis copy, with a separate list of proposed canonical project changes.

## Acceptance criteria

Before calling the mission-execution architecture substantially reversed, require: a complete loader/VM/scheduler/object-lifetime path; every mission-visible host command classified by observable state changes and error paths; indirect callback tables bounded and enumerated; event epochs, consumption order, and source lifetime traced; mission-relevant frame and timer order stated with branch guards; test vectors demonstrating corner cases; and an explicit bounded unresolved-risk register. Absolute certainty or full engine emulation are not acceptance requirements. Avoid overstating incomplete whole-engine coverage.

## Validation design (not reimplementation)

Build address-anchored static regression checks (record sizes, table boundaries, pointers, case counts, function ownership), plus behavioral experiment plans for: two yielding nodes in one traversal; consuming predicates racing for a single event; current/previous epoch visibility; appending `NoLabel` actor records and releasing their references; removing a source before a later query; AI state selection and transition priority; mode and timer-dependent suspension; and mission objective completion/failure.

The later reconstruction pipeline will use these contracts to construct unit/functional tests; those future implementations are out of scope here.

## Initial autonomous checkpoint

See `V79_AI_BEHAVIOR_TABLE_FINDINGS.md` and `v79_full_ai_behaviors.tsv`. A full Ghidra `-readOnly` audit on 2026-10-20 established 34 consecutively indexed behavior states, rather than the previous 12-row v78 sample; recovered all indexed pointers and conditions; and identified two live pointer-table targets at `00417060` and `00417500` that lack Ghidra function boundaries. Next research should first resolve those boundaries and trace source-reference invalidation and the three distinct predicate channels.
