# I76 — original retail BWD2 parser emulator (v0.5.0)

Read `ORIGINAL_CODE_EMULATION_REPORT.md` for methods, results, caveats, and reproduction commands.

This checkpoint executes original `i76.exe` x86 machine instructions via Ghidra's instruction emulator. It does not execute the game in Windows. **Only three imported C runtime functions are stubbed; no parser or revision-callback machine code is replaced.**

Input is the original BWD2/REV 20-byte header, verified against shipped `miss8/M06.MSN`. Variations exist only in emulated memory. Five test pairs exercise repeated calls on the **same emulator memory instance**.

Principal result: original parser cold REV-only root returns null; warm REV-only root after a valid BWD2 parse returns non-null. Even a previous parse rejected for wrong REV leaves the BWD2 seen bit set.

Run `python3 tools/validate_results.py --results results` to verify the saved traces without installing Ghidra. Source and a reproducible Ghidra headless command are provided in the full report.
