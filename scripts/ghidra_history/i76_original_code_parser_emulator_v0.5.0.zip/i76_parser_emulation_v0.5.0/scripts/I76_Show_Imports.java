import ghidra.app.script.GhidraScript;
import ghidra.app.emulator.EmulatorHelper;
public class I76_Show_Imports extends GhidraScript {
 @Override public void run() throws Exception {
  EmulatorHelper e=new EmulatorHelper(currentProgram);
  try {
   for(long x:new long[]{0x4bc28cL,0x4bc238L,0x4bc210L}){
    byte[] b=e.readMemory(toAddr(x),4);long v=(b[0]&255L)|((b[1]&255L)<<8)|((b[2]&255L)<<16)|((b[3]&255L)<<24);
    println(String.format("IMPORT %08X %08X",x,v));
   }
   for(long x : new long[]{0x5003b8L,0x5003c0L,0x5003c8L,0x5003d0L,0x5003d8L,0x5003e0L}){
    byte[] b=e.readMemory(toAddr(x),8);StringBuilder s=new StringBuilder();for(byte c:b)s.append(String.format("%02X ",c&255));println(String.format("TBL %08X %s",x,s.toString()));
   }
  }finally{e.dispose();}
 }
}
