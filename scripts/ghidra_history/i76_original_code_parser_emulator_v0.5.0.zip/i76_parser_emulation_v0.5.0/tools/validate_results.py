#!/usr/bin/env python3
"""Independently check the original-code emulator's captured TSV output.
Run python tools/validate_results.py --results results [--game-tar /path/to/i76_base.tar]
"""
import argparse, csv, hashlib, io, json, pathlib, tarfile

EXPECTED = {
    "C01_stock_cold": ("20000014", "00000044", "000000C4"),
    "C02_missing_cold": ("NULL", "00000044", "00000044"),
    "C03_missing_warm": ("2000000C", "000000C4", "000000C4"),
    "C04_stock_warm": ("20000014", "000000C4", "000000C4"),
    "C05_rev_rejected": ("NULL", "00000044", "000000C4"),
    "C06a_session1_stock": ("20000014", "00000044", "000000C4"),
    "C06b_session1_missing": ("2000000C", "000000C4", "000000C4"),
    "C07a_session2_missing": ("NULL", "00000044", "00000044"),
    "C07b_session2_stock": ("20000014", "00000044", "000000C4"),
    "C08a_session3_stock": ("20000014", "00000044", "000000C4"),
    "C08b_session3_rev_reject": ("NULL", "000000C4", "000000C4"),
    "C09a_session4_bad_rev": ("NULL", "00000044", "000000C4"),
    "C09b_session4_missing": ("2000000C", "000000C4", "000000C4"),
    "C10a_session5_missing_bad_rev": ("NULL", "00000044", "00000044"),
    "C10b_session5_missing_valid_rev": ("NULL", "00000044", "00000044"),
}

HEADER = bytes.fromhex('42 57 44 32 08 00 00 00 52 45 56 00 0c 00 00 00 02 00 00 00')

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--results',type=pathlib.Path,default=pathlib.Path(__file__).parent.parent/'results')
    parser.add_argument('--game-tar',type=pathlib.Path)
    parser.add_argument('--output',type=pathlib.Path)
    args=parser.parse_args()
    checks=[]
    def check(label, condition):
        checks.append({'id':label,'passed':bool(condition)})
    with (args.results/'emulation_outcomes.tsv').open() as f:
        rows=list(csv.DictReader(f,delimiter='\t'))
    by={x['scenario']:x for x in rows}
    check('exact_case_set',set(by)==set(EXPECTED) and len(rows)==len(EXPECTED))
    for case,(ret,before,after) in EXPECTED.items():
        r=by.get(case,{})
        check('return_'+case,r.get('returned')=='true' and r.get('eax_or_failure')==ret)
        check('flags_'+case,r.get('bwd_flags_before')==before and r.get('bwd_flags_after')==after)
        check('native_revision_callback_'+case,r.get('native_rev_callbacks_entered')=='1')
        check('external_crt_only_'+case,int(r.get('external_crt_calls_stubbed','0'))>=2)
    with (args.results/'instruction_events.tsv').open() as f:
        events=list(csv.DictReader(f,delimiter='\t'))
    def seen(name, event):return any(r['scenario']==name and r['type']==event for r in events)
    check('native_required_failure_branch',seen('C02_missing_cold','required_error') and seen('C07a_session2_missing','required_error'))
    check('warm_skips_required_failure',not seen('C06b_session1_missing','required_error') and not seen('C09b_session4_missing','required_error'))
    check('original_seen_store',seen('C06a_session1_stock','seen_store') and seen('C09a_session4_bad_rev','seen_store'))
    check('CRT_isolated_splitpath',seen('C01_stock_cold','CRT_splitpath_stub'))
    check('CRT_isolated_stricmp',seen('C01_stock_cold','CRT_stricmp_stub'))
    if args.game_tar:
        with tarfile.open(args.game_tar) as archive:
            exe=archive.extractfile('interstate 76/i76.exe').read()
            mission=archive.extractfile('interstate 76/miss8/M06.MSN').read()
        check('retail_exe_md5',hashlib.md5(exe).hexdigest()=='a640ea0097dbb62e0c77b7f2847c7161')
        check('stock_mission_header_match',mission[:20]==HEADER)
    summary={'passed':sum(c['passed'] for c in checks),'total':len(checks),'all_passed':all(c['passed'] for c in checks),'checks':checks,'scope':'Ghidra 12.1.4 original retail x86 parser with external CRT stubs; not full-game Windows execution'}
    target=args.output or args.results/'validation.json'
    target.write_text(json.dumps(summary,indent=2)+'\n')
    print(f"{summary['passed']}/{summary['total']} checks passed; {target}")
    if not summary['all_passed']:
        print('Failures:',[c['id'] for c in checks if not c['passed']]);raise SystemExit(1)

if __name__=='__main__': main()
