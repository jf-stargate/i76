# I76 mission architecture v80 — autonomous local Ghidra checkpoint

The phase remains **reverse engineering only**, not game-runtime reconstruction. Retail target: MD5 `a640ea0097dbb62e0c77b7f2847c7161`, native Ghidra 12.1.4 and imported user `i76.exe(1).gzf`.

## Highlights

- Defined two previously unidentified AI selection callback boundaries in a **disposable scratch project only**. `00417500..0041750D` calls the class eligibility check; `00417060..004170BF` tests horizontal separation `<80.0f` and current integrity `<30 + 17*tactics`. The byte-level thresholds are independently verified from the original retail PE.
- Scanned 232,525 decoded instructions for nine AI state displacements. The three damage-source slots have six direct write instructions across constructor and event recorder. Unregister has none of those direct displacement writes; whether alternative ownership protects stale pointers remains unknown.
- Reconciled the 96-ID source-command resolver to 95 explicit dispatcher cases. Command ID `0x16` `playScene` resolves but lacks a runtime case and follows the default error/abort path in retail.
- The v79 34-state AI behavior table and three separate predicate semantics remain the larger established baseline.

## Contents

- `V80_MISSION_EVENT_AI_AND_HOST_FINDINGS.md` — main evidence-based report, limitations and test design.
- `v80_mission_host_commands.tsv` — all 96 IDs with source names, handler presence, best-effort named call extraction.
- `v80_whole_program_event_fields.tsv` — 56 matched literal AI field offsets, instruction bytes and ownership.
- `v80_callback_boundaries.txt` — local disassembly and canonical function neighbor evidence.
- `v80_missing_callbacks_decompiled.txt` — native Ghidra scratch decompilation of both newly defined functions plus cached horizontal separation helper.
- `v80_selected_decomp.txt` + `.missing_asm.txt` — selected native Ghidra read-only decompilations and raw missing-function instructions.
- `v80_scan_summary.txt`, `v80_static_validation.json` — audit and static regression outcomes.
- `v80_baseline_function_state.txt`, `v80_scratch_function_state.txt` — proves baseline undefined and scratch defined (not the same underlying project).
- `i76_mission_v80_boundary_lifetime.java`, `i76_mission_v80_deep_functions.java` — read-only headless scripts.
- `i76_mission_v80_scratch_define.java` — **mutating**, permitted **only** on a disposable imported GZF scratch project.
- `i76_mission_v80_static_validation.py` — independent retail-PE / Ghidra evidence assertions. Requires an original matching retail `i76.exe` at `binary/i76.exe`; the executable is not redistributed in this research ZIP. Adjust path if running elsewhere.
- `v80_manifest.json` — SHA-256 hash manifest for packaged files.

## Headless usage

```bash
GHIDRA=/path/to/ghidra_12.1.4_PUBLIC
PROJECT_ROOT=/path/to/ghidra_projects
OUTPUT=/path/to/output

"$GHIDRA/support/analyzeHeadless" "$PROJECT_ROOT" i76_autonomous_test \
  -process 'i76.exe(1)' -readOnly -noanalysis \
  -postScript i76_mission_v80_boundary_lifetime.java "$OUTPUT" \
  -scriptPath /path/to/scripts
```

Read-only baseline used in this session: `/mnt/data/i76_headless_env/projects/i76_autonomous_test`. Disposable modified project: `/mnt/data/i76_headless_env/projects/i76_mission_scratch`. The source GZF and the user's canonical project were never modified.

**Validation scope:** native decompilation and static executable checks succeeded. No original-game behavioral execution took place. Names for scratch functions are proposed and may be refined. Do not infer runtime safety from absence of direct memory writes.
