# I76 v80 — Mission event arbitration, AI callback repair, and host-command coverage

Date: 2026-10-20. **Phase: research and reverse engineering only; no replacement runtime written.**

## Provenance and scope

The user-supplied `i76.exe(1).gzf` was imported with Ghidra 12.1.4 into an isolated project. Read-only headless scripts ran against its preserved function names, symbols and decompiler annotations. A second **disposable scratch import** was created to define and decompile two previously unowned callback entry points; the imported baseline and the user's original project were not edited. All addresses are retail PE virtual addresses with image base `00400000`. An independent copy extracted from the user's retail game TAR matches MD5 `a640ea0097dbb62e0c77b7f2847c7161`. All observations are **static and executable-backed**, not live gameplay tests.

## 1. Two v79 missing AI callback functions are independently bounded

### `00417500–0041750D`: target class eligibility selector (high confidence)

The contiguous code at `00417500` consists of: load the second callback parameter from `[ESP+8]`; push it; call `00458A90`; adjust stack; `RET` at `0041750D`. Function `00458A90` returns true precisely for non-null world objects whose class ID (`object+0x6C`) equals 1, 8, or 9. The wrapper leaves that integer return value in EAX. Ghidra's scratch decompiler rendered the wrapper with a `void` signature, but the **machine-code calling convention and use as a selector predicate support returning the callee's EAX boolean**. There are five selector-table uses (states 1, 2, 3, 4, 5).

A nearby, existing Ghidra function ends at `004174F2`; the following defined function starts at `00417510`. There is no overlap. The unowned bytes form a distinct return-terminated function.

Recommended canonical name (proposal only): `ai_behavior_selector_target_is_vehicle_or_actor`.

### `00417060–004170BF`: near damaged-target selector (high confidence for rule, medium for semantic name)

With exact function boundaries created only in scratch, Ghidra decompiled the predicate as:

```c
// High-level simplification, not a verbatim ABI-typed prototype
return horizontal_distance(vehicle, target) < 80.0f
    && compute_world_object_damage_integrity_percent(vehicle)
         < (30 + 17 * vehicle_ai_state.A818);
```

The true branch is `004170B3–004170BA` and the false return ends at `004170BF`. The raw instructions load the AI state pointer at `object->runtime(+0x70)->(+0x108)`, use integer tactics field `+A818`, compute `17*x+30` using shift/LEA, and compare against the x87 returned integrity percentage. The preceding call `004589F0` delegates to `004687F0`, which returns a **cached horizontal XZ separation** between two world objects. The independent PE bytes at `004BC8BC` decode to `80.0f` (IEEE-754 `00 00 A0 42`).

With the known tactics values `0..4`, the percentage thresholds are 30, 47, 64, 81, and 98. This callback occurs in selector lists for states 2 and 10. Important: the target must be non-null and otherwise valid for the horizontal separation helper; invocation ordering with the `00417500` eligibility predicate is especially relevant for state 2. The strength and meaning of the tactics field in states other than its observed initialization/guard remain an empirical question.

Recommended canonical name (proposal only): `ai_behavior_selector_near_and_below_integrity_threshold`.

**Decompiler prototype caveat:** `004589F0` has a legacy `void` signature but merely tail-delegates to `004687F0`, whose x87 `ST(0)` float result is subsequently consumed by `00417060`; likewise `00417500` preserves EAX despite a `void` inference. These should be treated as prototype/type errors, not executable contradictions. No signature correction was applied to the canonical GZF.

## 2. Whole-program damage source and event-field access audit

A single read-only Ghidra listing traversal enumerated **232,525 instructions**, finding **56 syntactic numeric-displacement references** for the nine targeted offsets: markers `A6D4/D8/DC`, attribution `A6E0`, source pointers `A6E4/E8/EC`, timestamp `A6F0`, and target pointer `A9B4`. The complete 56-row audit is preserved in `v80_whole_program_event_fields.tsv`.

The three source pointer offsets `A6E4/E8/EC` have precisely **six syntactic direct memory stores** among the decoded instructions, all owned by only two functions:

- `00415640` `allocate_initialized_ai_fsm_behavior_state_block` explicitly sets each to NULL (`004156F4/FA`, `00415700`).
- `004157A0` `record_vehicle_damage_source_event` explicitly writes the source object to categorized/last-source slots (`00415836`, `00415849`, `0041585B`) after its guards.

`00409980` unregister callback has **no direct access** to `A6E4/E8/EC` by these displacements. It *does* clear `A9B4` tracked target references and mission-actor `+0x58` bindings. `whoRammed` (`0040AFF0`), `whoShot` (`0040B0F0`) and `whoAttacked` (`0040B1F0`) read their respective source pointer and can bind it into the actor table as a dynamic `NoLabel_<index>` object with a new recursive reference.

**Interpretation:** The source-pointers and the epoch markers are not the same ownership or consumption channel. On the visible code paths, an event marker can be consumed while its last source pointer remains stored. Conversely unregistering a world object does not explicitly erase these source fields. This is strong **negative evidence for direct clearing** but not proof that a pointer becomes dangling: indirect field addressing, block reinitialization, other owner-held references and scene teardown may alter the actual lifetime. This is an unresolved **object-lifetime risk to test**, not a demonstrated exploitable bug.

The timestamp at `A6F0` is additionally read by `00420B30` path following, so the damage ledger can influence AI movement beyond the immediate collision/FSM callback. The AI target pointer `A9B4` is also used outside the main behavior function by radar helper `0045F970`; target release/retarget has multiple observers.

## 3. Mission host command resolver vs. executable dispatcher (high confidence)

The native code at `00410A10` recognizes every opcode `0..95` as a source command name: **96 distinct opcode IDs, with 97 matching branches** because `isArrived` is recognized twice for ID 40. Its textual comparisons are case-sensitive. The independent dispatcher `00412CE0` has **95 explicit switch case IDs**. The one missing case is **ID 22 (`0x16`) `playScene`**. That ID is **recognized by the command-name loader yet falls through to the dispatcher default error/abort path** in this retail build. The v59 corpus examination noted no `playScene` in its 25 nonempty missions; this is consistent with but does not explain the nonimplementation.

Full 96-row opcode ↔ name ↔ native-case ↔ named-direct-callee inventory is `v80_mission_host_commands.tsv`. The callee column is an automated **candidate extraction from Ghidra C output**, not a validated exhaustive indirect call graph or ABI argument specification. Shared switch labels and helper macros may cause some adjacent case blocks to appear empty. This is a coverage inventory, not a complete host-command contract.

Control/ABI anchors:

- `004125C0`: the finalizer converts each loaded `0x54`-byte serialized command record's source name into an opcode at record `+0x50`.
- `00414670`: token VM case `0x0D` calls `00412CE0` with a **source command-record index**, not a direct opcode; the dispatcher indexes `command_base + index * 0x54 + 0x50`.
- `00412CE0`: each executed host command advances the token PC by 8 bytes and resets its operand cursor as observed; some update node boolean result at `+0x10A0`; others manipulate mission actor bindings, AI target/behavior state, timers or mission objectives.
- `004149F0`: pending-node scheduler executes nodes in list order, retains nodes that yield, frees nodes after VM completion. Therefore event-consuming predicates are order-sensitive across nodes.

## 4. Proposed verification tests — design only

These test designs are *not implemented and have no observed outcomes*:

1. Create two FSM nodes both testing `isRammed` for the same vehicle and epoch. Observe first-wins consumption with `A6D8 -> 0xFFFFFFF6` and how yielding affects subsequent node order.
2. Damage a vehicle; read `whoRammed`, then remove the source world object. Determine whether source is still held by a newly appended actor record and whether a **later** `whoRammed` is safe after the actor binding is invalidated.
3. Trigger a `clsnDmg` exit condition in AI while an FSM node also tests and consumes `isRammed`. Verify which callback phase sees the event and whether a next-epoch event behaves differently.
4. Evaluate `00417060` with tactics levels `0..4`, horizontal distances just below/equal/above `80.0`, and integrity immediately below/equal/above `30+17*tactics`. Confirm both comparisons are strict `<`.
5. On a disposable mission script, compare loader resolution of `playScene` and its host dispatcher path; avoid executing this in unsaved production game state. Validate whether the runtime routes `0x16` to an abort or is guarded before dispatch.

## 5. Unresolved questions, prioritized

- **High priority:** aliasing and lifetime of raw `A6E4/E8/EC` source pointers; whether `who*` commands can observe a removed source during scene lifetime, and how missing/null/expired bindings are handled.
- **High priority:** complete per-ID host command argument counts/types, pointer ownership, return flag conventions, and host callback side effects; v80 provides names and structural coverage, **not** those verified contracts.
- **Medium priority:** intended semantics and precision of the cached geometric XZ helper at `004589F0/004687F0`, especially coordinate scales and assumptions under destroyed or missing objects.
- **Medium priority:** initialization/teardown and signal routing across world-object callbacks and mission objective state, including class callback timing relative to `0040A320` and event epoch increment.
- **Medium priority:** v79 AI state callback prototypes and tables as input to classifying script-issued `behave`, `attack`, `goto`, and `sit` commands.

**Status:** v80 native Ghidra scripts ran successfully, scratch functions were created/decompiled, independent retail PE checks passed, and `v80_static_validation.json` reports PASS. No live game execution or behavioral trace was performed; the canonical Ghidra project and original GZF were not modified.
