// @category I76
// EXPERIMENTAL: define two missing functions in disposable scratch project ONLY.
// Never run on the canonical user project.
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.address.*;
import ghidra.program.model.symbol.SourceType;
import java.io.*;
public class i76_mission_v80_scratch_define extends GhidraScript {
  @Override public void run() throws Exception{
    String[] args=getScriptArgs();if(args.length<1)throw new IllegalArgumentException("output required");
    if(!"a640ea0097dbb62e0c77b7f2847c7161".equalsIgnoreCase(currentProgram.getExecutableMD5()))throw new IllegalStateException("Unexpected executable");
    DecompInterface dc=new DecompInterface();if(!dc.openProgram(currentProgram))throw new IllegalStateException("Decompiler failed to start");
    try(PrintWriter w=new PrintWriter(new File(args[0]),"UTF-8")){
      for(String[] triple:new String[][]{{"00417060","004170BF","v80_candidate_ai_geometry_integrity_selector"},{"00417500","0041750D","v80_candidate_ai_target_is_vehicle_or_actor"}}){
        Address start=toAddr(triple[0]),end=toAddr(triple[1]);
        Function f=currentProgram.getFunctionManager().getFunctionAt(start);
        if(f==null){
          f=currentProgram.getFunctionManager().createFunction(triple[2],start,new AddressSet(start,end),SourceType.ANALYSIS);
          if(f==null)throw new IllegalStateException("Create failed "+triple[0]);
        }
        w.println("==== "+triple[0]+".."+triple[1]+" "+f.getName()+" ====");
        DecompileResults r=dc.decompileFunction(f,60,monitor);
        w.println(r.decompileCompleted()?r.getDecompiledFunction().getC():"FAILED "+r.getErrorMessage());
      }
      for(String a:new String[]{"004687F0"}){Function f=currentProgram.getFunctionManager().getFunctionAt(toAddr(a));w.println("=== HELPER "+a+" "+(f==null?"NONE":f.getName())+" ===");if(f!=null){DecompileResults r=dc.decompileFunction(f,60,monitor);w.println(r.decompileCompleted()?r.getDecompiledFunction().getC():"FAILED "+r.getErrorMessage());}}
    }finally{dc.dispose();}
    println("V80_SCRATCH_DECOMPILE_COMPLETE");
  }
}
