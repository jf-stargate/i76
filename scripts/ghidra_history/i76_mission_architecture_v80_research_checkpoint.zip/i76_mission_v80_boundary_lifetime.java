// @category I76
// I76 mission architecture v80: read-only whole-program event-field displacement audit,
// callback entrypoint boundaries, and selected retail assembly windows.
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.symbol.Reference;
import java.io.*;
import java.util.*;
public class i76_mission_v80_boundary_lifetime extends GhidraScript {
  private static final String MD5="a640ea0097dbb62e0c77b7f2847c7161";
  private static final String[] TARGETS={"00417060","00417500"};
  private static final String[] DISPS={"0xa6d4","0xa6d8","0xa6dc","0xa6e0","0xa6e4","0xa6e8","0xa6ec","0xa6f0","0xa9b4"};
  private String name(Address a){Function f=currentProgram.getFunctionManager().getFunctionContaining(a);return f==null?"UNDEFINED":f.getName()+"@"+f.getEntryPoint();}
  private String clean(String s){return s.replace('\t',' ').replace('\n',' ').replace('\r',' ');}
  private String bytes(Instruction ins) throws Exception {byte[] b=ins.getBytes();StringBuilder out=new StringBuilder();for(byte v:b)out.append(String.format("%02X",v&255));return out.toString();}
  private void window(PrintWriter o,String section,long start,int steps) throws Exception{
    o.println("### "+section+" ("+String.format("%08X",start)+")");
    Instruction p=currentProgram.getListing().getInstructionAt(toAddr(start));
    if(p==null){o.println("NO_INSTRUCTION_AT_START");return;}
    for(int i=0;i<steps&&p!=null;i++){o.println(p.getAddress()+"\t"+bytes(p)+"\t"+p.getMnemonicString()+"\t"+clean(p.toString())+"\towner="+name(p.getAddress()));p=p.getNext();}
  }
  @Override public void run() throws Exception{
    String[] args=getScriptArgs();if(args.length<1)throw new IllegalArgumentException("output directory required");
    if(!MD5.equalsIgnoreCase(currentProgram.getExecutableMD5()))throw new IllegalStateException("Retail MD5 mismatch");
    File d=new File(args[0]);d.mkdirs();
    try(PrintWriter w=new PrintWriter(new File(d,"v80_callback_boundaries.txt"),"UTF-8")){
      w.println("I76 retail MD5 "+MD5+" read-only Ghidra 12.1.4");
      for(String v:TARGETS){
        Address a=toAddr(v);Function here=currentProgram.getFunctionManager().getFunctionAt(a);
        Function prev=null,next=null;for(Function f:currentProgram.getFunctionManager().getFunctions(true)){if(f.getEntryPoint().compareTo(a)<0)prev=f;else if(f.getEntryPoint().compareTo(a)>0){next=f;break;}}
        w.println("\n=== "+v+" ===");
        w.println("function_at="+(here==null?"NONE":here.getName()));
        w.println("function_containing="+name(a));
        w.println("function_before="+(prev==null?"NONE":prev.getEntryPoint()+" "+prev.getName()+" body_end="+prev.getBody().getMaxAddress()));
        w.println("function_after="+(next==null?"NONE":next.getEntryPoint()+" "+next.getName()));
        for(Reference r:currentProgram.getReferenceManager().getReferencesTo(a))w.println("xref: "+r.getFromAddress()+" "+r.getReferenceType());
      }
      window(w,"earlier context of 00417060",0x00417030L,80);
      window(w,"earlier context of 00417500",0x004174D0L,55);
      for(long a:new long[]{0x0040aff0L,0x0040b0f0L,0x0040b1f0L,0x004157a0L,0x00409980L}) window(w,"specific event path",a,22);
    }
    Map<String,Integer> counts=new TreeMap<>();int instructions=0,matches=0;
    try(PrintWriter w=new PrintWriter(new File(d,"v80_whole_program_event_fields.tsv"),"UTF-8")){
      w.println("address\towner\tdisplacement\tbytes\tassembly\toperation\tassessment");
      for(Instruction p:currentProgram.getListing().getInstructions(true)){
        instructions++;
        String a=p.toString().toLowerCase(Locale.ROOT);
        for(String dis:DISPS)if(a.contains(dis)){
          String operation=p.getMnemonicString().toUpperCase(Locale.ROOT);
          String assessment=operation.equals("MOV")?"inspect destination register/memory to classify read versus write":"requires operand/dataflow review";
          w.println(p.getAddress()+"\t"+name(p.getAddress())+"\t"+dis+"\t"+bytes(p)+"\t"+clean(p.toString())+"\t"+operation+"\t"+assessment);
          counts.put(dis,counts.getOrDefault(dis,0)+1);matches++;
        }
      }
    }
    try(PrintWriter w=new PrintWriter(new File(d,"v80_scan_summary.txt"),"UTF-8")){
      w.println("Retail PE MD5="+MD5);w.println("Instructions_scanned="+instructions);w.println("displacement_matches="+matches);
      for(Map.Entry<String,Integer> e:counts.entrySet())w.println(e.getKey()+"="+e.getValue());
      w.println("NOTE: numeric displacement scan is NOT a proof of AI base register; independently inspect register provenance.");
    }
    println("V80_BOUNDARY_LIFETIME_OK instructions="+instructions+" matches="+matches);
  }
}
