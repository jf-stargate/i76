#!/usr/bin/env python3
"""Retail-PE-backed static verification and resolver/dispatcher comparison, not gameplay tests."""
from pathlib import Path
import csv, hashlib, json, re, struct
P=Path(__file__).resolve().parent
PE=(P/'binary/i76.exe').read_bytes(); MD5='a640ea0097dbb62e0c77b7f2847c7161'
assert hashlib.md5(PE).hexdigest()==MD5
peofs=struct.unpack_from('<I',PE,0x3c)[0]
assert PE[peofs:peofs+4]==b'PE\0\0'
sects=[]
section_base=peofs+24+struct.unpack_from('<H',PE,peofs+20)[0]
for i in range(struct.unpack_from('<H',PE,peofs+6)[0]):
 off=section_base+i*40
 name=PE[off:off+8].rstrip(b'\0').decode()
 size,rva,rawsize,rawoff=struct.unpack_from('<IIII',PE,off+8)
 sects.append((name,rva,max(size,rawsize),rawoff))
def va_bytes(a,n):
 rva=a-0x400000
 for name,begin,size,raw in sects:
  if begin<=rva<begin+size:return PE[raw+rva-begin:raw+rva-begin+n]
 raise ValueError(hex(a))
assert va_bytes(0x00417500,14).hex().upper()=='8B44240850E88615040083C404C3'
assert va_bytes(0x004170BF,1)==b'\xc3'
assert va_bytes(0x004170BA,1)==b'\xc3'
limit=struct.unpack('<f',va_bytes(0x004BC8BC,4))[0]
assert limit==80.0
asm=(P/'v80_selected_decomp.txt.missing_asm.txt').read_text()
b1=asm.split('==== 00417060 ====')[1].split('==== 00417500 ====')[0]
b2=asm.split('==== 00417500 ====')[1]
assert '004170ba RET' in b1 and '004170bf RET' in b1
assert '0041750d RET' in b2
assert '0xa818' in b1 and '0x0040b450' in b1 and '0x004589f0' in b1
scratch=(P/'v80_missing_callbacks_decompiled.txt').read_text()
assert '0x11 + 0x1e' in scratch and '0xa818' in scratch
assert 'is_vehicle_or_actor_runtime_world_object(param_2)' in scratch
rows=list(csv.DictReader((P/'v80_whole_program_event_fields.tsv').open(),delimiter='\t'))
assert len(rows)==56
fields={f'0x{x:x}' for x in [0xa6e4,0xa6e8,0xa6ec]}
source=[r for r in rows if r['displacement'] in fields]
source_writers=[r for r in source if r['assembly'].startswith(('MOV dword ptr [','FSTP '))]
assert len(source_writers)==6
allowed={'00415640','004157a0'}
assert {r['owner'].split('@')[-1].lower() for r in source_writers}==allowed
assert not [r for r in source if 'FUN_00409980@' in r['owner']]
G=(P/'v80_selected_decomp.txt').read_text()
resolver=G.split('===== 00410A10 initialize_fsm_command_name_table =====')[1].split('===== 004102D0 ')[0]
entries=[(0,'null')]
for m in re.finditer(r'pcVar4\s*=\s*s_(.*?)_004c[0-9a-f]{4};',resolver):
 nxt=resolver[m.end():m.end()+740]; ret=re.search(r'\breturn\s+(0x[0-9a-f]+|\d+)\s*;',nxt)
 if ret:entries.append((int(ret.group(1),0),m.group(1)))
# The resolver text explicitly lists the initial null command before the first pcVar4 reassign.
entries=entries[0:1]+[e for e in entries[1:] if e!=(0,'null')]
assert set(i for i,n in entries)==set(range(96))
assert len(entries)==97 # 96 unique IDs plus isArrived alias
assert [n for i,n in entries if i==40]==['isArrived','isArrived']
lookup={i:n for i,n in entries}
HOST=Path('/mnt/data/i76_v78_fsm_decompiled.txt').read_text()
chunk=HOST.lower().split('===== 00412ce0',1)[1].split('\n===== ',1)[0]
ids={int(x,0) for x in re.findall(r'\n\s*case\s+(0x[0-9a-f]+|\d+):',chunk)}
assert ids==set(range(96))-{22}
assert lookup[22]=='playScene'
# Extract observed direct named callees per switch arm; don't reinterpret unnamed API semantics.
body=HOST.split('===== 00412ce0',1)[1].split('\n===== ',1)[0]
case_pat=re.compile(r'^\s*case\s+(0x[0-9a-f]+|\d+):',re.M)
all_cases=list(case_pat.finditer(body))
callees={}
for j,m in enumerate(all_cases):
 i=int(m.group(1),0)
 next_pos=all_cases[j+1].start() if j+1<len(all_cases) else len(body)
 seg=body[m.end():next_pos]
 names=[]
 for hit in re.finditer(r'(?<![A-Za-z0-9_])([A-Za-z_][A-Za-z0-9_]*)\s*\(',seg):
  nm=hit.group(1)
  if nm not in {'if','while','switch','sizeof','float','int','code','uint','undefined4','LPVOID'} and not nm.startswith(('CONCAT','SUB','ZEXT','SEXT')) and nm not in names: names.append(nm)
 callees[i]=names
out=P/'v80_mission_host_commands.tsv'
with out.open('w',newline='') as f:
 w=csv.writer(f,delimiter='\t')
 w.writerow(['opcode_dec','opcode_hex','source_command_name','resolver_matches','explicit_dispatch_case','direct_named_callee_candidates','source_evidence'])
 for i in range(96):
  w.writerow([i,f'0x{i:02X}',lookup[i],sum(j==i for j,n in entries),'yes' if i in ids else 'no','; '.join(callees.get(i,[])),'00410A10 resolver / 00412CE0 dispatcher'])
assert sum(1 for i in range(96) if i in ids)==95
report={
 'status':'PASS','scope':'Ghidra static exports cross-checked against original retail PE; no runtime execution',
 'retail_md5':MD5,
 'ghidra_project':'isolated imported user GZF + disposable scratch function boundaries',
 'v80_full_instruction_scan':232525,
 'v80_event_displacement_matches':56,
 'source_displacement_explicit_writes':len(source_writers),
 'source_displacement_writer_functions':sorted(allowed),
 'new_function_candidates':{'00417060':['00417060','004170BF'],'00417500':['00417500','0041750D']},
 'distance_threshold_float':limit,'integrity_selector_formula':'integrity_pct < 30 + 17 * AI_tactics_level (A818)',
 'resolver_unique_ids':len(lookup),'resolver_matching_branches':len(entries),
 'dispatcher_explicit_case_count':len(ids),'resolver_but_not_dispatcher':[{'id':22,'name':lookup[22]}],
 'state_table_reference':'v79 34 indexed AI states',
 'limitations':['Indirect/aliased stores may not be counted by numeric displacement scan.','No live gameplay, decompiler prototypes may be inaccurate.','Missing dispatcher case is proven for retail 00412CE0 only.','Source pointer survival after object release is a risk hypothesis, not a demonstrated dangling-pointer bug.'],
 'checks':[ 'retail PE MD5','instruction bytes both callbacks','both independent function RET ranges','literal 80.0f PE constant','decompiler predicate formula','complete displacement scan and writer scope','96 distinct resolver names plus alias','95 native dispatcher cases and excluded playScene']}
(P/'v80_static_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
