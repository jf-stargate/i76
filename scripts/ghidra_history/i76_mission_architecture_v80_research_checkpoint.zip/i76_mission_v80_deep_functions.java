// @category I76
// Read-only native decompilation and exact disassembly of mission boundary functions.
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.program.model.listing.*;
import java.io.*;
public class i76_mission_v80_deep_functions extends GhidraScript {
  private static final String[] FUNS={"004589F0","00458A90","0040B450","004170C0","00415640","00457420","0045ED00","0045EF70","0045F0F0","00420B30","004125C0","00410A10","004102D0","00410490","00410720","00409740"};
  @Override public void run() throws Exception{
   String[] a=getScriptArgs();if(a.length<1)throw new IllegalArgumentException("Output path required");
   DecompInterface dc=new DecompInterface();dc.openProgram(currentProgram);dc.setOptions(new DecompileOptions());
   try(PrintWriter out=new PrintWriter(new File(a[0]),"UTF-8")){
    for(String k:FUNS){Function f=currentProgram.getFunctionManager().getFunctionAt(toAddr(k));out.println("\n===== "+k+" "+(f==null?"UNDEFINED":f.getName())+" =====");
     if(f==null)continue;
     DecompileResults res=dc.decompileFunction(f,45,monitor);out.println(res.decompileCompleted()?res.getDecompiledFunction().getC():"FAILED: "+res.getErrorMessage());
    }
   } finally{dc.dispose();}
   try(PrintWriter out=new PrintWriter(new File(a[0]+".missing_asm.txt"),"UTF-8")){
    for(String start:new String[]{"00417060","00417500"}){
      out.println("\n==== "+start+" ====");Instruction in=currentProgram.getListing().getInstructionAt(toAddr(start));
      for(int i=0;i<80&&in!=null;i++){String addr=in.getAddress().toString();if(i>0 && ((start.equals("00417060")&&in.getAddress().compareTo(toAddr("004170C0"))>=0)||(start.equals("00417500")&&in.getAddress().compareTo(toAddr("00417510"))>=0)))break;out.println(addr+" "+in);in=in.getNext();}
    }
   }
   println("V80_DECOMP_OK");
  }
}
