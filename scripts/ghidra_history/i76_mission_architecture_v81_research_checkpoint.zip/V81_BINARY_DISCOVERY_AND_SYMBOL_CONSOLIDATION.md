# I76 mission architecture v81 — binary-wide discovery and symbol consolidation

Date: October 20, 2026. Phase: **reverse engineering only**. Original user-supplied GZF remains unchanged. Evidence: native Ghidra 12.1.4, the imported existing annotations, and executable MD5 `a640ea0097dbb62e0c77b7f2847c7161`.

## Executive findings

A read-only Ghidra pass enumerated **2,097 internal functions** (the earlier 2,332 count includes externals) and emitted 2,075 direct-call edges from mission-/AI-/script-/VOM-related named functions. There were **no direct CALL targets** pointing to disassembled instructions outside an existing function. This does not imply that indirect callbacks, raw data pointers, thunk tables or all undiscovered code have been exhausted.

**Primary previously undercounted control path:** Ghidra does not have a conventional reference to the loader `00409740`. A raw four-byte executable pointer at **`00500D38`** points to it. The surrounding 16-byte descriptor is `(handler=00409740, auxiliary=1, tag='EXIT', trailing=0)` following a `(handler=004B4610, auxiliary=0x2004, tag='FSM', trailing=0)` descriptor at **`00500D28`**. This belongs to the caller-supplied tagged BWD2 resource parser used to load missions (`004B41E0`), and connects the mission-resource layer to the established FSM table loader. This is a **static callback-registry identification**, not a recorded runtime call.

The systematic, pattern-bounded scan of four-byte-aligned tagged descriptors in `004FF000–00500DB0` recovered **101 candidate handler records**; all 101 point to **defined Ghidra functions** in the updated project. The table spans vehicle-resource entries and world/mission sections; it is **not an exhaustive search of all callback tables** elsewhere in the executable. See `v81_bwd2_tagged_handler_candidates.tsv` for every entry and the precise byte-derived tag.

## Explicit mission-related coverage recovered from the raw registry

| Raw descriptor | Handler | Evidence-based responsibility |
|---|---|---|
| `00500D28` `FSM` | `004B4610` | Revision/chunk validation helper; precedes the FSM end callback |
| `00500D38` `EXIT` | `00409740` | Loads and finalizes serialized FSM runtime tables |
| `00500AF0` `OBJ` | `004B4610` | Object/world revision or format check |
| `00500B00` `EXIT` | `004B7AC0` | Creates scene object/vehicle runtime record |
| `00500B20` `SOBJ` | `004B7F70` | Scene descriptor handler |
| `00500B30` `SGEO` | `004B8470` | Scene object geometry ID handler |
| `00500B40` `SCHK` | `004B7FF0` | Scene geometry section handler |
| `00500CE8` `ISEG` | `004B8780` | Route/corridor segment record handler |
| `00500CF8` `TSEG` | `004B8960` | Route segment record table handler |
| `00500B60` `EXIT` | `004B8ED0` | Light world-object constructor; section-dependent finalizer context |

Note: the tag shown is the descriptor's encoded tag. Some descriptors named `EXIT` are section exit handlers; a tag is not necessarily the semantic name of its callback or of the preceding section.

## Resolved function symbols and missing boundaries

The mutable working project gained **two function definitions** for previously disassembled but unbounded AI callbacks and **five corrected function names**. Corrected names include:

- `00409850` => `fsm_on_world_object_registered`: registered at `00409BF4` by `00409BD0`; inserts into team buckets, initializes vehicle state, and parses tactics. Its previous name incorrectly suggested top-level heap initialization.
- `00409980` => `fsm_on_world_object_unregistered`: callback registered at `00409C17`; removes team records, clears held mission actor bindings/AI target references.
- `00412680` => `select_ai_behavior_weighted_candidate`: uses `0x1354` behavior descriptor stride, `0x1D8` predicate-group stride and weighted candidate selection. Its previous name described only the aggression sum.
- `0041C2C0` => `ai_behavior_condition_current_epoch_normal_damage`: checks AI `+A6D8` against the global event epoch, without comparing actor identifiers and without consuming the marker.
- `0040B0F0` => `fsm_query_who_shot`: FSM host opcode `0x0C` and `whoShot` diagnostic, reads AI `+A6E8` source. It may include other specially categorized hits; the command name is the established lexical identity.
- Newly defined `00417060..004170BF`: `ai_behavior_selector_near_and_below_integrity_threshold` (previous v80 exact `<80` distance and `<30+17*tactics` percent rule).
- Newly defined `00417500..0041750D`: `ai_behavior_selector_target_is_vehicle_or_actor` (tail wrapper around `00458A90`).

Existing scene, route, and object-loader handler functions in the BWD2 table were already named, so no speculative renames were applied to those.

## Resolved mission runtime global layout

These fields were verified by positional arguments to `00410720` (serialized loader), `00409740` (chunk callback), `004125C0` (finalizer) and `0040A320`/`004149F0` (execution):

| Address | Final semantic field | Runtime representation |
|---|---|---|
| `0051F5B4` | `g_fsm_runtime_heap_handle` | HeapCreate result |
| `0051F608 / 60C` | `g_fsm_host_command_records` / `_count` | 0x54-byte records, opcode at +0x50 |
| `0051F610 / 614` | `g_fsm_media_records` / `_count` | 0x54-byte validated media records |
| `0051F618 / 61C` | `g_fsm_named_position_records` / `_count` | Named vec3 record sets |
| `0051F620 / 624` | `g_fsm_mission_actor_records` / `_count` | 0x60-byte actor records, live reference +0x58 |
| `0051F628 / 62C` | `g_fsm_pending_vm_node_head` / `_count` | Linked 0x10BC-byte VM nodes |
| `0051F630 / 634` | `g_fsm_vm_initial_word_array` / `_count` | u32 serialized runtime words |
| `0051F638 / 63C` | `g_fsm_vm_token_array` / `_count` | 8-byte `{kind,payload}` tokens |
| `00507DA0 / 51F5D0` | Team object buckets / counts | 8 buckets × 64 pointers plus per-bucket counts |
| `005244E0 / 005244E4` | Game-flow timeout seconds / destination state | Pending mission game-flow transition |
| `005244DC` | `g_fsm_vm_instruction_budget_exceeded` | VM budget flag observed by host dispatcher |

**Audited address correction:** The first labeling pass mistakenly assigned the heap handle to `0051F600`. An independent instruction/symbol scan identified the actual `HeapCreate` result store at `004097C8 -> 0051F5B4`. The working project was corrected and **both final labels were subsequently reimport-verified**. `0051F600` is now conservatively labeled `g_fsm_runtime_initialization_flag_0051f600` because initialization writes 1 there; its full use semantics are not yet independently established.

## Persistence, integrity and limitations

- **29 function/global symbol names**, plus executable MD5, passed **30 checks** after **exporting a new GZF and importing it into a fresh Ghidra project**. This tests persistence, not just in-memory changes.
- The original retail image and original user GZF were not modified. This work modifies neither machine code nor gameplay resources; symbol/definition metadata only.
- Full callback coverage cannot be proven without auditing any additional raw tables, computed dispatch, dynamic resource handlers and mission execution in the real game.
- No gameplay runtime execution or behavioral measurements were performed during v81.
- No AI/FSM reimplementation was started.

## Files

`i76_mission_v81_symbols.gzf` is the **verified updated Ghidra Program export**. Import as a separate program or back up your existing Ghidra project before replacing the baseline. `v81_symbol_change_audit_FINAL.tsv` contains the final old→new changes, excluding corrected intermediate labels. `v81_reimport_validation.tsv` proves every preserved name; `v81_bwd2_tagged_handler_candidates.tsv` is the full bounded descriptor inventory. The standalone Ghidra scripts are included for reproducibility.

## Next mission research boundary

With host-command names, handler pointers, AI table cardinality, and core FSM globals mapped, the next highest-value work is an opcode-by-opcode **host command ABI and side-effects audit**, including actor reference ownership, scheduler-order event arbitration, resource actions and mission game-flow transitions. Keep any dynamic/gameplay behavioral tests explicitly separate from static findings.
