# I76 v81 research checkpoint

- The `i76_mission_v81_symbols.gzf` file is a Ghidra Program archive. Import into Ghidra 12.1.4 using **File → Import File**, keeping the user's existing program backed up. This archive was roundtrip-imported and validated in an isolated project.
- All evidence is on the retail executable MD5 `a640ea0097dbb62e0c77b7f2847c7161`; no executable patches or replacement runtime.
- This ZIP also contains the consolidated symbol audit, raw BWD2 callback registry, native decompiler extracts, read-only scan scripts, and guarded symbol-application script.
- **Warning:** `i76_mission_v81_apply_verified_symbols.java` and `i76_mission_v81_correct_heap_labels.java` mutate Ghidra symbols. Run only against a backed-up disposable project. The updated GZF already includes those changes; there is no need to rerun the mutating scripts.
- Source GZF was never modified, and source retail PE is not redistributed.
