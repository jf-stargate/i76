// @category I76
// v81 GZF roundtrip verification + raw BWD2 handler descriptor enumeration; read-only
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.Function;
import ghidra.program.model.symbol.Symbol;
import ghidra.program.model.address.Address;
import java.io.*;import java.util.*;
public class i76_mission_v81_reimport_verify extends GhidraScript {
 static String[][] functions={{"00409850","fsm_on_world_object_registered"},{"00409980","fsm_on_world_object_unregistered"},{"00412680","select_ai_behavior_weighted_candidate"},{"0041C2C0","ai_behavior_condition_current_epoch_normal_damage"},{"0040B0F0","fsm_query_who_shot"},{"00417060","ai_behavior_selector_near_and_below_integrity_threshold"},{"00417500","ai_behavior_selector_target_is_vehicle_or_actor"}};
 static String[][] globals={{"00507DA0","g_fsm_team_world_object_entry_buckets"},{"0051F5D0","g_fsm_team_world_object_entry_counts"},{"0051F5B4","g_fsm_runtime_heap_handle"},{"0051F600","g_fsm_runtime_initialization_flag_0051f600"},{"0051F608","g_fsm_host_command_records"},{"0051F60C","g_fsm_host_command_record_count"},{"0051F610","g_fsm_media_records"},{"0051F614","g_fsm_media_record_count"},{"0051F618","g_fsm_named_position_records"},{"0051F61C","g_fsm_named_position_record_count"},{"0051F620","g_fsm_mission_actor_records"},{"0051F624","g_fsm_mission_actor_record_count"},{"0051F628","g_fsm_pending_vm_node_head"},{"0051F62C","g_fsm_pending_vm_node_count"},{"0051F630","g_fsm_vm_initial_word_array"},{"0051F634","g_fsm_vm_initial_word_count"},{"0051F638","g_fsm_vm_token_array"},{"0051F63C","g_fsm_vm_token_count"},{"005244E0","g_fsm_game_flow_timeout_seconds"},{"005244E4","g_fsm_game_flow_timeout_next_state"},{"005244DC","g_fsm_vm_instruction_budget_exceeded"},{"00500D38","g_bwd2_mission_fsm_exit_callback_descriptor"}};
 void ck(boolean val,String msg){if(!val)throw new IllegalStateException(msg);}
 public void run() throws Exception{
  File dir=new File(getScriptArgs()[0]);dir.mkdirs();int checks=0,records=0,missing=0;
  ck("a640ea0097dbb62e0c77b7f2847c7161".equalsIgnoreCase(currentProgram.getExecutableMD5()),"Original executable checksum mismatch");checks++;
  try(PrintWriter w=new PrintWriter(new File(dir,"v81_reimport_validation.tsv"),"UTF-8")){
   w.println("kind\taddress\texpected\tactual\tresult");
   for(String[] row:functions){Function f=currentProgram.getFunctionManager().getFunctionAt(toAddr(row[0]));String actual=f==null?"MISSING":f.getName();ck(row[1].equals(actual),"function "+row[0]+" "+actual);w.println("function\t"+row[0]+"\t"+row[1]+"\t"+actual+"\tPASS");checks++;}
   for(String[] row:globals){Symbol s=currentProgram.getSymbolTable().getPrimarySymbol(toAddr(row[0]));String actual=s==null?"MISSING":s.getName();ck(row[1].equals(actual),"global "+row[0]+" "+actual);w.println("global\t"+row[0]+"\t"+row[1]+"\t"+actual+"\tPASS");checks++;}
  }
  try(PrintWriter w=new PrintWriter(new File(dir,"v81_bwd2_tagged_handler_candidates.tsv"),"UTF-8")){
   w.println("descriptor_address\tcallback_address\tfunction_name\tcallback_defined\tauxiliary_value\ttag\ttrailing_word");
   for(long v=0x004ff000L;v<0x00500db0L;v+=4){
    Address a=toAddr(v);int ptr=currentProgram.getMemory().getInt(a), aux=currentProgram.getMemory().getInt(a.add(4)), trailer=currentProgram.getMemory().getInt(a.add(12));
    if(ptr<0x00401000 || ptr>0x004bdf00 || aux<0 || aux>0x01000000 || trailer!=0)continue;
    byte[] tag=new byte[4];currentProgram.getMemory().getBytes(a.add(8),tag);
    boolean valid=true,atleast=false;for(byte x:tag){int y=x&255;if(y!=0)atleast=true;if(!(y==0||(y>=65&&y<=90)||(y>=48&&y<=57)||y==95))valid=false;}
    if(!valid||!atleast)continue;
    Function f=currentProgram.getFunctionManager().getFunctionAt(toAddr(ptr));String name=f==null?"UNDEFINED":f.getName();records++;if(f==null)missing++;
    String tagstr=new String(tag,"US-ASCII").replace("\u0000","");
    w.println(a+"\t"+String.format("%08X",ptr)+"\t"+name+"\t"+(f!=null)+"\t"+String.format("0x%X",aux)+"\t"+tagstr+"\t0x0");
   }
  }
  try(PrintWriter w=new PrintWriter(new File(dir,"v81_reimport_summary.txt"),"UTF-8")){
    w.println("Ghidra roundtrip GZF verified against original retail image");w.println("validated_fields="+checks);
    w.println("tagged_BWD2_structural_candidates="+records);w.println("tagged_BWD2_candidates_without_defined_functions="+missing);
    w.println("NOTE: this is a pattern-bounded descriptor audit for 004FF000-00500DB0, not proof of all callback tables in the executable.");
   }
  println("V81_ROUNDTRIP_OK checks="+checks+" tagged_rows="+records+" undefined_callbacks="+missing);
 }
}
