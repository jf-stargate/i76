// @category I76
// v81 APPLY: run ONLY in isolated working project imported from untouched user GZF.
// Guard: retail MD5, original symbolic names, callback code ranges, tagged FSM table marker.
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.*;
import java.io.*;
public class i76_mission_v81_apply_verified_symbols extends GhidraScript {
 private PrintWriter audit;
 String clean(String s){return s.replace('\t',' ').replace('\n',' ');}
 void line(String kind, String addr, String old, String nu,String confidence,String evidence,String status){audit.println(String.join("\t",kind,addr,old,nu,confidence,evidence,status));}
 void function(String addr,String expected,String nu,String evidence)throws Exception{
   Address a=toAddr(addr);Function f=currentProgram.getFunctionManager().getFunctionAt(a);
   if(f==null){line("function",addr,"MISSING",nu,"HIGH",evidence,"SKIP_NOT_DEFINED");return;}
   String old=f.getName();if(!old.equals(expected)){line("function",addr,old,nu,"HIGH",evidence,"SKIP_EXPECTED_MISMATCH");return;}
   f.setName(nu,SourceType.USER_DEFINED);line("function",addr,old,nu,"HIGH",evidence,"APPLIED");
 }
 void boundary(String a,String b,String nu,String evidence)throws Exception{
   Address start=toAddr(a),end=toAddr(b);Function f=currentProgram.getFunctionManager().getFunctionAt(start);
   if(f==null){if(currentProgram.getFunctionManager().getFunctionContaining(start)!=null)throw new IllegalStateException("overlap at "+a);
     f=currentProgram.getFunctionManager().createFunction(nu,start,new AddressSet(start,end),SourceType.USER_DEFINED);
     if(f==null)throw new IllegalStateException("Failed create "+a);line("new_function",a,"UNDEFINED",nu,"HIGH",evidence,"CREATED");return;}
   line("new_function",a,f.getName(),nu,"HIGH",evidence,"ALREADY_DEFINED_NO_CHANGE");
 }
 void global(String addr,String nu,String evidence)throws Exception{
   Address a=toAddr(addr);Symbol s=currentProgram.getSymbolTable().getPrimarySymbol(a);String old=s==null?"UNNAMED":s.getName();
   if(s!=null && !old.startsWith("DAT_") && !old.startsWith("PTR_") && !old.startsWith("LAB_") && !old.equals("g_fsm_runtime_global_cluster_end") && !old.equals("g_fsm_runtime_global_cluster_begin") && !old.equals("g_fsm_runtime_table_cluster")){
      line("global",addr,old,nu,"HIGH",evidence,"SKIP_PRESERVE_EXISTING");return;
   }
   if(s!=null && s.getSource()!=SourceType.DEFAULT){s.setName(nu,SourceType.USER_DEFINED);}
   else{createLabel(a,nu,true);}
   line("global",addr,old,nu,"HIGH",evidence,"APPLIED");
 }
 public void run()throws Exception{
   if(!"a640ea0097dbb62e0c77b7f2847c7161".equalsIgnoreCase(currentProgram.getExecutableMD5()))throw new IllegalStateException("Unexpected retail PE MD5");
   // Raw BWD2 mission table: callback pointer + EXIT marker are strong binary preflight.
   if(currentProgram.getMemory().getInt(toAddr("00500D38"))!=0x00409740 || currentProgram.getMemory().getInt(toAddr("00500D40"))!=0x54495845)
     throw new IllegalStateException("BWD2 mission FSM callback table differs from expected");
   File dir=new File(getScriptArgs()[0]);dir.mkdirs();
   try(PrintWriter w=new PrintWriter(new File(dir,"v81_symbol_change_audit.tsv"),"UTF-8")){
    audit=w;audit.println("kind\taddress\told_name\tnew_name\tconfidence\tevidence\tstatus");
    boundary("00417060","004170BF","ai_behavior_selector_near_and_below_integrity_threshold","v80 scratch decomp+retail x87 threshold 80 and 30+17*A818");
    boundary("00417500","0041750D","ai_behavior_selector_target_is_vehicle_or_actor","v80 callback pointer table & tail wrapper to 00458A90");
    function("00409850","initialize_fsm_runtime_heap_and_tables","fsm_on_world_object_registered","00409BD0 registration at 00409BF4; team bucket insertion");
    function("00409980","FUN_00409980","fsm_on_world_object_unregistered","00409BD0 unregister callback; actor and target refs cleared");
    function("00412680","compute_fsm_aggression_sum","select_ai_behavior_weighted_candidate","34-state descriptor + 0x1D8 weighted candidate choices and predicates");
    function("0041C2C0","is_ai_vehicle_target_matching_current_player_or_actor","ai_behavior_condition_current_epoch_normal_damage","reads AI+A6D8, exact compare to global event epoch, no actor lookup");
    function("0040B0F0","fsm_query_recent_special_damage_source","fsm_query_who_shot","host cmd 0x0C; diagnostic whoShot; AI+A6E8 source");
    global("00507DA0","g_fsm_team_world_object_entry_buckets","00409850 team-index insertion, 8 buckets x 64 entries; 00409980 removal");
    global("0051F5D0","g_fsm_team_world_object_entry_counts","00409850 increments bucket indexed by world bits; 00409980 decrements");
    global("0051F600","g_fsm_runtime_heap_handle","00409740 HeapCreate; 004149F0 HeapFree and 0040A030 HeapDestroy");
    global("0051F608","g_fsm_host_command_records","00409740 -> 00410720 first table 0x54 stride; 00412CE0 opcode +0x50");
    global("0051F60C","g_fsm_host_command_record_count","00410720 loader param4 and 004125C0 finalizer param2");
    global("0051F610","g_fsm_media_records","00410720 loader second 0x54 stride; 004125C0 validates WAV/SMK");
    global("0051F614","g_fsm_media_record_count","00410720 param6; 004125C0 validates media");
    global("0051F618","g_fsm_named_position_records","004102D0 loader named vec3 arrays; 00409740 loader param7");
    global("0051F61C","g_fsm_named_position_record_count","004102D0 loader param8; 00409740 param8");
    global("0051F620","g_fsm_mission_actor_records","004105A0 loader 0x60 actor records; who* binding +0x58");
    global("0051F624","g_fsm_mission_actor_record_count","00410720 actor count; who* append; 00409980 unregister scan");
    global("0051F628","g_fsm_pending_vm_node_head","00410490 linked allocation 0x10BC; 004149F0 list traversal");
    global("0051F62C","g_fsm_pending_vm_node_count","00410490 allocation count; 004149F0 decrements on completion");
    global("0051F630","g_fsm_vm_initial_word_array","00410720 param13 allocates u32 table; 00412500 node relocation");
    global("0051F634","g_fsm_vm_initial_word_count","00410720 param14 u32 count");
    global("0051F638","g_fsm_vm_token_array","00410720 param15 allocates token kind/payload pairs, 8-byte stride");
    global("0051F63C","g_fsm_vm_token_count","00410720 param16 count; 0040A320 frame dispatch param1");
    global("005244E0","g_fsm_game_flow_timeout_seconds","00412CE0 sets deadline and 004149F0 compares current runtime seconds");
    global("005244E4","g_fsm_game_flow_timeout_next_state","00412CE0 selects flow state; 004149F0 calls set_game_flow_state");
    global("005244DC","g_fsm_vm_instruction_budget_exceeded","00414670 writes on >800 instructions, 00412CE0 observes flag");
    global("00500D38","g_bwd2_mission_fsm_exit_callback_descriptor","retail .data [00409740,1,'EXIT',0] in mission tagged chunk descriptor table");
   }
   println("V81_VERIFIED_SYMBOL_APPLY_COMPLETE");
 }
}
