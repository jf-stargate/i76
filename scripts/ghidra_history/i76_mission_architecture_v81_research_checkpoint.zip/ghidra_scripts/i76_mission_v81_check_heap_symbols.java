// @category I76
import ghidra.app.script.GhidraScript;
import ghidra.program.model.symbol.Symbol;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Instruction;
import java.io.*;
public class i76_mission_v81_check_heap_symbols extends GhidraScript {
 public void run()throws Exception{
  File out=new File(getScriptArgs()[0]);try(PrintWriter w=new PrintWriter(out,"UTF-8")){
   for(String n:new String[]{"g_fsm_runtime_global_cluster_begin","g_fsm_runtime_global_cluster_end","g_fsm_runtime_table_cluster","g_fsm_runtime_heap_handle"})for(Symbol s:currentProgram.getSymbolTable().getSymbols(n))w.println(n+"="+s.getAddress());
   for(long a=0x0051f5f0L;a<=0x0051f644L;a+=4){Address aa=toAddr(a);Symbol s=currentProgram.getSymbolTable().getPrimarySymbol(aa);w.println(aa+"="+(s==null?"NONE":s.getName()));}
   for(long a=0x0040978cL;a<0x004097dbL;a++){Instruction i=currentProgram.getListing().getInstructionAt(toAddr(a));if(i!=null){w.println(i.getAddress()+" "+i);a=i.getMaxAddress().getOffset();}}
  }
 }
}
