// @category I76
// Read-only v81 native decomp and symbol audit of mission resource table raw callbacks.
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.address.*;
import ghidra.program.model.symbol.*;
import java.io.*;
public class i76_mission_v81_descriptor_callbacks extends GhidraScript {
 static final String[] A={"004B4290","004B4610","004B7AC0","004B7F70","004B8050","004B8470","004B8780","004B8960","004B8A10","004B8ED0","004B8E00","004B8E20","004B8F70","00409740"};
 public void run()throws Exception{
 DecompInterface di=new DecompInterface();di.openProgram(currentProgram);File out=new File(getScriptArgs()[0]);
 try(PrintWriter w=new PrintWriter(out,"UTF-8")){
 for(String s:A){Address a=toAddr(s);Function f=currentProgram.getFunctionManager().getFunctionAt(a);
   w.println("\n#### "+s+" function="+(f==null?"NONE":f.getName())+" type="+(f==null?"":f.getSignature().getPrototypeString()));
   if(f==null)continue;DecompileResults r=di.decompileFunction(f,40,monitor);w.println(r.decompileCompleted()?r.getDecompiledFunction().getC():"FAILED "+r.getErrorMessage());
 }
 }finally{di.dispose();}
 println("V81_DESCRIPTOR_CALLBACKS_OK");
 }
}
