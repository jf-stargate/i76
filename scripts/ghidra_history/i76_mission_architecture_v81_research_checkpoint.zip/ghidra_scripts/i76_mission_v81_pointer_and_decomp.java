// @category I76
// v81 read-only orphan callback inventory; native decompilation for registry/loader/flags.
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.address.*;
import ghidra.program.model.symbol.*;
import java.io.*;import java.util.*;
public class i76_mission_v81_pointer_and_decomp extends GhidraScript{
 static final String[] TARGETS={"00409740","00409850","00409980","00409BD0","004102B0","004102D0","00410490","004105A0","00410720","00412500","004125C0","00412680","00412830","004149F0","0041C2C0","0045E9E0","0045EA30","004B41E0","004B42B0"};
 public void run()throws Exception{
  File dir=new File(getScriptArgs()[0]);dir.mkdirs();
  try(PrintWriter w=new PrintWriter(new File(dir,"v81_orphan_code_data_callbacks.tsv"),"UTF-8")){
   w.println("target\tsource\treftype\towner\ttarget_instruction");
   for(Data d:currentProgram.getListing().getDefinedData(true))for(Reference r:d.getReferencesFrom()){
    Address to=r.getToAddress();if(!to.isMemoryAddress()||currentProgram.getFunctionManager().getFunctionContaining(to)!=null)continue;
    Instruction i=currentProgram.getListing().getInstructionAt(to);if(i==null)continue;
    Function f=currentProgram.getFunctionManager().getFunctionContaining(r.getFromAddress());
    w.println(to+"\t"+r.getFromAddress()+"\t"+r.getReferenceType()+"\t"+(f==null?"DATA":f.getName())+"\t"+i.toString().replace('\t',' '));
   }
  }
  DecompInterface dc=new DecompInterface();dc.openProgram(currentProgram);
  try(PrintWriter w=new PrintWriter(new File(dir,"v81_targeted_native_decomp.txt"),"UTF-8")){
   for(String a:TARGETS){Function f=currentProgram.getFunctionManager().getFunctionAt(toAddr(a));w.println("\n==== "+a+" "+(f==null?"UNDEFINED":f.getName())+" ====");if(f==null)continue;
    DecompileResults r=dc.decompileFunction(f,60,monitor);w.println(r.decompileCompleted()?r.getDecompiledFunction().getC():"FAILED: "+r.getErrorMessage());
   }
  }finally{dc.dispose();}
  println("V81_POINTER_AUDIT_OK");
 }
}
