// @category I76
// v81 post-audit correction, isolated working project only.
import ghidra.app.script.GhidraScript;
import ghidra.program.model.symbol.*;
import java.io.*;
public class i76_mission_v81_correct_heap_labels extends GhidraScript {
 public void run()throws Exception{
  if(!"a640ea0097dbb62e0c77b7f2847c7161".equalsIgnoreCase(currentProgram.getExecutableMD5()))throw new IllegalStateException("wrong PE");
  Symbol flag=currentProgram.getSymbolTable().getPrimarySymbol(toAddr("0051F600"));
  Symbol heap=currentProgram.getSymbolTable().getPrimarySymbol(toAddr("0051F5B4"));
  if(flag==null||!flag.getName().equals("g_fsm_runtime_heap_handle")||heap==null||!heap.getName().equals("g_fsm_runtime_global_cluster_begin"))throw new IllegalStateException("Unexpected original labels");
  flag.setName("g_fsm_runtime_initialization_flag_0051f600",SourceType.USER_DEFINED);
  heap.setName("g_fsm_runtime_heap_handle",SourceType.USER_DEFINED);
  try(PrintWriter out=new PrintWriter(new File(getScriptArgs()[0]),"UTF-8")){
   out.println("kind\taddress\told_name\tnew_name\tevidence");
   out.println("global_correction\t0051F600\tg_fsm_runtime_heap_handle\tg_fsm_runtime_initialization_flag_0051f600\t00409BD0 initializes one; NOT a HeapCreate output");
   out.println("global_correction\t0051F5B4\tg_fsm_runtime_global_cluster_begin\tg_fsm_runtime_heap_handle\t004097C8 writes HeapCreate EAX; passed to 00410720; 0040A030 HeapDestroy");
  }
  println("V81_HEAP_LABELS_CORRECTED");
 }
}
