// @category I76
// v81 broad discovery: read-only mission/AI/runtime lexical, direct-call, pointer, xref inventory
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.*;
import ghidra.program.model.mem.*;
import java.io.*;
import java.util.*;
public class i76_mission_v81_discovery extends GhidraScript {
  String clean(String s){return s.replace('\t',' ').replace('\n',' ').replace('\r',' ');}
  String owner(Address a){Function f=currentProgram.getFunctionManager().getFunctionContaining(a);return f==null?"NO_FUNCTION":f.getEntryPoint()+":"+f.getName();}
  String cur(Address a){Symbol s=currentProgram.getSymbolTable().getPrimarySymbol(a);return s==null?"UNNAMED":s.getName()+"@"+s.getSource();}
  boolean mission(String s){return s.toLowerCase(Locale.ROOT).matches(".*(fsm|mission|script|objective|actor|vehicle_ai|ai_behavior|tactic|world_object|damage_source|game_flow|vom|scene|command|gameplay).*" );}
  String refs(Address a,int max){StringBuilder b=new StringBuilder();int n=0;for(Reference r:currentProgram.getReferenceManager().getReferencesTo(a)){if(n++>=max){b.append("... ");break;}b.append(r.getFromAddress()+":"+owner(r.getFromAddress())+":"+r.getReferenceType()+"; ");}return b.toString();}
  void safe(PrintWriter w,String s){w.println(s);}
  @Override public void run()throws Exception{
    if(!"a640ea0097dbb62e0c77b7f2847c7161".equalsIgnoreCase(currentProgram.getExecutableMD5()))throw new IllegalStateException("MD5 mismatch");
    File d=new File(getScriptArgs()[0]);d.mkdirs();
    List<Function> funs=new ArrayList<>();for(Function f:currentProgram.getFunctionManager().getFunctions(true))funs.add(f);
    Map<Address,Function> entry=new HashMap<>();for(Function f:funs)entry.put(f.getEntryPoint(),f);
    try(PrintWriter w=new PrintWriter(new File(d,"v81_function_catalog.tsv"),"UTF-8")){
      w.println("entry\tend\tsize\tname\tsource\tparams\tref_count\treferences");
      for(Function f:funs)if(mission(f.getName()) || f.getName().startsWith("FUN_")){
        Symbol sy=currentProgram.getSymbolTable().getPrimarySymbol(f.getEntryPoint());int n=0;for(Reference r:currentProgram.getReferenceManager().getReferencesTo(f.getEntryPoint()))n++;
        w.println(f.getEntryPoint()+"\t"+f.getBody().getMaxAddress()+"\t"+f.getBody().getNumAddresses()+"\t"+f.getName()+"\t"+(sy==null?"NONE":sy.getSource())+"\t"+f.getParameterCount()+"\t"+n+"\t"+refs(f.getEntryPoint(),10));
      }
    }
    try(PrintWriter w=new PrintWriter(new File(d,"v81_undefined_targets.tsv"),"UTF-8")){
      w.println("target\tcode\tfirst_ins\tprimary_symbol\txref_count\tsource_references");
      Map<Address,List<String>> targets=new TreeMap<>();
      for(Instruction ins:currentProgram.getListing().getInstructions(true)){
        if(!ins.getFlowType().isCall())continue;
        for(Reference r:ins.getReferencesFrom()){
          Address a=r.getToAddress();if(!a.isMemoryAddress()||currentProgram.getFunctionManager().getFunctionContaining(a)!=null)continue;
          if(!currentProgram.getMemory().contains(a))continue;
          Instruction t=currentProgram.getListing().getInstructionAt(a);if(t==null)continue;
          targets.computeIfAbsent(a,k->new ArrayList<>()).add(ins.getAddress()+":"+owner(ins.getAddress()));
        }
      }
      for(var e:targets.entrySet()){Address a=e.getKey();Instruction ins=currentProgram.getListing().getInstructionAt(a);w.println(a+"\t"+(ins==null?"N":ins.getMnemonicString())+"\t"+clean(ins.toString())+"\t"+cur(a)+"\t"+e.getValue().size()+"\t"+String.join(";",e.getValue()));}
    }
    try(PrintWriter w=new PrintWriter(new File(d,"v81_mission_string_references.tsv"),"UTF-8")){
      w.println("address\tprimary_symbol\tpreview\trefs");
      for(Data data:currentProgram.getListing().getDefinedData(true)){
        if(!data.hasStringValue())continue;
        String s=data.getDefaultValueRepresentation();if(!mission(s))continue;
        w.println(data.getAddress()+"\t"+cur(data.getAddress())+"\t"+clean(s).substring(0,Math.min(200,clean(s).length()))+"\t"+refs(data.getAddress(),30));
      }
    }
    try(PrintWriter w=new PrintWriter(new File(d,"v81_global_symbol_baseline.tsv"),"UTF-8")){
      w.println("address\tname\tsource\trefs");
      long[] globals={0x00524550L,0x0051f620L,0x0051f624L,0x00507da0L,0x0051f5d0L,0x0051f640L,0x0051f638L,0x0051f60cL,0x0051f610L,0x0051f614L,0x0051f618L,0x0051f61cL,0x0051f628L,0x0051f62cL,0x0051f630L,0x0051f634L,0x0051f63cL,0x0051f5bcL,0x005244e0L,0x005244e4L,0x005244dcL,0x004c3edcL,0x004c3e54L,0x004c3e58L,0x004c3e88L,0x004c5150L,0x004144e4L};
      for(long v:globals){Address a=toAddr(v);w.println(a+"\t"+cur(a)+"\t"+(currentProgram.getSymbolTable().getPrimarySymbol(a)==null?"":currentProgram.getSymbolTable().getPrimarySymbol(a).getSource())+"\t"+refs(a,16));}
    }
    try(PrintWriter w=new PrintWriter(new File(d,"v81_mission_named_function_edges.tsv"),"UTF-8")){
      w.println("caller\tcallee_addr\tcallee\tcall_address\tcall_kind");
      int calls=0;
      for(Function f:funs)if(mission(f.getName())){
        for(Instruction ins:currentProgram.getListing().getInstructions(f.getBody(),true)){
          if(!ins.getFlowType().isCall())continue;
          for(Reference r:ins.getReferencesFrom())if(r.getReferenceType().isCall()){
            Address target=r.getToAddress();Function called=currentProgram.getFunctionManager().getFunctionAt(target);
            w.println(f.getEntryPoint()+":"+f.getName()+"\t"+target+"\t"+(called==null?cur(target):called.getName())+"\t"+ins.getAddress()+"\t"+r.getReferenceType());calls++;
          }
        }
      }
    }
    println("V81_DISCOVERY_OK functions="+funs.size());
  }
}
