# I76 v84 — ownership and damage-source lifetime

Retail `i76.exe` MD5 `a640ea0097dbb62e0c77b7f2847c7161`. Verified read-only using Ghidra 12.1.4 headless on the imported v81 named program. This is a static investigation, not live gameplay testing.

## 1. Stored attacker identities do not expire with event epochs

A whole-program scan over **232,525 decoded instructions** recovered **60 direct field-offset accesses** (eleven AI fields) and **34 explicit accesses** to five FSM globals. The three source pointers have precisely the following direct-access sites:

| AI source | Initialization | Damage-event writer | Reading query |
|---|---|---|---|
| `+A6E4` ram | `004156F4` | `00415836` | `0040B013`, `0040B03A`, `0040B0A0` |
| `+A6E8` shot | `004156FA` | `00415849` | `0040B113`, `0040B13A`, `0040B1A0` |
| `+A6EC` any | `00415700` | `0041585B` | `0040B213`, `0040B23A`, `0040B2A0` |

The only explicit *stores to each source-field displacement* are constructor initialization (`00415640`) and event recording (`004157A0`), while corresponding `whoRammed`, `whoShot`, or `whoAttacked` account for all observed direct reads. The unregistration callback `00409980` does not address these source fields. The event-consuming tests instead clear `+A6D4/+A6D8/+A6DC` epoch markers. The `who*` routines contain no epoch-recency test of their own. Accordingly, source identity and predicate event visibility have separate lifetimes.

**Conditional danger:** A `who*` helper may use a previously recorded source pointer after its owning world object has been removed. If the source is not already bound as a mission actor, it is passed to `0045ED00`, which dereferences it to increment the propagated reference count. If no other owner retains its allocation, this could dereference reclaimed memory. Neither actual gameplay reachability nor a crash is established. Numeric displacement scans do not exclude alias-based or bulk writes.

## 2. Null sentinel actor-slot behavior

`0040A8A0` (`fsm_format_default_label_name`, a misleading inherited name) searches for a qualifying actor among FSM team buckets. **On no target** it writes zero at `actor_records[count]+0x58`, returns index `count`, and **does not increment count**. Its caller `0040A740` treats index `count` as invalid. The write affects the reserved trailing slot, not a counted actor entry. This is a verified write-without-append path, not proof of buffer overflow. The earlier finding of `(initial actor count + 200)` record capacity remains; upper-bound conditions and whether one slot is deliberately reserved are unresolved.

## 3. Registry and vehicle destruction order

`004571A0` iterates active-world registry entries and invokes registered world-object unregistration callbacks before releasing/clearing each entry. This agrees with the ordinary `00457420` callback-before-release rule. `00465370` has branch-specific cleanup: one path unregisters its registry entry then removes the vehicle and unlinks its world-object node, whereas another changes status/effect and visual resources without the same immediate unlinking sequence. Thus a destroyed vehicle is not necessarily physically freed immediately after damage recording.

## 4. Evidence levels and pending tests

**Direct executable evidence:** exact field accesses, the absence of source-field clearing in the named callback, no-target sentinel write, bulk unregister callback order, and branch-dependent vehicle cleanup. **Inference:** source pointers are borrowed identities, not independently retained by the recorder, based on its instruction path. **Unknown:** whether reachable mission scripts use `who*` after source physical release; whether additional implicit/aliased clearing occurs; complete capacity limits and runtime branch feasibility.

A future targeted test should cover `event → attacker unregistration → who*` with/without retained references, and actor-count boundary cases. These are test cases to preserve, not an invitation to start reimplementation.

## Provisional source-layout evidence

- `00415640–004158B1`: AI event initialization and recorder, plausible adjacent source neighborhood.
- `0040A740–0040BB99`: FSM actor queries and adapters.
- `004571A0–004574D3`: active-world registry and callbacks.
- `0045EBD0–0045F307`: low-level intrusive ownership operations.

These are hypotheses, not original `.c/.h` boundaries. No Ghidra symbols were modified.
