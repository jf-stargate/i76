// @category I76
// v84 read-only instructions/field-lifetime inventory, with pinned original-executable MD5.
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.address.*;
import ghidra.app.decompiler.*;
import ghidra.program.model.symbol.*;
import java.io.*;
import java.util.*;

public class i76_v84_ownership_lifetime_crossrefs extends GhidraScript {
 private static final String[] DISPS = {"a6d4","a6d8","a6dc","a6e4","a6e8","a6ec","a6e0","a6f0","a944","a990","a9b4"};
 private static final String[] GLOBALS = {"0051f620","0051f624","0051f628","0051f62c","00524550"};
 private static final String[] TARGETS={"0045EBD0","0045ED00","0045ED70","0045EF70","0045F0F0","004572B0","00457420","004571A0","00409850","00409980","0040AFF0","0040B0F0","0040B1F0","0040A8A0","0040BA60","004157A0","00415640","00412830","00465370","0040B9E0","0040A030","0040A010","00410720","004105A0","00412400","0040A320","004149F0","0040A740","0045F410"};
 public void run() throws Exception {
  if(!"a640ea0097dbb62e0c77b7f2847c7161".equalsIgnoreCase(currentProgram.getExecutableMD5()))throw new IllegalStateException("wrong PE");
  File dir=new File(getScriptArgs()[0]);dir.mkdirs();
  int n=0, m=0, g=0;
  try(PrintWriter out=new PrintWriter(new File(dir,"v84_ai_field_instructions.tsv"),"UTF-8");PrintWriter gout=new PrintWriter(new File(dir,"v84_fsm_global_access_instructions.tsv"),"UTF-8")){
   out.println("field\taddress\tfunction\tmnemonic\toperand0\toperand1\taddressed_instruction");
   gout.println("global\taddress\tfunction\tmnemonic\toperand0\toperand1\taddressed_instruction");
   InstructionIterator iter=currentProgram.getListing().getInstructions(true);
   while(iter.hasNext()){
    Instruction ins=iter.next();n++;
    String op0=ins.getNumOperands()>0?ins.getDefaultOperandRepresentation(0):"";
    String op1=ins.getNumOperands()>1?ins.getDefaultOperandRepresentation(1):"";
    String all=ins.toString().toLowerCase(Locale.ROOT);String which=String.format("%s",ins.getAddress());
    Function fn=getFunctionContaining(ins.getAddress());String name=fn==null?"<outside>":fn.getName();
    for(String disp:DISPS){if(all.matches(".*(?<![0-9a-f])(?:0x)?"+disp+"(?![0-9a-f]).*")){out.println(disp+"\t"+which+"\t"+name+"\t"+ins.getMnemonicString()+"\t"+clean(op0)+"\t"+clean(op1)+"\t"+clean(ins.toString()));m++;}}
    for(String adr:GLOBALS){String shortadr=adr.substring(2);if(all.contains(adr)||all.contains(shortadr)|| all.contains("0x"+shortadr)){gout.println(adr+"\t"+which+"\t"+name+"\t"+ins.getMnemonicString()+"\t"+clean(op0)+"\t"+clean(op1)+"\t"+clean(ins.toString()));g++;}}
   }
  }
  try(PrintWriter out=new PrintWriter(new File(dir,"v84_ownership_function_index.tsv"),"UTF-8")){
   out.println("address\tname\tentry\tbodybytes\tcallers");
   for(String at:TARGETS){Address ad=toAddr(at);Function f=currentProgram.getFunctionManager().getFunctionAt(ad);int ref=0;ReferenceIterator it=currentProgram.getReferenceManager().getReferencesTo(ad);while(it.hasNext()){it.next();ref++;}out.println(at+"\t"+(f==null?"UNDEFINED":f.getName())+"\t"+(f==null?"-":f.getEntryPoint())+"\t"+(f==null?0:f.getBody().getNumAddresses())+"\t"+ref);}
  }
  DecompInterface dc=new DecompInterface();dc.openProgram(currentProgram);
  String[] decomp={"0045F0F0","0045EF70","00409850","00409980","004571A0","0040A8A0","0040BA60","00415640","004157A0","00465370","0040B9E0","0040A030","0040A010","0045ED70","0040A740"};
  try(PrintWriter out=new PrintWriter(new File(dir,"v84_focused_native_decomp.txt"),"UTF-8")){
   for(String at:decomp){Function f=currentProgram.getFunctionManager().getFunctionAt(toAddr(at));out.println("\n===== "+at+" "+(f==null?"UNDEFINED":f.getName())+" =====\n");
    if(f!=null){DecompileResults r=dc.decompileFunction(f,65,monitor);out.println(r.decompileCompleted()?r.getDecompiledFunction().getC():"DECOMPILE_FAILED "+r.getErrorMessage());}
   }
  }finally{dc.dispose();}
  println("V84_DONE instructions="+n+" ai_field_matches="+m+" fsm_global_matches="+g);
 }
 private String clean(String s){return s.replace('\t',' ').replace('\n',' ');}
}
