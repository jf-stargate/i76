#!/usr/bin/env python3
"""
Interstate '76 geometry reconstruction corpus probe, v5.

Data-side companion for cgpt_i76exe_export_geometry_reconstruction_deeptrace_v23.java.
It does not claim final semantics. It extracts reconstruction-critical record shapes:
  * ODEF/OBJ 100-byte placement/entity records, including transform basis, position, tail dwords, class byte.
  * RDEF/RSEG kind/count plus 0x18-byte point records as six-float probes.
  * LDEF/OBJ variable-size static/world entity records as string/number probes.
  * TDEF/ZMAP/ZONE terrain sidecar references and active patch layout.
  * Optional route polyline OBJ for visual inspection of RSEG point columns.

Default output root for project work remains /media/neon-remote/prj/i76/scratch_data.
"""
from __future__ import annotations

import argparse
import dataclasses
import json
import math
import os
import struct
import subprocess
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

DEFAULT_ROOT = Path('/media/neon-remote/prj/i76/scratch_data')
CONTAINERS = {'BWD2','WDEF','TDEF','RDEF','ODEF','LDEF','ADEF'}
PAGE_W = 128
PATCH_SIZE_WORLD = 640.0
SAMPLE_SCALE = PATCH_SIZE_WORLD / PAGE_W

@dataclasses.dataclass
class Chunk:
    tag: str
    offset: int
    size: int
    payload_offset: int
    payload_size: int
    parent: str = ''

    @property
    def end(self) -> int:
        return self.offset + self.size

def u32(data: bytes, off: int) -> int:
    return struct.unpack_from('<I', data, off)[0]

def f32(data: bytes, off: int) -> float:
    return struct.unpack_from('<f', data, off)[0]

def fourcc(data: bytes, off: int) -> str:
    return data[off:off+4].decode('ascii', errors='replace')

def clean_tag(tag: str) -> str:
    return tag.replace('\x00','')

def cstr(buf: bytes) -> str:
    return buf.split(b'\0',1)[0].decode('ascii', errors='replace').strip()

def parse_flat(data: bytes, start: int, end: int, parent: str) -> List[Chunk]:
    out = []
    off = start
    while off + 8 <= end:
        tag = fourcc(data, off)
        size = u32(data, off + 4)
        if size < 8 or off + size > end:
            break
        out.append(Chunk(tag, off, size, off+8, size-8, parent))
        off += size
    return out

def parse_tree(data: bytes) -> List[Chunk]:
    roots = parse_flat(data, 0, len(data), '')
    def rec(chunks: List[Chunk]) -> List[Chunk]:
        allc = []
        for c in chunks:
            allc.append(c)
            if clean_tag(c.tag) in CONTAINERS and c.payload_size >= 8:
                kids = parse_flat(data, c.payload_offset, c.end, clean_tag(c.tag))
                if kids:
                    allc.extend(rec(kids))
        return allc
    return rec(roots)

def mission_files(root: Path, filt: str) -> List[Path]:
    files = [p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in {'.msn','.spc','.lvl'}]
    if filt:
        lf = filt.lower()
        files = [p for p in files if lf in p.name.lower() or lf in p.stem.lower()]
    return sorted(files)

def zmap_summary(data: bytes, chunks: List[Chunk]) -> dict:
    for c in chunks:
        if clean_tag(c.tag) == 'ZMAP' and c.payload_size >= 6401:
            active = data[c.payload_offset]
            cells = data[c.payload_offset+1:c.payload_offset+1+6400]
            used = []
            hist = Counter()
            for z in range(80):
                for x in range(80):
                    v = cells[z*80+x]
                    if v != 0xff:
                        used.append((x,z,v)); hist[v]+=1
            if used:
                xs=[u[0] for u in used]; zs=[u[1] for u in used]
                bounds=[min(xs),min(zs),max(xs),max(zs)]
            else:
                bounds=None
            return {'active_count':active,'used_count':len(used),'bounds':bounds,'page_histogram':dict(sorted(hist.items())),'used_cells':used}
    return {'active_count':0,'used_count':0,'bounds':None,'page_histogram':{},'used_cells':[]}

def zone_name(data: bytes, chunks: List[Chunk]) -> str:
    for c in chunks:
        if clean_tag(c.tag) == 'ZONE':
            p = data[c.payload_offset:c.end]
            for off in (1,0,8,9):
                if off < len(p):
                    s = cstr(p[off:])
                    if s and ('.' in s or s.lower().endswith('ter')):
                        return s
            return cstr(p)
    return ''

def finite(v: float) -> bool:
    return math.isfinite(v) and abs(v) < 1e20

def fmtf(v: float) -> str:
    if not finite(v): return ''
    return f'{v:.8g}'

def unpack_floats(data: bytes, off: int, count: int) -> List[float]:
    out=[]
    for i in range(count):
        if off + i*4 + 4 <= len(data): out.append(f32(data, off+i*4))
    return out

def analyze_odef_obj(payload: bytes) -> dict:
    name = cstr(payload[:8])
    basis = unpack_floats(payload, 8, 9)
    pos = unpack_floats(payload, 0x2c, 3)
    tail = [u32(payload, off) if off+4 <= len(payload) else 0 for off in range(0x38, min(len(payload),0x64),4)]
    cls = payload[0x5c] if len(payload) > 0x5c else None
    # Simple matrix diagnostics for detecting transform columns/rows.
    row_lens=[]
    dots=[]
    if len(basis)==9:
        rows=[basis[0:3],basis[3:6],basis[6:9]]
        for r in rows:
            row_lens.append(math.sqrt(sum(x*x for x in r)) if all(finite(x) for x in r) else float('nan'))
        dots=[sum(rows[0][i]*rows[1][i] for i in range(3)), sum(rows[0][i]*rows[2][i] for i in range(3)), sum(rows[1][i]*rows[2][i] for i in range(3))]
    return {'name':name,'basis':basis,'pos':pos,'tail':tail,'class':cls,'row_lens':row_lens,'row_dots':dots}

def write_header(path: Path, header: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(header+'\n', encoding='utf-8')

def append_line(path: Path, fields: Iterable[object]):
    with path.open('a', encoding='utf-8') as f:
        f.write('\t'.join(str(x).replace('\t',' ').replace('\n',' ').replace('\r',' ') for x in fields)+'\n')

def export_rseg_obj(route_obj: Path, route_rows: List[Tuple[str,str,int,int,int,List[float]]]):
    route_obj.parent.mkdir(parents=True, exist_ok=True)
    with route_obj.open('w', encoding='utf-8') as f:
        f.write('# RSEG route/segment probe OBJ. Uses point floats [0], [1], [2] as XYZ probe only.\n')
        vbase = 1
        by_seg = defaultdict(list)
        for corpus, mission, rseg_idx, kind, point_idx, vals in route_rows:
            if len(vals) >= 3 and all(finite(v) for v in vals[:3]):
                by_seg[(corpus, mission, rseg_idx)].append((vals[0], vals[1], vals[2]))
        for key, pts in by_seg.items():
            if len(pts) < 2: continue
            f.write(f'o {key[0]}_{key[1]}_rseg_{key[2]}\n')
            for x,y,z in pts:
                f.write(f'v {x:.6f} {z:.6f} {y:.6f}\n')
            idxs = list(range(vbase, vbase+len(pts)))
            f.write('l ' + ' '.join(str(i) for i in idxs) + '\n')
            vbase += len(pts)

def odef_class_case(cls: int | None) -> str:
    if cls is None or cls == 0 or cls > 0x53:
        return 'invalid'
    if cls == 0x01:
        return 'case0_spawn_regen_or_child'
    if cls in (0x02,0x03,0x04,0x07,0x0a,0x0b,0x0c,0x50,0x52,0x53):
        return 'vehicle_or_resource_path'
    if cls in (0x05,0x06) or (0x0d <= cls <= 0x4f) or cls == 0x51:
        return 'case7_fallback_or_defaultish'
    if cls in (0x08,0x09):
        return 'case3_child_special'
    return 'mapped_other'

def write_odef_axes_obj(path: Path, rows: list[dict], scale: float = 80.0) -> None:
    with path.open('w', encoding='utf-8') as f:
        f.write('# ODEF placement basis-axis probe, not final geometry\n')
        vi = 1
        for r in rows:
            name = r['name'].replace(' ', '_') or 'obj'
            px,py,pz = r['pos']
            b = r['basis']
            f.write(f'o {r["corpus"]}_{r["mission"]}_{r["idx"]}_{name}\n')
            f.write(f'v {px:.6f} {pz:.6f} {py:.6f}\n')
            # basis rows as local axes in x/z/y OBJ space
            axes = [(b[0],b[1],b[2]), (b[3],b[4],b[5]), (b[6],b[7],b[8])]
            for ax in axes:
                f.write(f'v {px + ax[0]*scale:.6f} {pz + ax[2]*scale:.6f} {py + ax[1]*scale:.6f}\n')
            f.write(f'l {vi} {vi+1}\n')
            f.write(f'l {vi} {vi+2}\n')
            f.write(f'l {vi} {vi+3}\n')
            vi += 4

def export_rseg_interpretation_objs(out: Path, rows: list[tuple]) -> None:
    # rows: corpus, mission, rseg_index, kind, point_index, vals
    grouped = defaultdict(list)
    for cname,mission,ridx,kind,pi,vals in rows:
        grouped[(cname,mission,ridx,kind)].append((pi,vals))
    modes = {
        'center_f0f3_f1f5': lambda v: ((v[0]+v[3])*0.5, (v[1]+v[5])*0.5, v[4]),
        'left_f0_f1': lambda v: (v[0], v[1], v[4]),
        'right_f3_f5': lambda v: (v[3], v[5], v[4]),
        'pair_edges': None,
    }
    for mode, fn in modes.items():
        p = out / f'rdef_rseg_{mode}.obj'
        with p.open('w', encoding='utf-8') as f:
            f.write(f'# RSEG interpretation probe {mode}; not final semantics\n')
            vi=1
            for key, pts in grouped.items():
                cname,mission,ridx,kind=key
                pts=sorted(pts)
                if len(pts) < 2: continue
                f.write(f'o {cname}_{mission}_rseg{ridx}_kind{kind}\n')
                if mode != 'pair_edges':
                    inds=[]
                    for _,vals in pts:
                        x,z,y = fn(vals)
                        f.write(f'v {x:.6f} {z:.6f} {y:.6f}\n')
                        inds.append(vi); vi += 1
                    f.write('l ' + ' '.join(str(i) for i in inds) + '\n')
                else:
                    # Per record crossbar from left to right candidate edge.
                    for _,vals in pts:
                        f.write(f'v {vals[0]:.6f} {vals[1]:.6f} {vals[4]:.6f}\n')
                        f.write(f'v {vals[3]:.6f} {vals[5]:.6f} {vals[4]:.6f}\n')
                        f.write(f'l {vi} {vi+1}\n')
                        vi += 2

def run(args) -> dict:
    out = args.out_dir or (DEFAULT_ROOT / 'i76_geometry_reconstruction_corpus_probe_v6')
    out.mkdir(parents=True, exist_ok=True)
    dbg = out / 'debug'
    dbg.mkdir(exist_ok=True)

    paths = {
        'mission_summary': out/'mission_geometry_summary.tsv',
        'odef': out/'odef_obj_records.tsv',
        'odef_classes': out/'odef_class_histogram.tsv',
        'rseg': out/'rdef_rseg_records.tsv',
        'rseg_points': dbg/'rdef_rseg_points_sample.tsv',
        'ldef': out/'ldef_obj_records.tsv',
        'tdef': out/'tdef_zmap_zone_summary.tsv',
        'odef_semantic': out/'odef_obj_semantic_records.tsv',
        'rseg_interp': out/'rdef_rseg_interpretation_points.tsv',
        'odef_class0': out/'odef_class0_invalid_or_special_records.tsv',
        'rseg_width_stats': out/'rdef_rseg_width_stats.tsv',
        'ldef_size_histogram': out/'ldef_obj_size_histogram.tsv',
    }
    write_header(paths['mission_summary'], 'corpus\tmission\tpath\tchunk_count\todef_obj_count\trseg_count\trseg_point_count\tldef_obj_count\tzmap_active\tzmap_used\tzmap_bounds\tzone')
    write_header(paths['odef'], 'corpus\tmission\tobj_index\tchunk_offset\tname\tclass_dec\tclass_hex\tpos_x\tpos_y\tpos_z\tbasis_0\tbasis_1\tbasis_2\tbasis_3\tbasis_4\tbasis_5\tbasis_6\tbasis_7\tbasis_8\trow_len_0\trow_len_1\trow_len_2\trow_dot_01\trow_dot_02\trow_dot_12\ttail_dwords_hex')
    write_header(paths['odef_classes'], 'corpus\tclass_dec\tclass_hex\tcount\tnames_sample')
    write_header(paths['rseg'], 'corpus\tmission\trseg_index\tchunk_offset\tkind\tcount\tpayload_size\texpected_size\tsize_match\tfirst6_float\tlast6_float')
    write_header(paths['rseg_points'], 'corpus\tmission\trseg_index\tkind\tpoint_index\tf0\tf1\tf2\tf3\tf4\tf5\traw_hex')
    write_header(paths['ldef'], 'corpus\tmission\tobj_index\tchunk_offset\tpayload_size\tname_guess\tfirst16_hex\tfirst12_float')
    write_header(paths['tdef'], 'corpus\tmission\tactive_count\tused_count\tbounds\tzone\tused_cells_json')
    write_header(paths['odef_semantic'], 'corpus\tmission\tobj_index\tname\tclass_dec\tclass_hex\tdispatch_case\tpos_x\tpos_y\tpos_z\tbasis_rows_json\ttail_dwords_hex')
    write_header(paths['rseg_interp'], 'corpus\tmission\trseg_index\tkind\tpoint_index\tleft_x_f0\tleft_z_f1\tright_x_f3\tright_z_f5\theight_or_y_f4\tcenter_x\tcenter_z\tf2_raw')
    write_header(paths['odef_class0'], 'corpus\tmission\tobj_index\tname\tpos_x\tpos_y\tpos_z\ttail_dwords_hex\tnote')
    write_header(paths['rseg_width_stats'], 'corpus\tmission\tkind\tpoint_count\twidth_min\twidth_avg\twidth_max\theight_min\theight_avg\theight_max')
    write_header(paths['ldef_size_histogram'], 'corpus\tmission\tname_guess\tpayload_size\tcount')

    class_hist = defaultdict(Counter)
    class_names = defaultdict(lambda: defaultdict(Counter))
    route_rows=[]
    rseg_stat_rows=[]
    ldef_hist=Counter()
    odef_axis_rows=[]
    manifest = {'format':'i76_geometry_reconstruction_corpus_probe','version':6,'corpora':{},'warnings':[]}

    corpora=[]
    if args.miss8: corpora.append(('miss8', args.miss8))
    if args.miss16: corpora.append(('miss16', args.miss16))
    if args.input: corpora.append(('input', args.input))

    for cname, root in corpora:
        files = mission_files(root, args.mission_filter)
        manifest['corpora'][cname]={'root':str(root),'missions_seen':len(files)}
        for mp in files:
            try:
                data = mp.read_bytes(); chunks = parse_tree(data)
                mission = mp.stem.lower()
                zsum = zmap_summary(data, chunks); zname = zone_name(data, chunks)
                odef_count=rseg_count=rseg_point_count=ldef_count=0
                for c in chunks:
                    tag=clean_tag(c.tag); parent=clean_tag(c.parent)
                    payload=data[c.payload_offset:c.end]
                    if parent=='ODEF' and tag=='OBJ' and len(payload)>=0x64:
                        odef_count += 1
                        rec=analyze_odef_obj(payload)
                        cls=rec['class']; class_hist[cname][cls]+=1; class_names[cname][cls][rec['name']]+=1
                        append_line(paths['odef'], [cname,mission,odef_count-1,f'0x{c.offset:08x}',rec['name'],cls if cls is not None else '',f'0x{cls:02x}' if cls is not None else '',*(fmtf(v) for v in rec['pos']),*(fmtf(v) for v in rec['basis']),*(fmtf(v) for v in rec['row_lens']),*(fmtf(v) for v in rec['row_dots']),' '.join(f'0x{x:08x}' for x in rec['tail'])])
                        append_line(paths['odef_semantic'], [cname,mission,odef_count-1,rec['name'],cls if cls is not None else '',f'0x{cls:02x}' if cls is not None else '',odef_class_case(cls),*(fmtf(v) for v in rec['pos']),json.dumps([rec['basis'][0:3],rec['basis'][3:6],rec['basis'][6:9]]),' '.join(f'0x{x:08x}' for x in rec['tail'])])
                        odef_axis_rows.append({'corpus':cname,'mission':mission,'idx':odef_count-1,'name':rec['name'],'class':cls,'pos':rec['pos'],'basis':rec['basis']})
                        if cls == 0:
                            append_line(paths['odef_class0'], [cname,mission,odef_count-1,rec['name'],*(fmtf(v) for v in rec['pos']),' '.join(f'0x{x:08x}' for x in rec['tail']),'class byte zero; dispatch-invalid, likely alternate/special/disabled record'])
                    elif parent=='RDEF' and tag=='RSEG' and len(payload)>=8:
                        rseg_count += 1
                        kind=u32(payload,0); cnt=u32(payload,4); exp=8+cnt*0x18
                        rseg_point_count += cnt
                        first=unpack_floats(payload,8,6) if len(payload)>=8+24 else []
                        last=unpack_floats(payload,8+(cnt-1)*24,6) if cnt and len(payload)>=8+cnt*24 else []
                        append_line(paths['rseg'], [cname,mission,rseg_count-1,f'0x{c.offset:08x}',kind,cnt,len(payload),exp,len(payload)==exp,','.join(fmtf(v) for v in first),','.join(fmtf(v) for v in last)])
                        # Full per-segment geometry stats for the paired edge interpretation.
                        widths=[]; hs=[]
                        for spi in range(cnt):
                            off2=8+spi*24
                            if off2+24 <= len(payload):
                                vals2=unpack_floats(payload,off2,6)
                                widths.append(math.sqrt((vals2[3]-vals2[0])*(vals2[3]-vals2[0]) + (vals2[5]-vals2[1])*(vals2[5]-vals2[1])))
                                hs.append(vals2[4])
                        if widths:
                            append_line(paths['rseg_width_stats'], [cname,mission,kind,len(widths),fmtf(min(widths)),fmtf(sum(widths)/len(widths)),fmtf(max(widths)),fmtf(min(hs)),fmtf(sum(hs)/len(hs)),fmtf(max(hs))])
                        sample_limit=min(cnt,args.max_rseg_points_per_segment)
                        for pi in range(sample_limit):
                            off=8+pi*24
                            raw=payload[off:off+24]
                            vals=unpack_floats(payload,off,6)
                            append_line(paths['rseg_points'], [cname,mission,rseg_count-1,kind,pi,*(fmtf(v) for v in vals),raw.hex(' ')])
                            append_line(paths['rseg_interp'], [cname,mission,rseg_count-1,kind,pi,fmtf(vals[0]),fmtf(vals[1]),fmtf(vals[3]),fmtf(vals[5]),fmtf(vals[4]),fmtf((vals[0]+vals[3])*0.5),fmtf((vals[1]+vals[5])*0.5),fmtf(vals[2])])
                            route_rows.append((cname,mission,rseg_count-1,kind,pi,vals))
                    elif parent=='LDEF' and tag=='OBJ':
                        ldef_count += 1
                        ng=cstr(payload[:16])
                        floats=unpack_floats(payload,0,min(12,len(payload)//4))
                        append_line(paths['ldef'], [cname,mission,ldef_count-1,f'0x{c.offset:08x}',len(payload),ng,payload[:16].hex(' '),','.join(fmtf(v) for v in floats)])
                        ldef_hist[(cname,mission,ng,len(payload))] += 1
                append_line(paths['mission_summary'], [cname,mission,str(mp),len(chunks),odef_count,rseg_count,rseg_point_count,ldef_count,zsum['active_count'],zsum['used_count'],json.dumps(zsum['bounds']),zname])
                append_line(paths['tdef'], [cname,mission,zsum['active_count'],zsum['used_count'],json.dumps(zsum['bounds']),zname,json.dumps([{'x':x,'z':z,'page':p} for x,z,p in zsum['used_cells']])])
            except Exception as e:
                manifest['warnings'].append(f'{cname}:{mp}: {type(e).__name__}: {e}')
    for cname,hist in class_hist.items():
        for cls,count in sorted(hist.items(), key=lambda kv: (-kv[1], kv[0] if kv[0] is not None else -1)):
            names=','.join(name for name,_ in class_names[cname][cls].most_common(12))
            append_line(paths['odef_classes'], [cname, cls if cls is not None else '', f'0x{cls:02x}' if cls is not None else '', count, names])
    for (cname,mission,ng,psz),count in sorted(ldef_hist.items()):
        append_line(paths['ldef_size_histogram'], [cname,mission,ng,psz,count])
    write_odef_axes_obj(out/'odef_object_basis_axes_probe.obj', odef_axis_rows)
    if args.write_rseg_obj:
        export_rseg_obj(out/'rdef_rseg_points_probe.obj', route_rows)
        export_rseg_interpretation_objs(out, route_rows)
    manifest['outputs']={k:str(v) for k,v in paths.items()}
    manifest['outputs']['odef_axes_obj']=str(out/'odef_object_basis_axes_probe.obj')
    if args.write_rseg_obj: manifest['outputs']['rseg_obj']=str(out/'rdef_rseg_points_probe.obj')
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    if args.make_tar:
        subprocess.run(['tar','-cf',out.name+'.tar',out.name],cwd=str(out.parent),check=False)
    return manifest

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--miss8', type=Path)
    ap.add_argument('--miss16', type=Path)
    ap.add_argument('--input', type=Path)
    ap.add_argument('--out-dir', type=Path)
    ap.add_argument('--mission-filter', default='')
    ap.add_argument('--max-rseg-points-per-segment', type=int, default=32)
    ap.add_argument('--write-rseg-obj', action='store_true')
    ap.add_argument('--make-tar', action='store_true')
    args=ap.parse_args()
    if not (args.miss8 or args.miss16 or args.input):
        ap.error('provide --miss8, --miss16, or --input')
    manifest=run(args)
    print(json.dumps({'outputs':manifest.get('outputs',{}),'warnings':len(manifest.get('warnings',[]))},indent=2))
    return 0
if __name__=='__main__':
    raise SystemExit(main())
