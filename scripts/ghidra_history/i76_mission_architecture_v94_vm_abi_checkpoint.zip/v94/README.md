# v94 retail mission VM ABI research checkpoint

Read `V94_VM_CALL_FRAMES_OPERAND_STACK_AND_BYTECODE_VALIDITY.md` for the findings, limits, and exact evidence.

- `v94_native_decompiled.txt`: native decompiler output for 17 requested functions; includes the two auxiliary FSM table loaders.
- `v94_instruction_windows.tsv`: actual x86 instruction listing to cross-check decompiler interpretations.
- `v94_function_callers.tsv`, `v94_node_field_uses.tsv`, `v94_symbols.tsv`: read-only reference and field evidence.
- `v94_shipped_mission_fsm_inventory.tsv`, `v94_shipped_mission_fsm_summary.json`: 40 miss8 mission files, 25 nonempty FSM chunks, 90,923 tokens.
- `v94_miss8_miss16_fsm_comparison.tsv`, `v94_resource_variant_comparison_summary.json`: paired comparison of all 40 miss8/miss16 mission FSM chunks.
- `v94_static_validation.json`: 45 static and corpus inspection checks; these are **not** live gameplay tests.
- `i76_v94_fsm_frame_and_validation.java`: Ghidra read-only script. Verify MD5 before running. Supply output directory as its first script argument.
- `v94_inspect_shipped_fsm.py`: read-only mission chunk inspector. Extract user's licensed `miss8/*.MSN` files alongside script into `shipped_missions/` before running. No game assets are included in this checkpoint.
- `v94_compare_resource_variants.py`: additionally extract licensed `miss16/*.MSN` into `shipped_missions16/`.
- `v94_verify_static_and_corpus.py`: reproducible verification of saved evidence and read-only inspector edge cases.

Source Ghidra annotated baseline v92 imported into disposable v93 project and processed read-only. **No Ghidra symbol edits**, no gameplay execution, and no engine reimplementation.
