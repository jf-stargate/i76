#!/usr/bin/env python3
"""Compare FSM chunks from extracted miss8/ and miss16/ files; read-only corpus analysis."""
import struct, csv, json, hashlib
from pathlib import Path
from contextlib import redirect_stdout
import io
ROOT=Path(__file__).parent
with redirect_stdout(io.StringIO()):
    import v94_inspect_shipped_fsm as inspector

def chunk(file):
    b=file.read_bytes(); i=b.rfind(b'FSM\x00')
    if i<0:raise ValueError(f'{file}: no FSM marker')
    sz=struct.unpack_from('<I',b,i+4)[0]
    if sz<8 or i+sz>len(b):raise ValueError(f'{file}: malformed FSM length')
    return b[i+8:i+sz]
rows=[]
for f8 in sorted((ROOT/'shipped_missions').glob('*.MSN')):
    f16=ROOT/'shipped_missions16'/f8.name
    if not f16.exists():continue
    a,b=chunk(f8),chunk(f16)
    parsed_a=inspector.parse(a) if a else None
    parsed_b=inspector.parse(b) if b else None
    rows.append(dict(file=f8.name,chunk_identical=a==b,token_stream_identical=parsed_a['code']==parsed_b['code'] if parsed_a else not b,
      initial_execution_nodes_identical=parsed_a['nodeinfo']==parsed_b['nodeinfo'] if parsed_a else not b,
      fsm_size8=len(a),fsm_size16=len(b),different_bytes=sum(x!=y for x,y in zip(a,b))+abs(len(a)-len(b))))
with (ROOT/'v94_miss8_miss16_fsm_comparison.tsv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
result=dict(paired_missions=len(rows),byte_identical_chunks=sum(r['chunk_identical'] for r in rows),matching_token_streams=sum(r['token_stream_identical'] for r in rows),matching_execution_nodes=sum(r['initial_execution_nodes_identical'] for r in rows),variants=[r for r in rows if not r['chunk_identical']])
(ROOT/'v94_resource_variant_comparison_summary.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
