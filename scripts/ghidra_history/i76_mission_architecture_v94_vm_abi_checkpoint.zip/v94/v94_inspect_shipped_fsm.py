#!/usr/bin/env python3
"""Read-only structural inspection of shipped I76 BWD2 FSM chunks; not an emulator."""
from pathlib import Path
from collections import Counter
import struct, csv, json
ROOT=Path(__file__).with_name('shipped_missions')
OUT=Path(__file__).parent

def chunks(blob):
    pos=0
    while pos+8<=len(blob):
        tag=blob[pos:pos+4]; size=struct.unpack_from('<I',blob,pos+4)[0]
        if size<8 or size+pos>len(blob): raise ValueError(f'chunk at {pos}: size {size}, remaining {len(blob)-pos}')
        yield tag,pos,size,blob[pos+8:pos+size]
        pos+=size
    if pos!=len(blob): raise ValueError(f'trailing {len(blob)-pos}')

class Reader:
    def __init__(self,buf): self.b=buf;self.i=0
    def u32(self):
        if self.i+4>len(self.b):raise ValueError(f'Fsm stream EOF offset={self.i}, length={len(self.b)}')
        v=struct.unpack_from('<I',self.b,self.i)[0];self.i+=4;return v
    def read_u32(self,n):
        if n>250_000 or self.i+4*n>len(self.b):raise ValueError(f'Invalid count {n} offset={self.i} length={len(self.b)}')
        i=self.i;self.i+=4*n
        return struct.unpack_from(f'<{n}I',self.b,i) if n else ()

def parse(buf):
    x=Reader(buf)
    commands=x.u32();x.read_u32(commands*10)
    actors=x.u32();x.read_u32(actors*12)
    media=x.u32();x.read_u32(media*10)
    positions=x.u32(); vec_tot=0
    for _ in range(positions):
        x.read_u32(10); nv=x.u32();vec_tot+=nv;x.read_u32(nv*3)
    nodes=x.u32(); nodeinfo=[]
    for _ in range(nodes):
        entry=x.u32(); locals_count=x.u32(); data=x.read_u32(40)
        nodeinfo.append((entry,locals_count,data))
    words=x.u32();x.read_u32(words)
    tokens=x.u32();tokwords=x.read_u32(tokens*2)
    instr=[(tokwords[i],tokwords[i+1]) for i in range(0,len(tokwords),2)]
    hist=Counter(k for k,p in instr)
    bad_kind=[(i,k,p) for i,(k,p) in enumerate(instr) if not 1<=k<=14]
    bad_target=[(i,k,p) for i,(k,p) in enumerate(instr) if k in (8,9,10,11) and p>=tokens]
    bad_host=[(i,k,p) for i,(k,p) in enumerate(instr) if k==13 and p>=commands]
    bad_nodes=[(i,a,b) for i,(a,b,_) in enumerate(nodeinfo) if a>=tokens or b>40]
    bad_relocations=[(i,k,value,words) for i,(_entry,count,values) in enumerate(nodeinfo) for k,value in enumerate(values[:count]) if value>=words]
    return dict(commands=commands, actors=actors,media=media,positions=positions,position_vectors=vec_tot,
         nodes=nodes,initial_words=words,tokens=tokens,token_hist=hist, bad_kind=bad_kind,bad_targets=bad_target,
         bad_hosts=bad_host,bad_node_entries=bad_nodes,bad_relocations=bad_relocations,unconsumed=len(buf)-x.i, max_init_context=max((z[1] for z in nodeinfo),default=0),
         code=instr,nodeinfo=nodeinfo)

summary=[]; allcodes=Counter(); issues=[]
for f in sorted(ROOT.glob('*.MSN')):
 try:
  data=f.read_bytes(); off=data.rfind(b'FSM\0'); fs=[]
  if off>=0 and off+8<=len(data):
   size=struct.unpack_from('<I',data,off+4)[0]
   if size>=8 and off+size<=len(data):fs=[(off,size,data[off+8:off+size])]
  if not fs:raise ValueError('no FSM section')
  o,size,pay=fs[0]
  result=parse(pay) if pay else None
  if result:
   code=result.pop('code');result.pop('nodeinfo')
   allcodes.update(result['token_hist'])
  row=dict(file=f.name,file_size=len(data),fsm_offset=o,fsm_size=size,has_fsm=bool(pay),**(result or {}))
  summary.append(row)
  if result and (result['bad_kind'] or result['bad_targets'] or result['bad_hosts'] or result['bad_node_entries'] or result['bad_relocations'] or result['unconsumed']):
    issues.append({k:row[k] for k in ('file','bad_kind','bad_targets','bad_hosts','bad_node_entries','bad_relocations','unconsumed')})
 except Exception as ex: issues.append({'file':f.name,'parser_error':str(ex)})
with open(OUT/'v94_shipped_mission_fsm_inventory.tsv','w') as h:
 fields=['file','file_size','fsm_offset','fsm_size','has_fsm','commands','actors','media','positions','position_vectors','nodes','initial_words','tokens','max_init_context','unconsumed','bad_kind','bad_targets','bad_hosts','bad_node_entries','bad_relocations']
 w=csv.DictWriter(h,fieldnames=fields,delimiter='\t');w.writeheader();w.writerows([{k:v for k,v in d.items() if k in fields} for d in summary])
out=dict(files=len(summary),scripted_missions=sum(x['has_fsm'] for x in summary),empty_missions=sum(not x['has_fsm'] for x in summary),
  max_nodes=max((x.get('nodes',0) for x in summary),default=0),max_initial_frame_words=max((x.get('max_init_context',0) for x in summary),default=0),max_token_count=max((x.get('tokens',0) for x in summary),default=0),aggregate_vm_kinds=dict(sorted(allcodes.items())),issues=issues)
(OUT/'v94_shipped_mission_fsm_summary.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2)[:2000])
