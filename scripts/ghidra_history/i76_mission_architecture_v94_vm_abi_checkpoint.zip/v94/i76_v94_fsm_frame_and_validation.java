// Ghidra 12.1.4 read-only. i76.exe retail FSM loader/VM frame and validity evidence.
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.address.*;
import ghidra.program.model.symbol.*;
import ghidra.program.model.mem.*;
import java.util.*;
import java.io.*;

public class i76_v94_fsm_frame_and_validation extends GhidraScript {
 static String s(String x){return x.replace('\t',' ').replace('\n',' ').replace('\r',' ');}
 static String q(String x){return x.replace('\t',' ').replace('\n',' ').replace('\r',' ');}
 String where(Address a){Function fn=getFunctionContaining(a);return fn==null?"UNKNOWN":fn.getEntryPoint()+" "+fn.getName();}
 public void run() throws Exception{
  if(!"a640ea0097dbb62e0c77b7f2847c7161".equalsIgnoreCase(currentProgram.getExecutableMD5())) throw new Exception("Wrong executable");
  File d=new File(getScriptArgs()[0]);d.mkdirs();
  String[] targets={"00409740","004102d0","004105a0","00410490","00410720","00410a10","00410a50","00412400","00412500","004125c0","00412ce0","00414670","004149f0","0040a320","004155f0","00402620","00458f40","0040b320"};
  DecompInterface di=new DecompInterface();di.openProgram(currentProgram);
  int ok=0, fail=0;
  try(PrintWriter w=new PrintWriter(new File(d,"v94_native_decompiled.txt"),"UTF-8");
      PrintWriter a=new PrintWriter(new File(d,"v94_instruction_windows.tsv"),"UTF-8")){
   a.println("function\taddress\tmnemonic\toperands\tbytes");
   for(String t:targets){
    Function f=getFunctionAt(toAddr(t));w.println("\n===== "+t+" "+(f==null?"UNDEFINED":f.getName())+" =====");
    if(f==null)continue;
    DecompileResults z=di.decompileFunction(f,35,monitor);
    if(z.decompileCompleted()&&z.getDecompiledFunction()!=null){w.println(z.getDecompiledFunction().getC());ok++;}else{w.println("ERROR "+z.getErrorMessage());fail++;}
    InstructionIterator it=currentProgram.getListing().getInstructions(f.getBody(),true);
    int n=0;while(it.hasNext() && n<5000){Instruction i=it.next(); String bytes="";
     try{byte[] bb=i.getBytes();StringBuilder sb=new StringBuilder();for(byte b:bb)sb.append(String.format("%02X",b&255));bytes=sb.toString();}catch(Exception e){}
     a.println(t+"\t"+i.getAddress()+"\t"+i.getMnemonicString()+"\t"+q(i.toString())+"\t"+bytes);n++;}
   }
  }
  di.dispose();
  String[] watch={"00414670","00410720","00410490","00412500","004125c0","00410a10","00409740","00412ce0"};
  try(PrintWriter w=new PrintWriter(new File(d,"v94_function_callers.tsv"),"UTF-8")){
   w.println("target\tcallsite\tcaller\tref_type");
   for(String t:watch){for(Reference r:currentProgram.getReferenceManager().getReferencesTo(toAddr(t))){w.println(t+"\t"+r.getFromAddress()+"\t"+where(r.getFromAddress())+"\t"+r.getReferenceType());}}
  }
  // Enumerate all direct memory-operand references to node fields and serialization state globals.
  String[] fields={"0x1000","0x109c","0x10a0","0x10a4","0x10a8","0x10ac","0x10b0","0x10b4","0x10b8","0x10bc","0x42a","0x42b","0x42c","0x42d","0x42e"};
  try(PrintWriter w=new PrintWriter(new File(d,"v94_node_field_uses.tsv"),"UTF-8")){
   w.println("field\taddress\tfunction\tinstruction");InstructionIterator it=currentProgram.getListing().getInstructions(true);int scanned=0,hits=0;
   while(it.hasNext()){Instruction i=it.next();scanned++;String dis=i.toString().toLowerCase(Locale.ROOT);
     for(String field:fields){if(dis.matches(".*(?<![a-z0-9])"+field+"(?![a-z0-9]).*")){w.println(field+"\t"+i.getAddress()+"\t"+where(i.getAddress())+"\t"+s(i.toString()));hits++;}}
   } println("V94_uses scanned="+scanned+" hits="+hits);
  }
  try(PrintWriter w=new PrintWriter(new File(d,"v94_symbols.tsv"),"UTF-8")){
   w.println("address\tsymbol\tfunction");
   String[] globs={"0051f5b4","0051f608","0051f628","0051f62c","0051f630","0051f634","0051f638","0051f63c","005244dc","004bc20c"};
   for(String v:globs){Address ad=toAddr(v);Symbol sym=currentProgram.getSymbolTable().getPrimarySymbol(ad);w.println(v+"\t"+(sym==null?"NONE":sym.getName())+"\t"+where(ad));}
  }
  println("V94_DONE decompiled_ok="+ok+" failed="+fail+" functions="+currentProgram.getFunctionManager().getFunctionCount());
 }
}
