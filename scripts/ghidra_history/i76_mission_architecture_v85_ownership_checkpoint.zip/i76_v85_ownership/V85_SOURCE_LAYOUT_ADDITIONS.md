# v85 provisional source-layout additions (separate from binary-proven architecture)

These are hypotheses about original link/source-unit neighborhood, **not** claims that original filenames or translation-unit boundaries survive.

| Binary address window | Evidence | Possible source grouping | Confidence |
|---|---|---|---|
| 0049EAD0–0049F1D0 | explosion spawn / get effect source / recycle, shared hash cache | Explosion effects module | Moderate |
| 0049F210–0049F470 | muzzle flash acquire, per-frame update, cleanup | Muzzle flash module | Moderate |
| 0049F5C0–004A0Bxx | ordnance definitions, root registry, spawn, source/target addref, linked-list retirement | Ordnance instance management | Moderate-High for broad neighborhood, Low for one TU |
| 004A7190–004A8240 | ordnance effect selection, source accessor, radial and direct damage | Ordnance / damage adapter modules | Moderate for neighborhood |
| 004A92E0–004AD11E | many ordnance category-specific behavior callbacks share runtime arrays | Ordnance behavior handlers | Moderate |
| 00461970–00461Dxx | class callback table, addref, queue update, pre/post dispatch | Class runtime/dispatcher | Moderate-High |
| 00425E60–004260xx | audio object holder and resource release, separate from 00421400–004226xx | Audio instance lifetime | Low on TU boundaries |
| 00443C90–004440xx | flamer emitter acquired tree holds, incremental update and destruction | Flame effect module | Moderate-High |

The source-layout ledger must retain separate fields for **binary-proven associations** (addresses, actual calls, shared globals and neighboring functions) and **inferred original translation-unit memberships**. No source files are reconstructed in this phase.
