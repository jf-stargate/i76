// @category I76
// I76 v85 read-only: owner-path decompilation, indexed addref/release callers, function data xrefs.
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.address.*;
import ghidra.program.model.symbol.*;
import java.util.*;
import java.io.*;

public class i76_v85_ownership_followup extends GhidraScript {
 static final String[] FNS={
 "0049F790",
 "0049FB40",
 "0049EFE0",
 "0049F100",
 "0049F2F0",
 "0049F470",
 "004A0990",
 "004A7370",
 "004A92E0",
 "004AA150",
 "004AA2D0",
 "004AA450",
 "004AA5B0",
 "004AA9F0",
 "004AB1C0",
 "004ABE60",
 "004AC3D0",
 "004AC800",
 "004ACE20",
 "0049F5C0",
 "004A0AE0",
 "004A7C80",
 "004A8240",
 "004A7350",
 "0045F0F0",
 "0045EF70",
 "00425E60",
 "004217E0",
 "00422540",
 "004413B0",
 "0044B030",
 "004614E0",
 "00461570",
 "004618E0",
 "004639A0",
 "004A0410",
 "004A0480",
 "0049F1D0",
 "0046EDC0"
 };
 static final String[] TARGETS={"0045ED00","0045ED70","0045EF70","0045F0F0","004572B0","00457420","00461970","00461B80","004A0AE0","004157A0"};
 public void run()throws Exception {
  if(!"a640ea0097dbb62e0c77b7f2847c7161".equalsIgnoreCase(currentProgram.getExecutableMD5()))throw new IllegalStateException("Wrong executable");
  File dest=new File(getScriptArgs()[0]);dest.mkdirs();
  try(PrintWriter o=new PrintWriter(new File(dest,"v85_followup_reference_sites.tsv"),"UTF-8")){
   o.println("target\ttarget_name\tref_address\tref_function\tref_type\tinstruction");
   for(String a:TARGETS){Address adr=toAddr(a);Function f=getFunctionAt(adr);ReferenceIterator refs=currentProgram.getReferenceManager().getReferencesTo(adr);while(refs.hasNext()){
     Reference r=refs.next();Function from=getFunctionContaining(r.getFromAddress());Instruction ins=getInstructionContaining(r.getFromAddress());
     o.println(a+"\t"+(f==null?"?":f.getName())+"\t"+r.getFromAddress()+"\t"+(from==null?"OUTSIDE":from.getEntryPoint()+":"+from.getName())+"\t"+r.getReferenceType()+"\t"+(ins==null?"":sanitize(ins.toString())));
    }}
  }
  try(PrintWriter o=new PrintWriter(new File(dest,"v85_followup_function_index.tsv"),"UTF-8")){
   o.println("address\tname\tbody_bytes\tdirect_call_count\tfrom_ref_count");
   for(String at:FNS){Address ad=toAddr(at);Function f=getFunctionAt(ad);int cc=0;int rc=0;if(f!=null){for(InstructionIterator i=currentProgram.getListing().getInstructions(f.getBody(),true);i.hasNext();){Instruction in=i.next();if(in.getFlowType().isCall())cc++;}}ReferenceIterator it=currentProgram.getReferenceManager().getReferencesTo(ad);while(it.hasNext()){it.next();rc++;}o.println(at+"\t"+(f==null?"UNDEFINED":f.getName())+"\t"+(f==null?0:f.getBody().getNumAddresses())+"\t"+cc+"\t"+rc);}
  }
  DecompInterface d=new DecompInterface();d.openProgram(currentProgram);int ok=0;
  try(PrintWriter o=new PrintWriter(new File(dest,"v85_followup_native_decompiled.txt"),"UTF-8")){
   for(String at:FNS){Function f=getFunctionAt(toAddr(at));o.println("\n===== "+at+" "+(f==null?"UNDEFINED":f.getName())+" =====\n");if(f!=null){DecompileResults r=d.decompileFunction(f,90,monitor);if(r.decompileCompleted()){o.println(r.getDecompiledFunction().getC());ok++;}else{o.println("DECOMPILE_FAILED: "+r.getErrorMessage());}}}
  }finally{d.dispose();}
  println("V85_FOLLOWUP_DONE decompiled="+ok+" targets="+FNS.length);
 }
 private String sanitize(String s){return s.replace('\t',' ').replace('\n',' ');}
}
