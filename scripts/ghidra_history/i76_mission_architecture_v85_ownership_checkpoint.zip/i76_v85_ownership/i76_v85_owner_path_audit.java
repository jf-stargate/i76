// @category I76
// I76 v85 read-only: owner-path decompilation, indexed addref/release callers, function data xrefs.
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.address.*;
import ghidra.program.model.symbol.*;
import java.util.*;
import java.io.*;

public class i76_v85_owner_path_audit extends GhidraScript {
 static final String[] FNS={
 "00425E60","004217E0","00422540","00425130","00425EF0","00421400",
 "0044AE50","00441310","0048F840","0049EAD0","00461970","00461B80",
 "00461C80","00461D50","004A0AE0","004A7C80","0049F210","004AB920",
 "00443C90","00443E90","00443FC0","0045F6D0","004AE000","00463120",
 "0049F5C0","00465370","00465310","004A0F60","00462A90","004157A0",
 "0045ED00","0045ED70","0045EF70","0045F0F0","0045EBD0","0045F260",
 "004571A0","004572B0","00457420","00409980","00412830",
 "0040AFF0","0040B0F0","0040B1F0","0040A8A0","0040BA60",
 "004A0410","004A8240","004A8210","00462040","004354C0"
 };
 static final String[] TARGETS={"0045ED00","0045ED70","0045EF70","0045F0F0","004572B0","00457420","00461970","00461B80","004A0AE0","004157A0"};
 public void run()throws Exception {
  if(!"a640ea0097dbb62e0c77b7f2847c7161".equalsIgnoreCase(currentProgram.getExecutableMD5()))throw new IllegalStateException("Wrong executable");
  File dest=new File(getScriptArgs()[0]);dest.mkdirs();
  try(PrintWriter o=new PrintWriter(new File(dest,"v85_owner_reference_sites.tsv"),"UTF-8")){
   o.println("target\ttarget_name\tref_address\tref_function\tref_type\tinstruction");
   for(String a:TARGETS){Address adr=toAddr(a);Function f=getFunctionAt(adr);ReferenceIterator refs=currentProgram.getReferenceManager().getReferencesTo(adr);while(refs.hasNext()){
     Reference r=refs.next();Function from=getFunctionContaining(r.getFromAddress());Instruction ins=getInstructionContaining(r.getFromAddress());
     o.println(a+"\t"+(f==null?"?":f.getName())+"\t"+r.getFromAddress()+"\t"+(from==null?"OUTSIDE":from.getEntryPoint()+":"+from.getName())+"\t"+r.getReferenceType()+"\t"+(ins==null?"":sanitize(ins.toString())));
    }}
  }
  try(PrintWriter o=new PrintWriter(new File(dest,"v85_owner_function_index.tsv"),"UTF-8")){
   o.println("address\tname\tbody_bytes\tdirect_call_count\tfrom_ref_count");
   for(String at:FNS){Address ad=toAddr(at);Function f=getFunctionAt(ad);int cc=0;int rc=0;if(f!=null){for(InstructionIterator i=currentProgram.getListing().getInstructions(f.getBody(),true);i.hasNext();){Instruction in=i.next();if(in.getFlowType().isCall())cc++;}}ReferenceIterator it=currentProgram.getReferenceManager().getReferencesTo(ad);while(it.hasNext()){it.next();rc++;}o.println(at+"\t"+(f==null?"UNDEFINED":f.getName())+"\t"+(f==null?0:f.getBody().getNumAddresses())+"\t"+cc+"\t"+rc);}
  }
  DecompInterface d=new DecompInterface();d.openProgram(currentProgram);int ok=0;
  try(PrintWriter o=new PrintWriter(new File(dest,"v85_owner_native_decompiled.txt"),"UTF-8")){
   for(String at:FNS){Function f=getFunctionAt(toAddr(at));o.println("\n===== "+at+" "+(f==null?"UNDEFINED":f.getName())+" =====\n");if(f!=null){DecompileResults r=d.decompileFunction(f,90,monitor);if(r.decompileCompleted()){o.println(r.getDecompiledFunction().getC());ok++;}else{o.println("DECOMPILE_FAILED: "+r.getErrorMessage());}}}
  }finally{d.dispose();}
  println("V85_DONE decompiled="+ok+" targets="+FNS.length);
 }
 private String sanitize(String s){return s.replace('\t',' ').replace('\n',' ');}
}
