# I76 v85 ownership checkpoint

Read-only local Ghidra 12.1.4 on the v81 named retail `i76.exe` baseline. The report and validation JSON are the entry points.

Run each standalone `.java` script from the package as a `-postScript` on the existing imported program using `-readOnly -noanalysis`, passing an output directory. The scripts check the exact retail MD5 before analysis.

The four Ghidra scripts cover (1) prioritized owners, (2) ordnance retirement, (3) effect-source provenance, and (4) incoming explosion callsites. The accompanying TSV and native decompilations are the actual observed output.

No symbols modified, no game executed, no source reconstruction started.
