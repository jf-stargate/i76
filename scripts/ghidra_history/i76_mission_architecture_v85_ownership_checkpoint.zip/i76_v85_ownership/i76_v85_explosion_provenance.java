// @category I76
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.*;
import ghidra.app.decompiler.*;
import java.util.*;
import java.io.*;
public class i76_v85_explosion_provenance extends GhidraScript {
 public void run()throws Exception{
  if(!"a640ea0097dbb62e0c77b7f2847c7161".equalsIgnoreCase(currentProgram.getExecutableMD5())) throw new IllegalStateException("wrong binary");
  File out=new File(getScriptArgs()[0]);out.mkdirs();TreeMap<String,Function> fs=new TreeMap<>();
  String[] targets={"0049EAD0","0049ED70","0049EFE0","004A7C80","004A8240","0049F210","004A05F0","004A0990"};
  try(PrintWriter p=new PrintWriter(new File(out,"v85_explosion_incoming_xrefs.tsv"),"UTF-8")){
   p.println("target\tfrom\tcontaining_function\tref_type\topcode");
   for(String s:targets){ReferenceIterator it=currentProgram.getReferenceManager().getReferencesTo(toAddr(s));while(it.hasNext()){Reference r=it.next();Function f=getFunctionContaining(r.getFromAddress());Instruction i=getInstructionContaining(r.getFromAddress());p.println(s+"\t"+r.getFromAddress()+"\t"+(f==null?"?":f.getEntryPoint()+":"+f.getName())+"\t"+r.getReferenceType()+"\t"+(i==null?"":i.toString()));if(f!=null)fs.put(f.getEntryPoint().toString(),f);}}
  }
  DecompInterface dc=new DecompInterface();dc.openProgram(currentProgram);
  try(PrintWriter p=new PrintWriter(new File(out,"v85_explosion_callers_native_decomp.txt"),"UTF-8")){
   for(Map.Entry<String,Function> x:fs.entrySet()){Function f=x.getValue();p.println("\n==== "+f.getEntryPoint()+" "+f.getName()+" ====");DecompileResults r=dc.decompileFunction(f,90,monitor);p.println(r.decompileCompleted()?r.getDecompiledFunction().getC():"DECOMPILE_FAILED");}
  }finally{dc.dispose();}
  println("V85_EXPLOSION_DONE caller_functions="+fs.size());
 }
}
