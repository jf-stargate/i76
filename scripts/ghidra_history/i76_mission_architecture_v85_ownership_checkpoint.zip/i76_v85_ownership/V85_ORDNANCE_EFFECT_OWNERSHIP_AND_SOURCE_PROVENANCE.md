# I76 v85 — ordnance, effects, and mission damage-source ownership

2026-10-20; research only. Retail `i76.exe`, MD5 `a640ea0097dbb62e0c77b7f2847c7161`; Ghidra 12.1.4 headless against the **existing v81 named Ghidra program** in read-only mode. No runtime execution, source reimplementation, or symbol changes. Native decompiled C and read-only scripts are bundled.

## Principal conclusion

**The attacker identity used by FSM damage-source queries is not a generally owned reference.** Its validity depends on the lifetime of retained references maintained by whichever subsystem produced the attack. The provenance is not uniform across projectiles and explosions. We can now identify concrete counted slots, early liveness checks, retirement releases, and the precise code that hands a source pointer to the damage recorder.

### 1. Ordnance: retained source and target

`004A0AE0 update_ordnance_system`, called by `0049FB40 spawn_weapon_projectile_or_ordnance_runtime_object` at `004A00DC`, initializes `ordnance_world_object+0x70` class-specific data. It copies the world-object pointer passed in the launch record's `param_2[1]` to **class runtime +0x0C** and independently increments its tree reference with `0045ED00`. It likewise copies `param_2[10]` to **class runtime +0x10** and separately increments that pointer's tree reference if nonzero. They can designate the same object; the implementation retains them separately.

`004A7370 build_vehicle_ordnance_runtime_context` looks up both pointers via `0045F0F0`, and writes the returned values back into both slots. This matters because `0045F0F0` returns a live pointer unchanged, but when the object has already been logically removed, consumes a retained reference and returns NULL. The ordnance therefore *can* relinquish one of these holds before its own destruction. This routine is not an unconditional release on every access.

On ordnance retirement, `004A0990 update_mission_runtime_object_list_and_release_expired` drops both references from the class runtime (`piVar1[3]` and `[4]`) by invoking `0045EF70`, then removes/requeues the projectile via `004A06F0` and `004A05F0`. The alternative creation/early-retire branch within `0049FB40` also explicitly drops both fields (`piVar4[3]` and `[4]`). On a logically removed source, an earlier liveness check can have nullified the corresponding pointer and already consumed its hold. Both cases imply **retention is scoped to ordnance execution/retirement, not to the AI cached event**.

### 2. Explosion: borrowed source slot and separately retained auxiliary slot

`0049EAD0 spawn_cached_explosion_runtime_object` writes its third argument directly into explosion class runtime **+0x0C** without `0045ED00` on that argument. It separately writes its seventh argument into **+0x10** and retains that pointer with `0045ED00`. `0049EFE0 explosion_system_log_tag` releases `runtime+0x10` (`puVar1[4]`) as explosion objects are returned to a cache. The `+0x0C` value is not independently retained in this constructor.

**These pointers are sometimes equal and sometimes different.** For instance the vehicle catastrophic breakup caller `00466180` passes `param_1` as both argument 3 and argument 7, retaining its source as a consequence; destructible building callers such as `0046AC50` pass the building/source as argument 3 but zero as argument 7. The distinction is proven by the caller arguments, not guessed from function names. Other explosion creation paths, especially `004A7190`, need provenance classification per callsite before predicting source lifetime.

### 3. How both effects attribute damage

`0049ED70 get_effect_source_parent_world_object` is a six-instruction accessor in semantic terms: if an effect has non-null class-specific runtime data (`object+0x70`), it returns `[runtime+0x0C]`, otherwise zero.

`004A7C80 apply_radial_damage_and_impulse_to_target` invokes this accessor for class **0x33 ordnance** and **0x34 explosion** to obtain the source identity. If the source is a direct vehicle/actor, it instead uses the source directly. This resolves the data flow from specific ordnance/explosion owners through the common class-damage dispatcher to `004157A0 record_vehicle_damage_source_event`.

Another important boundary: the radial path acquires a *temporary counted reference to the damage target*, dispatches the class handler, calls `0045F0F0` to validate the target, and only records damage attribution when both `local_c0` (source) and the returned target are non-null. If the damage target is logically removed before this validation, that radial path **skips its event record**. The separate direct-damage helper `004A8240` has its own gating and must not be conflated with the radial path. This is conditional code behavior, not a proven fatal-hit gameplay omission.

### 4. Independently owned object references

| Domain | Retain site | Stored pointer / lifecycle | Release site | Confidence |
|---|---|---|---|---|
| Projectile source | `004A0AE0` | class runtime `+0x0C`; active ordnance | `004A0990`, `0049FB40`, or early dead-object retirement in `004A7370` | High |
| Projectile target | `004A0AE0` | class runtime `+0x10`; active ordnance | Same paired retirement paths | High |
| Explosion auxiliary object | `0049EAD0` | class runtime `+0x10`; cached explosion | `0049EFE0`; conditional other routes require further audit | High for identified pair |
| Explosion attribution source | `0049EAD0` | class runtime `+0x0C`; **no local counted retain** | Pointer overwritten when effect reused, no local release needed | High for constructor |
| Audio object anchor | `00425E60` | audio record `+0x5C` | `00425EF0`, also removal routes at `004217E0` and `00422540` | High |
| Texture animation timer | `0044AE50` | timer's object reference | `0044B030` / `0044B100` etc. | High for named paths |
| Smoke emitter | `00441310` | smoke emitter's object reference | `004413B0` | High |
| Flamer emitter | `00443C90` | record fields 1 and 2, two counted holds | `00443E90` or `00443FC0` | High |
| Muzzle flash | `0049F210` | muzzle-flash record's target | `0049F2F0` and `0049F470` | High |
| Class-update queue | `00461970` | queued world object | `00461B80` or logical-death path in pre/post queues | High |
| FSM actor records | `00412400` / 5 dynamic helpers | actor record `+0x58`, counted | `00409980` | High, inherited v83 |
| AI primary target | `00412830` | AI `+A9B4`, counted | `00412830` and `00409980` | High, inherited v83 |
| AI last attacker identities | `004157A0` | `AI+A6E4/+A6E8/+A6EC`, **borrowed** | No explicit matching addref/cleanup established | High for direct accesses, overall lifetime unknown |

`00461970` contributes a retained queue hold even before active-world registry registration; the pending-class and pre/post class dispatchers validate references differently depending on liveness and installed callback types. This should not be mistaken for a single generic registry.

### 5. The precise remaining risk

**Conditional sequence requiring further validation:** a vehicle source generates a qualifying damage event; the AI retains the source pointer as a borrowed identity; the source's active registration, projectile/explosion records, actor records, visual/audio effects, and other counted holders subsequently retire; a later `who*` command reads the old source pointer and attempts to addref it. The `who*` query tests pointer equality against existing actor bindings and then calls recursive addref on a cache miss, but does not first apply `0045F0F0` or test epoch recency. The code does not prevent an already-freed pointer from being used in that **conditional** sequence. We have not established that an actual shipped mission can produce the sequence, that all unregistration paths leave the pointer unmodified by alias/bulk stores, or that allocator reuse is observable before the query.

Distinguish two paths that might mitigate the risk: (1) the source may already be held as a named mission actor or AI target; (2) live ordnance, active-world registry, class queues, audio or visual effects may still retain it. Neither is a permanent global guarantee. Conversely, pending callback-queue references can temporarily extend lifetime even after logical removal.

### 6. Mission-runtime tests to preserve (not implemented)

- Fire from a vehicle while the corresponding projectile remains live; verify two ordnance counted holds if source and target are the same pointer.
- Destroy / unregister the source before the projectile expires; distinguish early `004A7370` retirement from expiry-time `004A0990` release.
- Spawn an explosion with `(arg3=source, arg7=source)` versus `(arg3=source, arg7=0)`; validate that only the first holds that source through the auxiliary slot.
- Record an attack and retire the attacker before calling `whoShot` / `whoAttacked`; separately test with attacker pre-bound as a named actor and with no prior binding.
- Destroy the radial-damage target during class handler dispatch; verify whether the `004A7C80` condition suppresses event recording and compare with direct damage `004A8240`.
- Verify object callback queue cleanup order relative to the FSM epoch advance for live, logically removed and physically freed objects.

### 7. Provisional source-layout map (hypotheses only)

- `0049EAD0–0049F1D0`: explosion allocation, source association, caching and retirement; likely coherent translation-unit neighborhood.
- `0049F210–0049F470`: muzzle flash effect lifecycle; plausible separate module next to explosion.
- `0049F5C0–004A0Bxx`: ordnance registration, spawning, linked-list recycling and owner release; likely one or several adjacent units.
- `004A7190–004A8240`: ordnance/effect collision and damage attribution bridge; separate later cluster.
- `004A92E0–004AD11E`: category-specific ordnance update and collision handlers; strongly cohesive behavior family; precise original file boundaries unknown.
- `00461970–00461Dxx`: class descriptor callback and queued pre/post scheduling; plausible module.
- `00425E60–004260xx` and `00421400–004226xx`: audio object allocation, instance teardown and update paths in noncontiguous sections; no claim of one source file.
- `00443C90–004440xx`: flamer effects and counted emitter references.

The code adjacency is binary fact; suspected original `.c/.cpp` boundaries are **speculation** and are not incorporated into Ghidra symbol names. This entry extends, rather than replaces, the v82 source-layout ledger.

### 8. Coverage, evidence, and limitations

Four independent read-only Ghidra headless investigations completed successfully, decompiling **50 + 38 + 19 target entries** and **30 distinct explosion-callsite functions** (some overlapping). A broad indexed reference inventory contains 26 references to `0045ED00`, 53 to `0045EF70`, and 108 to `0045F0F0`; these reference counts are indexed site counts, not unique function counts and not complete coverage of indirect/raw-pointer dispatch.

Primary evidence: `v85_owner_native_decompiled.txt`, `v85_followup_native_decompiled.txt`, `v85_provenance_native_decompiled.txt`, `v85_explosion_callers_native_decomp.txt`, `v85_owner_reference_sites.tsv`, and `v85_explosion_incoming_xrefs.tsv`. All scripts are included. Validation is static and is not proof of gameplay reachability. Research source remains the retail PE; imported named Ghidra baseline left unchanged.
