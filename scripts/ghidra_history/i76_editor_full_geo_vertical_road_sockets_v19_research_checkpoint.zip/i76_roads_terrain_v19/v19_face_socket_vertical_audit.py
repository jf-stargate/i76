#!/usr/bin/env python3
"""v19 research: complete indexed .GEO topology, exterior polygon edges and TER vs socket 3-D joins.
All sources retail bytes. Diagnostic threshold != original game's acceptance behavior.
"""
import csv,collections,json,math,pathlib,statistics,sys,tarfile,struct,hashlib
P=pathlib.Path(__file__).resolve().parent
sys.path[:0]=[str(P),'/mnt/data/i76_roads_terrain_v18']
from v19_geo_decode import load_pak
from v18_intersection_geometry_audit import sdf_info,read_mission
from v16_road_ground_surface_alignment import read_chunks
T=pathlib.Path('/mnt/data/i76_base(1).tar')
rd=lambda name:list(csv.DictReader(open(name,newline=''),delimiter='\t'))
def wr(name,rows,fields=None):
 with (P/name).open('w',newline='') as f:
  fields=fields or (list(rows[0]) if rows else ['no_records']);w=csv.DictWriter(f,fieldnames=fields,delimiter='\t');w.writeheader();w.writerows(rows)
def p_dist(q,a,b):
 dx=b[0]-a[0];dz=b[1]-a[1];l=dx*dx+dz*dz
 if l<1e-12:return math.dist(q[:2],a[:2]),0.0
 t=max(0,min(1,((q[0]-a[0])*dx+(q[1]-a[1])*dz)/l))
 return math.dist(q[:2],(a[0]+t*dx,a[1]+t*dz)),t

def transform(obj,sdf,geo):
 a=sdf['components'][0];r=obj['rot'];ox,oy,oz=obj['pos'];sr=a['matrix']; tx,ty,tz=a['trans'];out=[]
 for x,y,z in geo['vertices']:
  px=sr[0]*x+sr[3]*y+sr[6]*z+tx
  py=sr[1]*x+sr[4]*y+sr[7]*z+ty
  pz=sr[2]*x+sr[5]*y+sr[8]*z+tz
  # object rotation is stored in column-oriented 3x3; vertical behavior same general composition.
  out.append((ox+r[0]*px+r[3]*py+r[6]*pz,oz+r[2]*px+r[5]*py+r[8]*pz,oy+r[1]*px+r[4]*py+r[7]*pz))
 return out

def true_exterior_edges(geo):
 count=collections.Counter()
 for f in geo['faces']:
  ind=f['vertices']
  for a,b in zip(ind,ind[1:]+ind[:1]):count[tuple(sorted([a,b]))]+=1
 return [e for e,n in count.items() if n==1],len([e for e,n in count.items() if n>1]),sum(n>2 for n in count.values())

def sample_ter(x,z,ter,zm):
 # Native sampler 00493550: world-to-grid scale 0.2; bilinear interpolation of packed low 12 bits, multiplier .1.
 gx=x*.2;gz=z*.2;ix=math.floor(gx);iz=math.floor(gz);fx=gx-ix;fz=gz-iz
 def cell(i,k):
  if not(0<=i<10240 and 0<=k<10240):return 0
  zid=zm[(k//128)*80+(i//128)]
  if zid==255:return 0
  p=zid*32768+(k%128)*256+(i%128)*2
  return struct.unpack_from('<H',ter,p)[0]&4095 if p+2<=len(ter) else 0
 a=cell(ix,iz);b=cell(ix+1,iz);c=cell(ix,iz+1);d=cell(ix+1,iz+1)
 return ((a*(1-fx)+b*fx)*(1-fz)+(c*(1-fx)+d*fx)*fz)*.1

def main():
 aliases={r['alias_sdf'][:-4]:r['real_geometry_provider'][:-5] for r in rd('/mnt/data/i76_roads_terrain_v19/v18_sdf_geometry_aliases.tsv')}
 inv=rd('/mnt/data/i76_roads_terrain_v19/v18_intersection_sdf_geometry_inventory.tsv');names={r['resource'][:-4] for r in inv}
 resources={};inventory=[];failed=[]
 for nm in sorted(names):
  try:
   sdf=sdf_info(nm);canonical=aliases.get(nm,nm);models=load_pak(canonical)
   if not models:raise ValueError('missing geometry package')
   needed=sdf['components'][0]['name'];matches=[m for m in models if m['name']==needed]
   if not matches:raise ValueError('missing named geometry component '+needed)
   geo=matches[0];edges,internal,weird=true_exterior_edges(geo)
   refs=sum(f['corner_count'] for f in geo['faces'])
   if len(edges)<3:raise ValueError('no perimeter edges')
   yy=[v[1] for v in geo['vertices']]
   inventory.append(dict(resource=nm,geometry_provider=canonical,geometry_name=needed,geo_components=len(models),vertices=len(geo['vertices']),faces=len(geo['faces']),total_face_corners=refs,exterior_edges=len(edges),shared_edges=internal,nonmanifold_edges=weird,face_textures=';'.join(sorted(set(f['texture'] for f in geo['faces']))),vertex_y_range=max(yy)-min(yy),faces_planar_y_down=sum(f['plane'][1]<-.95 for f in geo['faces']),consumed_all_geo_chunks=True))
   resources[nm]=(sdf,geo,edges)
  except Exception as exc:failed.append((nm,str(exc)))
 wr('v19_full_geo_topology_inventory.tsv',inventory)
 if failed:print('FAILED RESOURCES',failed)
 placements=[];endpoints=[];matches=[];edgecount=collections.Counter();per_m=collections.Counter()
 with tarfile.open(T) as t:
  names=sorted([x for x in t.getnames() if '/miss8/' in x.lower() and x.lower().endswith('.msn')])
  for path in names:
   mission=path.rsplit('/',1)[-1];b=t.extractfile(path).read();ter=t.extractfile(path[:-3]+'TER').read()
   zc=next((p,n) for tg,p,n in read_chunks(b,b'TDEF') if tg==b'ZMAP');zm=b[zc[0]+9:zc[0]+9+6400]
   oo,rr=read_mission(b,mission);inte=[]
   for o in oo:
    if o['key'] not in resources:continue
    sdf,geo,edges=resources[o['key']];root_height=sample_ter(o['pos'][0],o['pos'][2],ter,zm);runtime_obj={**o,'pos':(o['pos'][0],root_height,o['pos'][2])};world=transform(runtime_obj,sdf,geo);ext=[(world[i],world[j]) for i,j in edges]
    bb=(min(v[0] for v in world),max(v[0] for v in world),min(v[1] for v in world),max(v[1] for v in world))
    inte.append((o,ext,bb));placements.append(dict(mission=mission,resource=o['key'],odef_offset=o['offset'],stored_obj_y=o['pos'][1],terrain_projected_root_y=root_height,stored_minus_runtime_root_y=o['pos'][1]-root_height,edge_count=len(ext),vertex_y_range=max(v[2] for v in world)-min(v[2] for v in world)))
   per_m[mission]=(len(inte),len(rr));endpoints+=rr
   for e in rr:
    cx,cz=e['center'];ea,eb=e['edges'];opts=[]
    for o,edges,bb in inte:
     if not(bb[0]-15<=cx<=bb[1]+15 and bb[2]-15<=cz<=bb[3]+15):continue
     for ai,(a,bp) in enumerate(edges):
      dct,tc=p_dist((cx,cz),a,bp);da,ta=p_dist(ea,a,bp);db,tb=p_dist(eb,a,bp)
      score=max(da,db)
      if dct<=15:
       opts.append((score,dct,o,ai,a,bp,da,db,ta,tb))
    if not opts:continue
    score,dc,o,ii,a,bp,da,db,ta,tb=min(opts,key=lambda v:(v[0],v[1]))
    # even if poor match, report best candidate; precise matches require both edge endpoints, center.
    hy_a=sample_ter(ea[0],ea[1],ter,zm);hy_b=sample_ter(eb[0],eb[1],ter,zm)
    py_a=a[2]+(bp[2]-a[2])*ta;py_b=a[2]+(bp[2]-a[2])*tb
    rec=dict(mission=mission,road=e['rseg'],end=e['end'],road_kind=e['kind'],intersection=o['key'],object_offset=o['offset'],boundary_edge_id=ii,center_distance=dc,edge_a_distance=da,edge_b_distance=db,road_edges_max_distance=score,road_edge_a_height=hy_a,road_edge_b_height=hy_b,mesh_edge_a_height=py_a,mesh_edge_b_height=py_b,vertical_gap_a=hy_a-py_a,vertical_gap_b=hy_b-py_b,vertical_gap_max=max(abs(hy_a-py_a),abs(hy_b-py_b)),mesh_local_face_geometry=True)
    matches.append(rec)
 wr('v19_intersection_root_height_projection.tsv',placements)
 wr('v19_true_polygon_socket_3d_cases.tsv',matches)
 exact=[r for r in matches if r['center_distance']<=.05 and r['road_edges_max_distance']<=.05]
 failure=[r for r in matches if r['center_distance']<=.05 and r['road_edges_max_distance']>.05]
 wr('v19_true_boundary_center_only_cases.tsv',failure)
 gap=[r['vertical_gap_max'] for r in exact]
 def pct(ls,p):return sorted(ls)[min(len(ls)-1,round((len(ls)-1)*p))] if ls else None
 summary=dict(mission_count=len(names),intersection_sdfs=len(inv),fully_decoded_sdf_intersections=len(resources),incomplete_resources=failed,intersection_placements=len(placements),rseg_endpoints=len(endpoints),road_ends_with_candidate_near_true_polygon=len(matches),center_matches_within_005=sum(r['center_distance']<=.05 for r in matches),both_road_corners_match_true_boundary_within_005=len(exact),center_only_mismatch_cases=len(failure),v18_convex_hull_full_edge_matches=617,vertical_gap_abs_max=max(gap) if gap else None,vertical_gap_abs_median=statistics.median(gap) if gap else None,vertical_gap_abs_p90=pct(gap,.9),vertical_gap_abs_p99=pct(gap,.99),vertical_gap_over_01=sum(v>.1 for v in gap),vertical_gap_over_05=sum(v>.5 for v in gap),vertical_gap_over_1=sum(v>1 for v in gap),vertical_gap_over_5=sum(v>5 for v in gap),vertical_gap_match_count=len(gap),intersection_placements_repositioned_from_stored_y=sum(abs(r['stored_minus_runtime_root_y'])>.05 for r in placements),max_stored_minus_projected_root_y=max(abs(r['stored_minus_runtime_root_y']) for r in placements),top_vertical_mismatch_cases=sorted(exact,key=lambda x:-x['vertical_gap_max'])[:15],geometry_notes=['Complete indexed n-gon face boundaries from GEO, not convex hull; edge shared by 2 faces omitted from external boundary.','Runtime constructor 004B8230 overwrites every top-level SDF root Y with terrain height (called with terrain_project flag 1 in OBJ loader 004B7AC0), independently of serialized ODEF Y. Joined geometry uses terrain-projected root Y plus SDF child offsets.','Road Y is reconstructed from native terrain lookup semantics (bilinear, 5-unit grid and 0.1 height factor); x87 precision edge cases not reproduced.','No rasterized collision or live game image was compared.'])
 (P/'v19_true_polygon_3d_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='top_vertical_mismatch_cases'},indent=2),flush=True)
 print('TOP GAP');[print(x) for x in summary['top_vertical_mismatch_cases'][:8]]
if __name__=='__main__':main()
