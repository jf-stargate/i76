# Interstate '76 road intersection v19 research checkpoint

Main report: `V19_GEO_FACE_TOPOLOGY_AND_VERTICAL_ROAD_INTERSECTION_SEAMS.md`.

Run `python3 v19_face_socket_vertical_audit.py` and `python3 v19_validate.py` with original retail `i76_base(1).tar` at `/mnt/data/i76_base(1).tar` (or change the constants to your local location). Python 3 and the system liblzo2 are required.

Native binary evidence: `v19_native_odef_height_sampling_window.txt`; prior Ghidra exports bundled as `v06_game_obj_field_asm.tsv`, `v06_game_obj_field_decomp.txt`, `v06_game_terrain_boundary_audit.txt`. Ghidra was **not re-run** in v19. Source code in this checkpoint parses retail formats for research; it is not an engine/editor reimplementation.

Tables: full mesh topology, all 386 decoded intersection placements/root heights, 933 nearest geometry candidates, 58 center-only mismatches, and source-layout ledger. 40 paired miss8/miss16 scenes share identical RDEF and TER bytes.

The source data files (.EXE/.PAK/.MSN/.TER/.ZFS) are not bundled. GitHub legacy references are supplementary, not treated as authoritative.
