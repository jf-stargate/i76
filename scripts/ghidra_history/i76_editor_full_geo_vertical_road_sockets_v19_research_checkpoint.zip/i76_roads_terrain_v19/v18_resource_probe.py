#!/usr/bin/env python3
import re,struct,ctypes,ctypes.util,json,collections,hashlib,pathlib,sys
P=pathlib.Path(__file__).resolve().parent
_retail_zfs=P/'__temp_retail_archive_do_not_bundle.zfs'
if _retail_zfs.exists():
 z=_retail_zfs.read_bytes()
else:
 import tarfile
 with tarfile.open('/mnt/data/i76_base(1).tar') as _tar:
  z=_tar.extractfile('interstate 76/I76.ZFS').read()
zl=z.lower()
lib=ctypes.CDLL(ctypes.util.find_library('lzo2'));f=lib.lzo1y_decompress_safe
f.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.c_void_p];f.restype=ctypes.c_int

def decomp(off,n,size,mode):
 raw=z[off:off+n]
 if mode==4:
  s=ctypes.create_string_buffer(raw);d=ctypes.create_string_buffer(size);sz=ctypes.c_size_t(size);rc=f(s,len(raw),d,ctypes.byref(sz),None)
  if rc or sz.value!=size:raise ValueError((rc,sz.value,size))
  return d.raw[:size]
 if mode==0:return raw
 raise ValueError(mode)

def entry(name):
 token=name.lower().encode()+b'\x00';i=zl.find(token)
 if i<0:return None
 name=z[i:i+16].split(b'\0',1)[0].decode('ascii','replace')
 if i+36>len(z):return None
 off,extent,stored,checksum,flags=struct.unpack_from('<IIIII',z,i+16)
 if off+stored>len(z) or flags&255 not in (0,4):return None
 return dict(name=name,index=i,offset=off,stored=stored,extent=extent,flags=flags,checksum=checksum,mode=flags&255,usize=flags>>8)

def chunks(data):
 out=[];i=0
 while i+8<=len(data):
  tag=data[i:i+4].decode('latin1');sz=struct.unpack_from('<I',data,i+4)[0]
  if sz<8 or i+sz>len(data):break
  out.append(dict(tag=tag,offset=i,size=sz));i+=sz
 return out,i

if __name__=='__main__':
 names=['sstop_1','sdxin_1','sedet_1','sdyin_1','sdtin_1','sdded_1','swend_1','sj62r_1','sh21n_1','sdcon_1','ahut1']
 obj=[]
 for base in names:
  for ext in ['sdf','edf','bdf','geo','p3d','3d','dfc','vdf','gdf']:
   name=base+'.'+ext;e=entry(name)
   if not e:continue
   try:
    data=decomp(e['offset'],e['stored'],e['usize'],e['mode']); ch,end=chunks(data);e.update(chunks=ch,walk_complete=(end==len(data)),sha256=hashlib.sha256(data).hexdigest()); obj.append(e)
    if ext=='sdf':
     print('\n',name,e['usize'],[(x['tag'],x['size']) for x in ch]);
     for x in ch:
      if x['tag']=='SGEO':
       o=x['offset'];ct=struct.unpack_from('<I',data,o+8)[0];print(' SGEO header count',ct,'first 200:',data[o+12:o+212].hex(' '));
       for k in range(min(6,ct*6)):
        row=data[o+12+k*0x78:o+12+(k+1)*0x78]
        if len(row)<0x78:break
        print(' row',k,'n',row[:8],'parent',row[0x38:0x40], 'class',struct.unpack_from('<I',row,0x5c)[0],'hex',row[:64].hex(' '))
   except Exception as ex:print('BAD',name,ex)
 (P/'v18_sdf_resource_probe.json').write_text(json.dumps(obj,indent=2)+'\n')
 print('found:',[(x['name'],x['usize']) for x in obj])
