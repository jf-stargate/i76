# Interstate '76 v19 — Complete intersection GEO face topology, socket boundaries and height continuity

Research date: 2026-10-21. Status: original-resource static analysis, cross-checked against retail game PE and **frozen** prior Ghidra disassembly. Neither game nor editor executed; neither annotated Ghidra project modified. No source-code reconstruction or new editor implementation attempted.

## Executive conclusion

The original `.PAK` geometry can be decoded beyond vertex positions: it stores concatenated `OEG.` GEO components, each with vertex coordinates, a parallel normal table, and full indexed n-gon faces (face texture slot, face color, plane, flags and per-corner vertex/normal indices and UV coordinates). All 54 identified intersection SDF definitions can be resolved to one of 40 independently packaged first-LOD GEO providers; the other 14 are exact SDF component/transform aliases.

**762 of 1,300** distinct retail road-strip endpoints align with the **actual exterior polygon edge** of a placed intersection at both road corners (research diagnostic tolerance 0.05 world units). The previous v18 convex-hull audit had **617**. All 617 remain exact. The additional 145 matches are accounted for by intersection SDF aliases excluded from v18's first-pass placement count, rather than by fixing an erroneous convex-hull edge. **58** further endpoints meet the centerline criterion but fail the both-corners criterion.

The game's terrain projection of SDF roots is essential to vertical analysis. The native ODEF handler `004B7AC0` calls constructor `004B8230` with terrain-height projection enabled for classes `0x50`, `0x52`, and `0x53`, which contains a native `CALL 00493550` at `004B82B5`, followed by storing the returned Y at `WorldObject+0x48`. A height multiplication of `0.1` is stored in retail PE `.rdata` at `004BE8A8`; terrain words contain 12-bit height samples. Thus **original OBJ stored Y is not the final runtime intersection elevation**. In five intersection placements the source Y and projected root Y differ by more than 0.05; in S07 the discrepancy is **32.8** units, in S03 **13.6**, in S04 **4.0**.

With terrain-projected root Y, the 762 horizontally exact seams have **median maximum absolute per-corner vertical mismatch ~0.001**, 90th percentile ~0.099, 99th percentile ~0.300 and maximum ~0.500 world units. No exact-fit join in the corpus exceeds 0.5 under this static reconstruction. A naive stored-Y comparison would have reported **4.1 units** of phantom road/pavement height error in S04; accounting for the runtime override removes that false positive.

## Evidence tiers and sources

- **Binary-proven:** `.EXE` MD5 `a640ea0097dbb62e0c77b7f2847c7161`, `004B82B5` terrain-height call `00493550`, `004B82BA` storing returned double as object's height; `004BE8A8` float `0.1`. Reverified directly using GNU objdump and raw PE section contents. Full native source is v06 Ghidra's `v06_game_obj_field_decomp.txt`/`v06_game_obj_field_asm.tsv` bundled as frozen comparison; **Ghidra itself was not re-run in v19**.
- **Resource-proven:** GEO byte counts, face descriptors, concatenated component boundaries, explicit polygon vertex references, SDF child transforms, mission ODEF object identities, packed terrain words, `RSEG` road endpoint coordinates. All from the user's original `i76_base(1).tar`, not the GitHub scripts.
- **Derived diagnostics:** 0.05 X/Z tolerance, exterior-edge point-to-segment distance, height interpolation, center-only filters, rank statistics. These are research choices, not original engine/editor rejection thresholds. x87 float rounding and FPU control-word peculiarities may create sub-sample differences in edge cases.
- **Historical supplemental work:** public `jf-stargate/i76` references under `ref/model_format` and `ref/level_format` describe a substantially compatible face layout but are not relied on as the deciding evidence. The RSEG note still labels road materials and road-type mapping unresolved; the later v16 editor/game investigation resolved these matters. We did not import the older Blender exporter's UV or coordinate transforms as authoritative runtime conventions. GitHub: `https://github.com/jf-stargate/i76/tree/main/ref`, `https://github.com/jf-stargate/i76/tree/main/scripts`.

### Concrete audit of the earlier GitHub terrain exporter

The public `scripts/game/i76_level_blender_export_open76_v7.py` uses `DEFAULT_VERTICAL_SCALE = 409.5 / 4096.0` (approximately `0.099975586`), whereas the original retail terrain-height sampler multiplies packed elevation by the native constant **`0.10000000149`** at `004BE8A8`. The earlier Python script is a useful visual/Blender export tool and documents welded patch seams, but its vertical scale is **not an exact reproduction of this retail sampler**. Over a raw 12-bit elevation value of 4095, the nominal difference can approach 0.1 world units. The v19 road/socket study uses the binary-supported 0.1 factor; for a future editor, terrain preview and runtime-compatibility checking should distinguish approximate display/export scales from original engine coordinate units.

The legacy exporter additionally offers Open76-centered, min-corner, and absolute world-origin conventions and Blender-vs-Y-up coordinate representations. Those are visualization/OBJ output options, not evidence of differing on-disk mission coordinates. The GitHub script's globally welded terrain mesh can help eliminate duplicate-vertex shading seams in Blender, but is unrelated to whether an original intersection prefab and `RSEG` edge physically meet. Source: `https://github.com/jf-stargate/i76/blob/main/scripts/game/i76_level_blender_export_open76_v7.py`.

## GEO serialization determined from original intersection PAKs

`itd27_1g.pak` decompresses to 502 bytes, containing two concatenated 251-byte GEO chunks. Each starts at bytes `OEG.` (not conventional forward `GEO.`). Its first component is named `IT1_D271`, vertex count 4, face count 1; the second `IT1AD271` uses an identical structure and counts. A complete 251-byte chunk is explained as `36 + (4 * 12) + (4 * 12) + 55 + (4 * 16)` bytes.

| Field | Encoding | Position |
| --- | --- | --- |
| Magic, header field, component name | `OEG.` + 4 bytes + `name[16]` | bytes `0..23` |
| Vertex count, face count, header field | three `u32` | `+0x18..0x23` |
| Vertices | `vertex_count` triples of `float32` | `+0x24` |
| Normals | `vertex_count` triples of `float32` | after vertices |
| Per-face packed header | 55 bytes | after normals / prior faces |
| Face header | `u32 face_index`, `u32 corner_count`, `rgb[3]`, `float32 plane[4]`, `u32`, `flags[3]`, `texture[13]`, `u32`, `u32` | offsets relative to face header: 0, 4, 8, 11, 27, 31, 34, 47, 51 |
| Face corners | `corner_count` times (`u32 vertex_index`, `u32 normal_index`, `float32 u`, `float32 v`) | relative face offset 55 |

Every face index was within the corresponding vertex/normal table, every face fit the PAK buffer, and the parser consumed every component's exact bytes with no trailing data across all 40 geometry providers. All first-LOD pavement face normal coefficients have near-vertical Y = −1. Some models have several joined faces; others are single concave n-gons. The engine's use of these polygons for collision (if any) is not established by their geometric representation.

Illustrative parsed first-LOD components:

| Asset | Unique vertices | Faces | Per-face corner counts |
| --- | ---: | ---: | --- |
| `itd27_1` | 4 | 1 | 4 |
| `ijd27t1` | 7 | 2 | 5, 4 |
| `iga21_1` | 8 | 2 | 4, 4 |
| `ica21_1` | 8 | 1 | 8 |
| `iyd27_1` | 19 | 7 | 4, 4, 4, 5, 3, 5, 6 |

Exterior edges are determined by counting undirected pairs of adjacent vertex indices over the indexed faces and selecting edges occurring exactly once. Shared internal polygon edges are excluded; all 54 first components are free of non-manifold triple-used edges. Unlike a convex hull, this preserves concavities and face-defined inlets. Where a polygon's face winding is unusual or faces overlap, edge-incidence is an approximation to the **rendering** perimeter, and dynamic collision still requires a separate check.

## Road socket census — distinguish what improved

Forty different `miss8` `.MSN` missions contain 1,300 nonempty RSEG strip terminals. The corresponding `miss16` versions have byte-identical `RDEF` sections and `.TER` rasters across **all 40 paired missions**. Therefore they are not counted as independent geometric samples.

| Criterion | Number |
| --- | ---: |
| Intersection SDF definitions with complete first-LOD mesh topology | 54 |
| Independently packaged named mesh providers | 40 |
| Matched alternate SDF aliases | 14 |
| Placed intersection objects including aliases | 386 |
| Road endpoints with a candidate polygon perimeter within 15 units | 933 |
| Center within 0.05 of an exterior polygon segment | 820 |
| Center and BOTH road pavement corners on the same exterior segment within 0.05 | **762** |
| Center matches but full-width edge fails | **58** |
| Convex-hull strict joins from prior v18 | 617 |
| V18 strict joins lost by more precise face analysis | **0** |
| Additional strict joins due to alias coverage | **145** |

All 145 new strict joins are SDF-alias placements, not previously failed direct-resource cases. This important control prevents attributing the count improvement to more accurate polygon reconstruction when it actually comes from greater resource coverage.

### The ~0.349-unit anomaly survives exact face topology

In the `iga21_1`, `igd27_1`, `ila21_1`, and `ild27_1` families, 47 center-matched endpoints have repeatable pavement-corner differences near **0.348–0.350 units**. Reconstructing the actual face edges does not make those mismatches disappear. This is stronger evidence of a true stored road-vs-prefab boundary difference, but still **does not establish a visible crack**: render order, model geometry beyond the first component, terrain polygons, and deliberate oblique approach design could cover the discontinuity. These four families are the highest-value seam-specific regression tests. Other center-only differences include small ~0.069/0.086 units and isolated substantially larger gaps, retained verbatim in `v19_true_boundary_center_only_cases.tsv`.

## Vertical seam math and the importance of runtime object height

For a road edge at (x,z): use terrain grid scaling `x/5`, `z/5`, unpack low 12 bits from each of the four neighbors and bilinearly interpolate, then multiply by `0.1`. This matches the `00493550` height-sampling assembly's four-cell interpolation and final scale; it is not a bit-for-bit emulation of all x87 FPU rounding subtleties.

For intersection mesh vertex coordinates: start with original GEO vertex; apply the SDF `SGEO` component's 3x3 basis and translation; then apply the mission OBJ's 3x3 rotation and **runtime-resampled** root position. For horizontal coordinates the v18-established transform has `X = ox + r00*local_x + r20*local_z`, `Z = oz + r02*local_x + r22*local_z`. The object root's Y is terrain height at `(ox, oz)` rather than stored ODEF Y for the SDF-loading branch, then child/local Y is added. The included scripts calculate complete matrix composition, not a planar origin-only shortcut.

For a matching road corner, compare reconstructed road Y with the corresponding point interpolated along the actual transformed exterior GEO edge. Sample both corners independently; terrain can slope across the full ten-unit road width even when the junction prefab is nominally flat.

**Critical stored-Y correction fixtures**:

| Mission | Resource | ODEF stored Y | Runtime-projected root Y | Consequence |
| --- | --- | ---: | ---: | --- |
| `S07` | `itisect1` | 36.5 | 3.7 | 32.8-unit false discrepancy if source Y trusted |
| `S03` | `ita21_1` | ~9.6 | 23.2 | 13.6-unit false discrepancy |
| `S04` | `ita21_1` | 14.0 | 10.0 | Apparent >4-unit seam corrected at runtime |

The first-level intersection component is usually a near-horizontal single planar surface and can contain a tiny local Y offset (~0.001). The median gap being ~0.001 is consistent with this offset, but intent (e.g. z-fighting mitigation) cannot be claimed as proven. Small 0.1, 0.3 or 0.5 unit differences are compatible with packed-height quantization or local grading discrepancies; no gameplay camera, physics contact, or rasterized frame validation was performed.

**Worst verified exact-horizontal 3-D joins (reconstructed, not observed visually):**

- `T15`, `RSEG 0x15462` and `ild27_1` OBJ `0x1C472`: max per-corner vertical mismatch **~0.500 units**; the road edge samples ~8.2 and ~8.3 while the flat prefab edge is ~7.8.
- `T15`, `RSEG 0xCB02` and `ild27_1` OBJ `0x1B9E6`: max mismatch **~0.400**.
- `T07`, `RSEG 0x44CA` with `ixd27_1` OBJ `0xFAAE`: one corner mismatch **~0.399** while the opposite corner nearly meets the prefab, indicating lateral slope across the 10-unit strip.
- `A01`, `RSEG 0x1ADA` last section and `itd27_1` OBJ `0xBD52`: X/Z pavement corners coincide; runtime terrain centerline at edge ~86.9–87.0, intersection mesh near 87.001.

## Road-editor compatibility implications (derived guidance, not original developer contract)

1. Keep prefab **socket edges derived from indexed GEO polygons** (or explicitly captured equivalent socket metadata); preserve curved or concave boundaries. Do not attach to object centers or only to convex hulls.
2. Validate **both** road-corner positions on the **same actual exterior edge**; check tangent orientation separately from edge distance.
3. Use **runtime** world-object height behavior for intersections, including the root's terrain-height override and SDF local offset; do not insist that stored OBJ Y equal prefab pavement elevation.
4. Sample traction material in the external `.TER` raster separately from visual road geometry (`RSEG`) and intersection face texture. A visually seamless road may have a different wheel-contact surface classification at the junction.
5. Keep diagnostics for oblique family 0.349-unit offsets distinct from true multi-unit gaps and from height-quantization effects. Never auto-correct official retail data based solely on a 0.05-unit researcher tolerance.
6. Retain anomalous retail S04/T07/T15/S03/S07 fixtures in any future test suite; they probe the important limits of geometric and vertical continuity. No implementation is authorized yet.

## Remaining open questions

- Runtime polygon **collision** and drivability may not match the visual face boundary exactly. Follow the game geometry collision and road wheel-contact readers, separately from rendering.
- Determine precisely whether alternate first-LOD GEO components, near-LOD substitutions or non-first SDF variants ever change actual intersection pavement boundaries in the scene.
- Verify the editor's material painting at intersection ends and whether surface alias 6/7 has an intended junction-specific use. Some road-end material mismatches remain even for exact-fit polygon sockets.
- Trace any renderer z-bias or near-clipping effects that can visually mask sub-0.5-unit vertical seams, and confirm x87 tie rounding if bit-exact terrain sampling is required.
- Check whether authoring controls enforce cardinal placement for specific prefab types; three previously measured off-cardinal retail placements demonstrate this is not a universal runtime restriction.

## Reproduction and checkpoint contents

Run `python3 v19_face_socket_vertical_audit.py` from this directory, with original retail `/mnt/data/i76_base(1).tar` accessible. The scripts include copies of the v18 resource reader and parser support and do not write into retail inputs. Run `python3 v19_validate.py` for 23 checks spanning original PE MD5, native-height opcode signature, `.rdata` height scale, 40 render-variant comparisons, face parser, 54 geometry families, and key spatial fixtures. The checkpoint intentionally excludes retail `.EXE`, `.ZFS`, `.PAK`, `.MSN`, `.TER`, `.gzf`, and the large temporary ZFS cache. Previous v18 evidence remains a separate checkpoint. In v19 Ghidra was **not** newly run; prior frozen Ghidra decompilation/assembly was checked against the native PE with independent `objdump` disassembly.

Original source/TU boundaries remain hypotheses: ODEF dispatch around `004B7AC0–004B8350`, terrain height around `00493550–004937B2`, road geometry loading around `0048E1A0–0048E900`, and intersection resource geometry around the shared `.GEO` parsing path. These are code neighborhoods, not proven original source-file divisions.
