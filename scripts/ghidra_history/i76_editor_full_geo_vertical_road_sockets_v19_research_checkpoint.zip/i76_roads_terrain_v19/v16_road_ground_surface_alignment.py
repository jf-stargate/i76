#!/usr/bin/env python3
"""Independent approximation of retail RSEG-to-TER material alignment using runtime's 5-unit terrain cells."""
import collections, csv, json, math, struct, tarfile
from pathlib import Path
ROOT=Path(__file__).parent
TAR=Path('/mnt/data/i76_base(1).tar')
U32=lambda b,p:struct.unpack_from('<I',b,p)[0]
def chunks(buf,a,e):
 while a+8<=e:
  n=U32(buf,a+4)
  if n<8 or a+n>e:raise ValueError((a,n,e))
  yield (buf[a:a+4],a,n)
  a+=n
 assert a==e
def read_chunks(b,n):
 for t,a,s in chunks(b,0,len(b)):
  if t==n:return list(chunks(b,a+8,a+s))
 raise ValueError(n)
def study(mode='miss8'):
 confusion=collections.Counter(); unavailable=collections.Counter(); kinds=collections.Counter(); samples=0; lookuped=0; misses=[]; summary=[]
 with tarfile.open(TAR) as t:
  names=[m.name for m in t if m.name.lower().endswith('.msn') and ('/'+mode+'/') in m.name.lower()]
  for name in sorted(names):
   b=t.extractfile(name).read(); ter=t.extractfile(name[:-3]+'TER').read()
   rdef=read_chunks(b,b'RDEF'); tdef=read_chunks(b,b'TDEF'); zmap=next((a,s) for tg,a,s in tdef if tg==b'ZMAP')
   zp,_=zmap; zm=b[zp+9:zp+9+6400];local=collections.Counter();
   for tag,rp,rs in rdef:
    if tag!=b'RSEG':continue
    kind,n=struct.unpack_from('<II',b,rp+8)
    if n==0:continue
    expected={0:2,1:3,2:4}.get(kind)
    for i in range(n):
     x1,y1,z1,x2,y2,z2=struct.unpack_from('<6f',b,rp+16+i*24)
     samples+=1;kinds[kind]+=1
     x=(x1+x2)/2.;z=(z1+z2)/2.
     # x86 float->integer path in 004927B0 uses nearest integer grid cell at world scale 5.
     xi=round(x/5);zi=round(z/5)
     if not (0<=xi<10240 and 0<=zi<10240):unavailable['outside_grid']+=1;continue
     zid=zm[(zi//128)*80+xi//128]
     if zid==255:unavailable['inactive_zone']+=1;continue
     word=struct.unpack_from('<H',ter,zid*0x8000+(zi%128)*256+(xi%128)*2)[0]
     material=word>>13
     lookuped+=1;local[(kind,material)]+=1;confusion[(kind,material)]+=1
     if expected is not None and material!=expected and len(misses)<25:misses.append({'file':name.rsplit('/',1)[-1],'kind':kind,'world_x':round(x,3),'world_z':round(z,3),'observed':material,'expected':expected})
   summary.append({'mission':name.rsplit('/',1)[-1],'samples_total':sum(local.values()),'match_count':sum(v for (k,m),v in local.items() if {0:2,1:3,2:4}.get(k)==m),'surface_counts':str(dict(sorted(local.items())))})
 with (ROOT/'v16_road_ground_surface_alignment.tsv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(summary[0]),delimiter='\t');w.writeheader();w.writerows(summary)
 result={'mode':mode,'road_samples_total':samples,'road_samples_with_active_ground':lookuped,'unavailable':dict(unavailable),'observed_by_road_kind_and_terrain_surface':[{ 'road_kind':k,'terrain_material':m,'count':v } for (k,m),v in sorted(confusion.items())],'expected_matches':sum(v for (k,m),v in confusion.items() if {0:2,1:3,2:4}.get(k)==m),'illustrative_mismatches':misses}
 (ROOT/'v16_road_ground_surface_alignment.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k not in ('illustrative_mismatches',)},indent=2))
if __name__=='__main__':study()
