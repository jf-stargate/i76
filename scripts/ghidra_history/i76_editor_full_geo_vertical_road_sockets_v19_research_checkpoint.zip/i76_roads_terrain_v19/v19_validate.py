#!/usr/bin/env python3
"""Independent consistency checks for v19 derived tables, resource bytes and authoritative native .EXE."""
import csv,hashlib,json,pathlib,struct,tarfile,collections,sys
P=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(P))
from v19_geo_decode import load_pak
from v16_road_ground_surface_alignment import read_chunks
R=lambda name:list(csv.DictReader(open(P/name,newline=''),delimiter='\t'))
results=[]
def check(lbl,ok,details=''):
 results.append(dict(test=lbl,passed=bool(ok),detail=str(details)))
 if not ok: print('FAILED',lbl,details)
summary=json.loads((P/'v19_true_polygon_3d_summary.json').read_text());inv=R('v19_full_geo_topology_inventory.tsv');edges=R('v19_true_polygon_socket_3d_cases.tsv');placements=R('v19_intersection_root_height_projection.tsv');aliases=R('v18_sdf_geometry_aliases.tsv')
check('resolved all intersection names',len(inv)==54 and summary['fully_decoded_sdf_intersections']==54)
check('all geometry packets parsed',all(r['consumed_all_geo_chunks']=='True' for r in inv))
check('all indexed faces valid',all(int(r['vertices'])>=3 and int(r['faces'])>=1 and int(r['total_face_corners'])>=3 for r in inv))
check('no non-manifold edges',all(int(r['nonmanifold_edges'])==0 for r in inv))
check('all first-component intersection face planes approximately downward',all(int(r['faces_planar_y_down'])==int(r['faces']) for r in inv))
check('14 legacy SDF geometry aliases',len(aliases)==14 and all(r['exact_transform_and_class']=='True' for r in aliases))
check('386 placed intersection objects',len(placements)==386)
check('1300 road ends',summary['rseg_endpoints']==1300)
check('complete face-outline socket count 762',sum(float(r['center_distance'])<.05 and float(r['road_edges_max_distance'])<.05 for r in edges)==762)
check('58 center-only near misses',sum(float(r['center_distance'])<.05 and float(r['road_edges_max_distance'])>=.05 for r in edges)==58)
check('no vertical reconstructed exact socket above 0.5',summary['vertical_gap_abs_max']<0.5)
check('vertical nearest median below 0.002',summary['vertical_gap_abs_median']<.002)
check('five stored vertical placements are corrected',sum(abs(float(r['stored_minus_runtime_root_y']))>.05 for r in placements)==5)
check('large stored/root height deviation',32.79<float(summary['max_stored_minus_projected_root_y'])<32.81)
check('S04 reprojected 4 unit absolute mismatch',any(r['mission']=='S04.MSN' and r['resource']=='ita21_1' and abs(float(r['stored_minus_runtime_root_y'])-4.0)<1e-5 for r in placements))
check('T15 surviving true vertical edge case',any(r['mission']=='T15.MSN' and r['road']=='0x15462' and .49<float(r['vertical_gap_max'])<.5 for r in edges))
reconciliation=R('v19_v18_exact_join_reconciliation.tsv')
check('all v18 exact joins remain exact after full faces',sum(r['classification']=='retained_v18_exact' for r in reconciliation)==617)
check('145 new exact joins are geometry aliases',sum(r['classification']=='new_sdf_alias_exact' for r in reconciliation)==145 and not any(r['classification']=='new_direct_resource_exact' for r in reconciliation))
check('A01 socket exact with normalized reconstructed heights',any(r['mission']=='A01.MSN' and r['road']=='0x1ada' and r['end']=='last' and float(r['road_edges_max_distance'])<.00001 and float(r['vertical_gap_max'])<.2 for r in edges))
# Independently inspect original game PE signature, model height multiplier and assembly byte sequence.
with tarfile.open('/mnt/data/i76_base(1).tar') as tar:
 exe=tar.extractfile('interstate 76/i76.exe').read()
 check('retail PE MD5 guard',hashlib.md5(exe).hexdigest()=='a640ea0097dbb62e0c77b7f2847c7161')
 check('native indirect calls to terrain height function in root constructor',b'\xe8\x96\xb2\xfd\xff\xdd\x5d\x48' in exe)
 # RVA-based PE offset of f32 constant at VA 004be8a8.
 pos=struct.unpack_from('<I',exe,0x3c)[0];opt=struct.unpack_from('<H',exe,pos+20)[0];sec=pos+24+opt;base=struct.unpack_from('<I',exe,pos+24+28)[0];ns=struct.unpack_from('<H',exe,pos+6)[0]
 found=[]
 for i in range(ns):
  s=sec+40*i;vsize,rva,rsize,raw=struct.unpack_from('<IIII',exe,s+8)
  if rva<=0x004be8a8-base<rva+min(vsize,rsize):found.append(struct.unpack_from('<f',exe,raw+0x004be8a8-base-rva)[0])
 check('height 0.1 literal in original .rdata',len(found)==1 and abs(found[0]-.1)<1e-7)
 # Separate render versions should contain identical road defs and terrain raster.
 match_road=0;match_ter=0
 for i in range(1,17): pass
 for i in range(1,41): pass
 names=[m.name for m in tar if '/miss8/' in m.name.lower() and m.name.lower().endswith('.msn')]
 for name in names:
  other=name.replace('/miss8/','/miss16/')
  def rdef(data):
   for tg,p,n in read_chunks(data,b'RDEF'):pass
   b=0
   while b+8<len(data):
    tg=data[b:b+4];n=struct.unpack_from('<I',data,b+4)[0]
    if tg==b'RDEF':return data[b:b+n]
    if n<8 or b+n>len(data):break
    b+=n
  a=tar.extractfile(name).read();b=tar.extractfile(other).read()
  match_road+=(rdef(a)==rdef(b))
  match_ter+=(tar.extractfile(name[:-3]+'TER').read()==tar.extractfile(other[:-3]+'TER').read())
 check('all 40 8/16-bit missions identical RDEF',match_road==40,match_road)
 check('all 40 8/16-bit missions identical .TER',match_ter==40,match_ter)
# Native GEO face count is not inferred from hull vertex positions; verify exact PAK consumption for every provider.
check('all 40 independent PAK geometry providers include valid full indexed faces',len({r['geometry_provider'] for r in inv})==40)
result={'checks':len(results),'passed':sum(r['passed'] for r in results),'failed':sum(not r['passed'] for r in results),'source':'Retail i76_base(1).tar and frozen v06 native PE proof; earlier v18 derived resource inventory and aliases','tests':results}
(P/'v19_validation.json').write_text(json.dumps(result,indent=2)+'\n');print('VALIDATION',result['passed'],'/',result['checks']);sys.exit(0 if result['failed']==0 else 1)
