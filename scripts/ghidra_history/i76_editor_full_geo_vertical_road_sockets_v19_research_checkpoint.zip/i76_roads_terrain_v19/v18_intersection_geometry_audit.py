#!/usr/bin/env python3
"""Read-only SDF/PAK/ODEF/RSEG research. Outputs only derived measurements, never retail payloads."""
from __future__ import annotations
import csv,collections,hashlib,json,math,pathlib,re,struct,sys,tarfile
from v18_resource_probe import z,zl,entry,decomp,chunks
P=pathlib.Path(__file__).resolve().parent
TAR=pathlib.Path('/mnt/data/i76_base(1).tar')
u32=lambda b,p:struct.unpack_from('<I',b,p)[0]
f32=lambda b,p:struct.unpack_from('<f',b,p)[0]

def write(fn,rows,fields=None):
 with (P/fn).open('w',newline='') as fp:
  w=csv.DictWriter(fp,fieldnames=fields or (list(rows[0]) if rows else ['empty']),delimiter='\t',extrasaction='ignore');w.writeheader();w.writerows(rows)

def sdf_info(key):
 sdfe=entry(key+'.sdf')
 if not sdfe:return None
 try:
  d=decomp(sdfe['offset'],sdfe['stored'],sdfe['usize'],sdfe['mode']); ch,_=chunks(d)
  sf=next(c for c in ch if c['tag']=='SDFC'); sg=next(c for c in ch if c['tag']=='SGEO')
  label=d[sf['offset']+8:sf['offset']+28].split(b'\0')[0].decode('latin1')
  cnt=u32(d,sg['offset']+8)
  if not (0<cnt<=12):return None
  comp=[]
  for ix in range(cnt):
   p=sg['offset']+12+ix*120;r=d[p:p+120];
   if len(r)!=120:return None
   comp.append(dict(name=r[:8].split(b'\0')[0].decode('latin1'),cls=u32(r,0x5c),matrix=struct.unpack_from('<9f',r,8),trans=struct.unpack_from('<3f',r,0x2c)))
  return {'key':key,'label':label,'components':comp,'sdf_size':len(d),'sdf_sha256':hashlib.sha256(d).hexdigest(),'variant_count':(sg['size']-12)//(cnt*120)}
 except (ValueError,StopIteration,struct.error,OverflowError):return None

def mesh_points(key,expected_name):
 e=entry(key+'g.pak')
 if not e:return None
 try:d=decomp(e['offset'],e['stored'],e['usize'],e['mode'])
 except ValueError:return None
 p=0
 while p+36<=len(d):
  if d[p:p+4]!=b'OEG.':break
  vcount=u32(d,p+24)
  nm=d[p+8:p+16].split(b'\0')[0].decode('latin1')
  if vcount>1024:break
  if nm==expected_name and p+36+12*vcount<=len(d):
   vertices=[struct.unpack_from('<3f',d,p+36+12*i) for i in range(vcount)]
   return {'vertices':vertices,'pak_sha256':hashlib.sha256(d).hexdigest(),'pak_size':len(d),'chunk_name':nm}
  nxt=d.find(b'OEG.',p+4)
  if nxt<0:break
  p=nxt
 return None

def shape(key, cache):
 if key not in cache:
  sf=sdf_info(key)
  if not sf or not sf['label'].startswith('Intersection'):
   cache[key]=None
  else:
   a=sf['components'][0]
   m=mesh_points(key,a['name'])
   if not m:cache[key]=None
   else:
    verts=m['vertices'];tx,ty,tz=a['trans']
    # The ODEF horizontal basis is stored column-major; geometry local transform (SDF) applied first.
    transformed=[]
    for x,y,z0 in verts:
     px=a['matrix'][0]*x+a['matrix'][3]*y+a['matrix'][6]*z0+tx
     pz=a['matrix'][2]*x+a['matrix'][5]*y+a['matrix'][8]*z0+tz
     transformed.append((px,pz))
    cache[key]={**sf,**m,'tile_local_vertices':transformed,'local_box':(min(x for x,_ in transformed),max(x for x,_ in transformed),min(y for _,y in transformed),max(y for _,y in transformed))}
 return cache[key]

def scan_chunks(b,start,end):
 p=start
 while p+8<=end:
  n=u32(b,p+4)
  if n<8 or p+n>end:break
  yield b[p:p+4],p,n
  p+=n

def read_mission(b,mission):
 sections={tag:(p,n) for tag,p,n in scan_chunks(b,0,len(b))}; objects=[];roads=[]
 o,n=sections[b'ODEF']
 for tag,p,sz in scan_chunks(b,o+8,o+n):
  if tag!=b'OBJ\0' or sz!=108:continue
  cls=u32(b,p+100)
  if cls not in (1,2,3,4,8,9,11,12,0x50,0x52,0x53):continue
  key=bytes(v&127 for v in b[p+8:p+16]).split(b'\0')[0].decode('ascii','replace').lower()
  pos=struct.unpack_from('<3f',b,p+0x34);rot=struct.unpack_from('<9f',b,p+0x10)
  objects.append(dict(mission=mission,cls=cls,key=key,offset=hex(p),pos=pos,rot=rot))
 o,n=sections[b'RDEF']
 for tag,p,sz in scan_chunks(b,o+8,o+n):
  if tag!=b'RSEG':continue
  kind,cnt=struct.unpack_from('<II',b,p+8)
  if cnt<2:continue
  for loc,ix in [('first',0),('last',cnt-1)]:
   off=p+16+24*ix
   ax,ay,az,bx,by,bz=struct.unpack_from('<6f',b,off)
   cx,cz=(ax+bx)/2,(az+bz)/2
   j=1 if ix==0 else ix-1
   tx,_,tz,ux,__,uz=struct.unpack_from('<6f',b,p+16+24*j)
   tangent=((tx+ux)/2-cx,(tz+uz)/2-cz)
   roads.append(dict(mission=mission,rseg=hex(p),end=loc,kind=kind,center=(cx,cz),edges=((ax,az),(bx,bz)),into=tangent))
 return objects,roads

def world_points(obj,sp):
 ox,oy,oz=obj['pos'];r=obj['rot'];out=[]
 for x,z in sp['tile_local_vertices']:
  out.append((ox +r[0]*x+r[6]*z,oz +r[2]*x+r[8]*z))
 return out

def ptsegdist(p,a,b):
 dx=b[0]-a[0];dy=b[1]-a[1];ll=dx*dx+dy*dy
 if ll<1e-12:return math.dist(p,a),a
 t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/ll))
 q=(a[0]+t*dx,a[1]+t*dy)
 return math.dist(p,q),q

def boundary_distance(p,box):
 l,r,b,t=box
 # actual quad border rather than axis aligned projection; enough for first canonical tile examples
 return min(ptsegdist(p,a,c)[0] for a,c in [((l,b),(r,b)),((r,b),(r,t)),((r,t),(l,t)),((l,t),(l,b))])

def main():
 cache={}
 # Enumerate archive .sdf names by index signature, no parsing of unrelated payload names.
 keys=set()
 for m in re.finditer(rb'[a-z0-9_]{1,8}\.sdf\x00',zl):
  key=m.group()[:-5].decode('ascii');keys.add(key)
 sdfrows=[]
 for key in sorted(keys):
  sp=sdf_info(key)
  if not sp or not sp['label'].startswith('Intersection'):continue
  sh=shape(key,cache)
  sdfrows.append(dict(resource=key+'.sdf',sdfc_title=sp['label'],geometry_name=sp['components'][0]['name'],sdf_class=sp['components'][0]['cls'],sgeo_translation=','.join(f'{x:.6f}' for x in sp['components'][0]['trans']),variants=sp['variant_count'],pak_vertices=len(sh['vertices']) if sh else 0,local_min_x=sh['local_box'][0] if sh else '',local_max_x=sh['local_box'][1] if sh else '',local_min_z=sh['local_box'][2] if sh else '',local_max_z=sh['local_box'][3] if sh else ''))
 intersection_keys={x['resource'][:-4] for x in sdfrows}
 print('intersection sdf resources:',len(sdfrows),'with geometry',sum(x['pak_vertices']>0 for x in sdfrows),'discovered sdf index names:',len(keys),flush=True)
 write('v18_intersection_sdf_geometry_inventory.tsv',sdfrows)
 # match all physical ODEF intersections to nearest RSEG terminals, using first-lod projected bounds.
 placements=[];candidates=[];roadcoverage=[];mat_pairs=[];per_mission=[]
 with tarfile.open(TAR) as t:
  missions=sorted(x for x in t.getnames() if '/miss8/' in x.lower() and x.lower().endswith('.msn'))
  for name in missions:
   b=t.extractfile(name).read();objs,roads=read_mission(b,name.rsplit('/',1)[-1]); ints=[]
   for o in objs:
    if o['key'] not in intersection_keys:continue
    sh=shape(o['key'],cache)
    if sh is None:continue
    coords=world_points(o,sh)
    bx=(min(x for x,z in coords),max(x for x,z in coords),min(z for x,z in coords),max(z for x,z in coords))
    oo={**o,'shape':sh,'box':bx,'coords':coords};ints.append(oo)
    placements.append(dict(mission=o['mission'],offset=o['offset'],resource=o['key'],odef_class=o['cls'],center_x=(bx[0]+bx[1])/2,center_z=(bx[2]+bx[3])/2,bbox_x0=bx[0],bbox_x1=bx[1],bbox_z0=bx[2],bbox_z1=bx[3],placement_x=o['pos'][0],placement_z=o['pos'][2],rotation_r00=o['rot'][0],rotation_r02=o['rot'][2],rotation_r20=o['rot'][6],rotation_r22=o['rot'][8]))
   count=0
   for end in roads:
    x,z=end['center']; possibilities=[]
    for o in ints:
     box=o['box']
     if box[0]-16<=x<=box[1]+16 and box[2]-16<=z<=box[3]+16:
      dd=boundary_distance((x,z),box)
      if dd<=20:
       # max edge point-to-box sides for confirming whole span matches exact boundary
       ea,eb=end['edges'];edge_dist=max(boundary_distance(ea,box),boundary_distance(eb,box))
       possibilities.append((dd,edge_dist,o))
    if possibilities:
     dd,ed,o=min(possibilities,key=lambda item:(item[0],item[1]));
     candidate=dict(mission=end['mission'],rseg=end['rseg'],end=end['end'],road_kind=end['kind'],cx=x,cz=z,road_edge_a_x=end['edges'][0][0],road_edge_a_z=end['edges'][0][1],road_edge_b_x=end['edges'][1][0],road_edge_b_z=end['edges'][1][1],intersection=o['key'],odef_offset=o['offset'],odef_class=o['cls'],model_center_x=(o['box'][0]+o['box'][1])/2,model_center_z=(o['box'][2]+o['box'][3])/2,center_edge_distance=dd,endpoints_to_tile_edge_max=ed)
     candidates.append(candidate)
     if dd<.05 and ed<.05:count+=1
   per_mission.append(dict(mission=name.rsplit('/',1)[-1],intersection_placements=len(ints),road_endpoints=len(roads),nearby_candidates=sum(x['mission']==name.rsplit('/',1)[-1] for x in candidates),exact_boundary_matches=count))
   print(name.rsplit('/',1)[-1], 'model objects',len(ints),'matched',count,'/',len(roads),flush=True)
 write('v18_intersection_placements.tsv',placements)
 write('v18_road_to_intersection_edge_candidates.tsv',candidates)
 write('v18_intersection_mission_summary.tsv',per_mission)
 exact=[x for x in candidates if x['center_edge_distance']<.05 and x['endpoints_to_tile_edge_max']<.05]
 touching=[x for x in candidates if x['center_edge_distance']<.05]
 summary=dict(retail_source_sha256=hashlib.sha256(__import__("v18_resource_probe").z).hexdigest(),mission_count=len(per_mission),indexed_sdf_resources=len(keys),intersection_resource_count=len(sdfrows),intersection_with_decoded_pak=sum(x['pak_vertices']>0 for x in sdfrows),intersection_placements=len(placements),road_endpoints=sum(x['road_endpoints'] for x in per_mission),road_endpoint_candidates_within_20=len(candidates),center_on_rectangle_boundary_within_005=len(touching),both_edge_points_on_rectangle_boundary_within_005=len(exact),class_counts=dict(collections.Counter(str(x['odef_class']) for x in placements)),top_intersection_resource_counts=collections.Counter(x['resource'] for x in placements).most_common(20),example_exact=exact[:12],example_fail=[x for x in candidates if x['center_edge_distance']>.1][:12],assumptions=['Transformed PAK vertex positions use SDF child translation plus ODEF transpose rotation','For candidate matching, rectangles are derived from projected PAK vertex extrema; nonrectangle polygon outline is NOT decoded','All records read from user-supplied retail assets; no game executable run','Distances are geometric analysis tolerances not verified engine acceptance thresholds'])
 (P/'v18_intersection_geometry_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('SUMMARY',json.dumps({k:v for k,v in summary.items() if not k.startswith('example')},indent=2),flush=True)

if __name__=='__main__':main()
