#!/usr/bin/env python3
"""Research-only forensic GEO parser, tested on shipped retail intersection PAK, not a runtime/editor implementation."""
import struct,math
from pathlib import Path
from collections import Counter
import sys
sys.path.insert(0,'/mnt/data/i76_roads_terrain_v18')
from v18_resource_probe import entry,decomp
U=lambda b,p:struct.unpack_from('<I',b,p)[0]

def decode_geo(data):
    allgeo=[];pos=0
    while pos+36<=len(data):
        if data[pos:pos+4]!=b'OEG.': raise ValueError(('tag',pos,data[pos:pos+16]))
        nv,nf=struct.unpack_from('<II',data,pos+24)
        if nv>100000 or nf>100000:raise ValueError(('counts',nv,nf))
        size=36+nv*24
        if pos+size>len(data):raise ValueError(('vertex overflow',pos,nv,nf,len(data)))
        name=data[pos+8:pos+24].split(b'\0')[0].decode('latin1')
        verts=[struct.unpack_from('<fff',data,pos+36+12*i) for i in range(nv)]
        normals=[struct.unpack_from('<fff',data,pos+36+12*nv+12*i) for i in range(nv)]
        cur=pos+size;faces=[]
        for i in range(nf):
            if cur+55>len(data):raise ValueError(('face header overflow',name,i,cur,len(data)))
            idx,nref=struct.unpack_from('<II',data,cur)
            if nref>nv*4 or nref<3 or cur+55+16*nref>len(data):raise ValueError(('face corner count',name,i,idx,nref,cur))
            refs=[struct.unpack_from('<IIff',data,cur+55+16*k) for k in range(nref)]
            if any(r[0]>=nv or r[1]>=nv for r in refs): raise ValueError(('ref index',name,i,nv,refs))
            texture=data[cur+34:cur+47].split(b'\0')[0].decode('latin1')
            poly=[verts[r[0]] for r in refs]
            faces.append(dict(index=idx,corner_count=nref,refs=refs,texture=texture,flags=data[cur+31:cur+34].hex(),rgb=data[cur+8:cur+11].hex(),plane=struct.unpack_from('<4f',data,cur+11),centroid_y=sum(v[1] for v in poly)/nref,vertices=[r[0] for r in refs]))
            cur+=55+16*nref
        allgeo.append(dict(name=name,vertices=verts,normals=normals,faces=faces,start=pos,end=cur,chunk_header_word=U(data,pos+4)))
        pos=cur
    if pos!=len(data):raise ValueError(('trailing bytes',pos,len(data),data[pos:pos+16]))
    return allgeo

def load_pak(key):
    e=entry(key+'g.pak')
    if not e:return []
    d=decomp(e['offset'],e['stored'],e['usize'],e['mode']);return decode_geo(d)
if __name__=='__main__':
 for name in ['itd27_1','ijd27t1','iga21_1','ica21_1','iyd27_1']:
  print('\n',name)
  try:
   models=load_pak(name)
   for m in models:
    print('  ',m['name'], 'vertices',len(m['vertices']),'faces',len(m['faces']),'offsets',m['start'],m['end'],'face',[(f['index'],f['corner_count'],f['texture'],tuple(round(x,5) for x in f['plane'])) for f in m['faces']])
  except Exception as e:print(' ERROR',repr(e))
