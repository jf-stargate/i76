# Interstate 76 road geometry research — v17

Primary report: V17_ROAD_ENDPOINT_INTERSECTION_AND_SURFACE_EDGE_CASES.md.

Run `python3 v17_road_endpoints_and_intersections.py` then `python3 v17_intersection_object_audit.py`, `python3 v17_anomalous_sample_windows.py`, and `python3 v17_validate.py` with your original user-provided `/mnt/data/i76_base(1).tar`. Outputs are read-only geometric measurements, not active-game rendering tests.

Ghidra assembly/decompilation input from v16 checkpoint (unchanged); v17 does not claim new Ghidra headless runs. No code or executable reconstruction. Two Ghidra user projects remain untouched. The ZIP intentionally omits original game/editor binaries, texture/SDF data, and original mission payloads.
