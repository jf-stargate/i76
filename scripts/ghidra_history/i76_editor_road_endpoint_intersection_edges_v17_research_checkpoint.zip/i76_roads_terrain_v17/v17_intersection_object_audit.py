#!/usr/bin/env python3
"""Cross-reference endpoints with mission ODEF object positions; do not assume class-4 is an intersection."""
import csv,tarfile,struct,math,collections,json,pathlib,statistics
P=pathlib.Path(__file__).parent

def scan(data):
 p=0
 while p+8<=len(data):
  sz=struct.unpack_from('<I',data,p+4)[0]
  if data[p:p+4]==b'ODEF':
   q=p+8
   while q+8<=p+sz:
    n=struct.unpack_from('<I',data,q+4)[0]
    if n<8:break
    if data[q:q+4]==b'OBJ\x00' and n==108:
     cls=struct.unpack_from('<I',data,q+0x64)[0]
     if cls in (2,3,4,11,12):
      key=bytes(b&127 for b in data[q+8:q+16]).split(b'\0',1)[0].decode('ascii','replace')
      x,y,z=struct.unpack_from('<3f',data,q+0x34)
      yield dict(cls=cls,key=key,x=x,z=z,y=y,offset=hex(q))
    q+=n
   break
  p+=sz

def wr(fn,rows):
 with (P/fn).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['none'],delimiter='\t');w.writeheader();w.writerows(rows)

r=list(csv.DictReader(open(P/'v17_road_endpoint_inventory.tsv'),delimiter='\t'))
out=[]; objfreq=collections.Counter(); binned=collections.Counter(); bridge=collections.Counter()
with tarfile.open('/mnt/data/i76_base(1).tar') as t:
 for name in sorted({e['mission'] for e in r}):
  data=t.extractfile('interstate 76/miss8/'+name).read();objs=list(scan(data))
  class4=[o for o in objs if o['cls']==4]
  for e in (v for v in r if v['mission']==name):
   x=float(e['x']);z=float(e['z']);rd=float(e['nearest_road_distance'])
   choices=sorted(((math.hypot(x-o['x'],z-o['z']),o) for o in class4),key=lambda v:v[0]);dist,o=choices[0] if choices else (float('inf'),None)
   bk=('0-5' if dist<=5 else '5-10' if dist<=10 else '10-20' if dist<=20 else '20-50' if dist<=50 else '50+')
   bridge[(bk,rd<=.02)]+=1
   if o and dist<=30:objfreq[o['key']]+=1
   out.append(dict(mission=name,road=e['road'],end=e['end'],x=x,z=z,nearest_road_end=rd,nearest_class4_distance=dist,class4_key=o['key'] if o else '',class4_x=o['x'] if o else '',class4_z=o['z'] if o else '',class4_obj_offset=o['offset'] if o else '',road_terrain_surface=e.get('material'),expected=e.get('expected_material'),surface_match=e.get('material_equivalent')))
wr('v17_road_end_class4_proximity.tsv',out)
metrics={
'objects_class4_at_nearest_end_by_radius': {str(radius):sum(float(o['nearest_class4_distance'])<=radius for o in out) for radius in (5,10,15,20,30,50,100)},
'nearest_class4_key_counts_within_30':[{'key':k,'count':v} for k,v in objfreq.most_common(35)],
'nearest_class4_distance_by_nearest_road_endpoint': [{'endpoint_distance_bucket':str(bool(m)),'class4_distance_bucket':b,'count':v} for (b,m),v in sorted(bridge.items())],
'candidate_intersection_key_prefixes':[{ 'key':k,'count':v} for k,v in objfreq.items() if any(s in k for s in ('int','cross','xin','stop','junc','4way','tway','3way'))],
}
(P/'v17_intersection_object_proximity.json').write_text(json.dumps(metrics,indent=2)+'\n')
print(json.dumps({k:v for k,v in metrics.items() if k != 'nearest_class4_distance_by_nearest_road_endpoint'},indent=2))
