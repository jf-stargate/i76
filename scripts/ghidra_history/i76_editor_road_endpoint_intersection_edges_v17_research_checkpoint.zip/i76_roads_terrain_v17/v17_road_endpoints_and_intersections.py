#!/usr/bin/env python3
"""Independent, read-only retail RSEG seam and ODEF proximity audit. Requires user retail TAR; outputs no original game bytes."""
from __future__ import annotations
import tarfile,struct,math,collections,csv,json,statistics,pathlib
from itertools import combinations
P=pathlib.Path(__file__).parent
TAR=pathlib.Path('/mnt/data/i76_base(1).tar')

def chunks(data,start,end):
 p=start
 while p+8<=end:
  n=struct.unpack_from('<I',data,p+4)[0]
  if n<8 or p+n>end: raise ValueError(('bad-chunk',p,n))
  yield data[p:p+4],p,n
  p+=n
 assert p==end,(p,end)

def sdist(a,b):return (a[0]-b[0])**2+(a[1]-b[1])**2

def norm(v):return math.hypot(*v)

def diff(a,b):return (a[0]-b[0],a[1]-b[1])

def center(s):return ((s[0]+s[2])/2,(s[1]+s[3])/2)

def cross(a,b):return a[0]*b[1]-a[1]*b[0]

def point(name,road,end,secs):
 s=secs[0 if end=='first' else -1];inw=secs[1 if end=='first' else -2];c=center(s); ci=center(inw);away=diff(ci,c)
 return dict(mission=name,road=road,end=end,x=c[0],z=c[1],edge_ax=s[0],edge_az=s[1],edge_bx=s[2],edge_bz=s[3],away_dx=away[0],away_dz=away[1],interior_segment_length=norm(away),sample_count=len(secs))

def wr(name,rows):
 with (P/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['none'],delimiter='\t');w.writeheader();w.writerows(rows)

def analyze():
 eps=[];joins=[];roadstats=[];od=[];close=[];misses=[]; all_material=collections.Counter();nearest_hist=collections.Counter();gap_hist=collections.Counter();branch_hist=collections.Counter(); object_keys=collections.Counter(); bad_ter=collections.Counter(); repair=[]
 with tarfile.open(TAR) as t:
  names=sorted(m.name for m in t.getmembers() if '/miss8/' in m.name.lower() and m.name.lower().endswith('.msn'))
  for entry in names:
   name=entry.rsplit('/',1)[-1];data=t.extractfile(entry).read();ter=t.extractfile(entry[:-3]+'TER').read()
   top={tag:(pos,length) for tag,pos,length in chunks(data,0,len(data))}
   rdef=top[b'RDEF'];tdef=top[b'TDEF'];odef=top[b'ODEF']
   zmap=next((p,n) for tag,p,n in chunks(data,tdef[0]+8,sum(tdef)) if tag==b'ZMAP')
   zm=data[zmap[0]+9:zmap[0]+9+6400]
   objs=[]
   for tag,p,n in chunks(data,odef[0]+8,sum(odef)):
    if tag==b'OBJ\x00' and n==108:
     cls=struct.unpack_from('<I',data,p+0x64)[0]
     if cls not in [1,2,3,4,8,9,11,12,0x50,0x52,0x53]:continue
     xyz=struct.unpack_from('<3f',data,p+0x34)
     raw=data[p+8:p+16]; key=bytes(x&127 for x in raw).split(b'\x00')[0].decode('ascii','replace')
     o={'mission':name,'class_id':cls,'key':key,'x':xyz[0],'z':xyz[2],'file_offset':hex(p)};objs.append(o);object_keys[(cls,key)]+=1
   endpoints=[];roads=[]
   for tag,p,n in chunks(data,rdef[0]+8,sum(rdef)):
    if tag!=b'RSEG':continue
    kind,num=struct.unpack_from('<II',data,p+8)
    if num==0:
     roadstats.append(dict(mission=name,offset=hex(p),kind=kind,sample_count=0,min_step='',max_step='',max_turn_degrees='',winding_flips=0,zero_steps=0,short_steps=0,long_steps=0));continue
    sec=[]
    for i in range(num):
     ax,_,az,bx,__,bz=struct.unpack_from('<6f',data,p+16+24*i);sec.append((ax,az,bx,bz))
    rid=hex(p);roads.append((rid,kind,sec));cs=list(map(center,sec));steps=[norm(diff(b,a)) for a,b in zip(cs,cs[1:])]
    turns=[]
    for a,b in zip([diff(cs[i+1],cs[i]) for i in range(len(cs)-1)],[diff(cs[i+1],cs[i]) for i in range(1,len(cs)-1)]):
     if norm(a)>1.e-9 and norm(b)>1.e-9:
      cosine=max(-1,min(1,(a[0]*b[0]+a[1]*b[1])/(norm(a)*norm(b))))
      turns.append(math.degrees(math.acos(cosine)))
    signs=[]
    for i in range(len(sec)-1):
     v=diff(cs[i+1],cs[i]);edge=diff((sec[i][2],sec[i][3]),(sec[i][0],sec[i][1]));a=cross(v,edge)
     if abs(a)>1.e-7:signs.append(1 if a>0 else -1)
    flips=sum(1 for a,b in zip(signs,signs[1:]) if a!=b)
    roadstats.append(dict(mission=name,offset=rid,kind=kind,sample_count=num,min_step=min(steps) if steps else '',max_step=max(steps) if steps else '',max_turn_degrees=max(turns) if turns else '',winding_flips=flips,zero_steps=sum(s<0.001 for s in steps),short_steps=sum(s<1 for s in steps),long_steps=sum(s>15 for s in steps)))
    if num>=2:
     for end in ['first','last']: endpoints.append(point(name,rid,end,sec))
   # all pairs of endpoints of DIFFERENT strip records; each strip already aggregates editable linked segments
   for idx,e in enumerate(endpoints):
    near=sorted(((math.sqrt(sdist((e['x'],e['z']),(b['x'],b['z']))),b) for b in endpoints if b['road']!=e['road']),key=lambda a:a[0])
    d,b=near[0] if near else (math.inf,None)
    e['nearest_road_distance']=round(d,6)
    e['nearest_road']=b['road'] if b else ''
    e['nearest_end']=b['end'] if b else ''
    category=('exact' if d<=0.02 else 'near_1' if d<=1 else 'near_2.5' if d<=2.5 else 'near_5' if d<=5 else 'near_10' if d<=10 else 'near_20' if d<=20 else 'far')
    nearest_hist[category]+=1
    ob=min(objs,key=lambda o:sdist((o['x'],o['z']),(e['x'],e['z']))) if objs else None
    if ob:
     e['nearest_object_distance']=round(math.sqrt(sdist((ob['x'],ob['z']),(e['x'],e['z']))),6)
     e['nearest_object_class']=ob['class_id']; e['nearest_object_key']=ob['key'];e['nearest_object_offset']=ob['file_offset']
     if d>2.5 and e['nearest_object_distance']<=30:
      close.append({'mission':name,'road':e['road'],'end':e['end'],'x':e['x'],'z':e['z'],'other_road_nearest':round(d,4),'nearest_object_distance':e['nearest_object_distance'],'class_id':ob['class_id'],'key':ob['key']})
    xi=round(e['x']/5);zi=round(e['z']/5)
    if not (0<=xi<10240 and 0<=zi<10240):continue
    zid=zm[zi//128*80+xi//128]
    if zid==255:continue
    m=struct.unpack_from('<H',ter,zid*0x8000+(zi%128)*256+(xi%128)*2)[0]>>13
    e['material']=m
    kind=next(ty for offset,ty,secs in roads if offset==e['road'])
    expected={0:2,1:3,2:4}.get(kind)
    e['expected_material']=expected
    e['material_equivalent']=expected==m or (expected,m) in [(2,6),(3,7)]
    all_material[(kind,m,e['end'])]+=1
    if not e['material_equivalent']:
     misses.append(dict(mission=name,road=e['road'],end=e['end'],x=e['x'],z=e['z'],expected=expected,material=m,nearest_road_distance=round(d,4),nearest_object_distance=e.get('nearest_object_distance',''),nearest_object_key=e.get('nearest_object_key','')))
   for i,a in enumerate(endpoints):
    for b in endpoints[i+1:]:
     if a['road']==b['road']:continue
     distance=math.sqrt(sdist((a['x'],a['z']),(b['x'],b['z'])))
     if distance>10:continue
     s1=((a['edge_ax'],a['edge_az']),(a['edge_bx'],a['edge_bz']))
     s2=((b['edge_ax'],b['edge_az']),(b['edge_bx'],b['edge_bz']))
     same=max(math.sqrt(sdist(s1[i],s2[i])) for i in range(2))
     flip=max(math.sqrt(sdist(s1[i],s2[1-i])) for i in range(2))
     ea=(a['away_dx'],a['away_dz']);eb=(b['away_dx'],b['away_dz']); ang=math.degrees(math.acos(max(-1,min(1,(ea[0]*eb[0]+ea[1]*eb[1])/(norm(ea)*norm(eb)))))) if norm(ea)>1e-6 and norm(eb)>1e-6 else None
     joins.append(dict(mission=name,road_a=a['road'],end_a=a['end'],road_b=b['road'],end_b=b['end'],center_distance=distance,edge_error_min=min(same,flip),edge_orientation='same' if same<=flip else 'flipped',away_tangent_angle=ang,ax=a['x'],az=a['z'],bx=b['x'],bz=b['z']))
   eps.extend(endpoints)
 wr('v17_road_endpoint_inventory.tsv',eps)
 wr('v17_near_endpoint_pairs.tsv',joins)
 wr('v17_road_strip_winding_spacing.tsv',roadstats)
 wr('v17_road_end_material_mismatches.tsv',misses)
 wr('v17_endpoint_near_world_objects.tsv',close)
 joins0=[j for j in joins if j['center_distance']<=.02]
 metrics={
  'missions':len(names),'road_strip_records':len(roadstats),'nonempty_road_strip_records':len(roadstats)-sum(not x['sample_count'] for x in roadstats),
  'endpoints':len(eps),'nearest_different_road_endpoint_class':dict(nearest_hist),
  'endpoint_pair_counts_by_dist':{str(c):sum(j['center_distance']<=c for j in joins) for c in (.001,.02,.1,1,2.5,5,10)},
  'exact_center_pairs':len(joins0),'exact_center_edge_match_0.05':sum(j['edge_error_min']<=.05 for j in joins0),
  'exact_center_edge_error_quantiles':{},'exact_center_tangent_angle_quantiles':{},
  'exact_center_pairs_with_tangent_bad_20_deg':sum(j['away_tangent_angle'] is not None and abs(180-j['away_tangent_angle'])>20 for j in joins0),
  'road_segments_with_winding_flips':sum(x['winding_flips']>0 for x in roadstats),
  'road_segments_with_steps_below_one':sum(x['short_steps']>0 for x in roadstats),
  'road_segments_with_steps_above_15':sum(x['long_steps']>0 for x in roadstats),
  'endpoint_material_mismatches':len(misses),
  'endpoint_object_near_with_no_near_road_count':len(close),
  'material_by_road_end': [{'kind':k,'terrain':m,'end':e,'count':v} for (k,m,e),v in sorted(all_material.items())],
  'most_common_odef_keys':[{'class':cls,'key':key,'count':v} for (cls,key),v in object_keys.most_common(30)],
  'pairs_exact_bad_examples':sorted((j for j in joins0 if j['edge_error_min']>.1 or abs(180-(j['away_tangent_angle'] or 180))>15),key=lambda j:(-j['edge_error_min'],abs(180-(j['away_tangent_angle'] or 180))))[:30],
 }
 for key,vals in [('exact_center_edge_error_quantiles',[j['edge_error_min'] for j in joins0]),('exact_center_tangent_angle_quantiles',[j['away_tangent_angle'] for j in joins0 if j['away_tangent_angle'] is not None])]:
  vals=sorted(vals)
  if vals:metrics[key]={str(q):vals[round((len(vals)-1)*q)] for q in (0,.25,.5,.75,.9,.95,.99,1)}
 (P/'v17_road_seam_metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
 print(json.dumps({k:v for k,v in metrics.items() if k not in ['most_common_odef_keys','pairs_exact_bad_examples','material_by_road_end']},indent=2))
 print('example keys',metrics['most_common_odef_keys'][:15]);print('bad pair examples',metrics['pairs_exact_bad_examples'][:8])
if __name__=='__main__':analyze()
