"""Audit X/Z strip reversal / zero-step conditions against exact RSEG source bytes."""
import csv,tarfile,struct,math,json,pathlib
P=pathlib.Path(__file__).parent
rows=list(csv.DictReader(open(P/'v17_road_strip_winding_spacing.tsv'),delimiter='\t'))
interesting=[r for r in rows if int(r['winding_flips']) or int(r['long_steps'])]
allrows=[]
with tarfile.open('/mnt/data/i76_base(1).tar') as t:
 for r in interesting:
  b=t.extractfile('interstate 76/miss8/'+r['mission']).read();p=int(r['offset'],16);n=struct.unpack_from('<I',b,p+12)[0]
  s=[]
  for i in range(n):
   ax,_,az,bx,__,bz=struct.unpack_from('<6f',b,p+16+i*24)
   s.append((ax,az,bx,bz))
  def ct(x):return ((x[0]+x[2])/2,(x[1]+x[3])/2)
  C=list(map(ct,s))
  for i in range(n-1):
   c=C[i];d=C[i+1];vx,vz=d[0]-c[0],d[1]-c[1];w=s[i][2]-s[i][0],s[i][3]-s[i][1]
   area=vx*w[1]-vz*w[0]
   c2=C[i+2] if i+2<n else None
   ang=''
   if c2 is not None:
    wx,wz=c2[0]-d[0],c2[1]-d[1]
    if math.hypot(vx,vz)>1.e-6 and math.hypot(wx,wz)>1.e-6:
     ang=math.degrees(math.acos(max(-1,min(1,(vx*wx+vz*wz)/(math.hypot(vx,vz)*math.hypot(wx,wz))))))
   allrows.append(dict(mission=r['mission'],road=r['offset'],sample=i,x=c[0],z=c[1],next_x=d[0],next_z=d[1],step_distance=math.hypot(vx,vz),width_orientation_cross=area,angle_to_next_degree=ang))
with (P/'v17_winding_anomaly_sample_windows.tsv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(allrows[0]),delimiter='\t');w.writeheader();w.writerows(allrows)
for r in interesting:
 subset=[x for x in allrows if x['mission']==r['mission'] and x['road']==r['offset']]
 suspect=[x for x in subset if x['step_distance']>15 or isinstance(x['angle_to_next_degree'],float) and x['angle_to_next_degree']>60]
 print(r['mission'],r['offset'],'N',r['sample_count'],'maxstep',r['max_step'],'maxangle',r['max_turn_degrees'],'suspect',suspect[:12]); print('distinct sign',sum(x['width_orientation_cross']<-.001 for x in subset),sum(x['width_orientation_cross']>.001 for x in subset))
