"""Validate frozen independently decoded v17 corpus outputs. Dynamic execution intentionally excluded."""
import csv,json,pathlib,hashlib
R=pathlib.Path(__file__).parent
j=json.loads((R/'v17_road_seam_metrics.json').read_text()); e=list(csv.DictReader(open(R/'v17_road_endpoint_inventory.tsv'),delimiter='\t'))
pairs=list(csv.DictReader(open(R/'v17_near_endpoint_pairs.tsv'),delimiter='\t'))
rs=list(csv.DictReader(open(R/'v17_road_strip_winding_spacing.tsv'),delimiter='\t'))
bad=list(csv.DictReader(open(R/'v17_road_end_material_mismatches.tsv'),delimiter='\t'))
obj=list(csv.DictReader(open(R/'v17_road_end_class4_proximity.tsv'),delimiter='\t'))
asserts={
 '40_independent_missions':j['missions']==40,
 '651_rseg':len(rs)==j['road_strip_records']==651,
 '650_populated_rseg':sum(int(x['sample_count'])>0 for x in rs)==650,
 '1300_endpoints':len(e)==j['endpoints']==1300,
 '27_coincident_center_pairs':sum(float(x['center_distance'])<=.02 for x in pairs)==27,
 '8_coincident_aligned_edges':sum(float(x['center_distance'])<=.02 and float(x['edge_error_min'])<=.05 for x in pairs)==8,
 '19_coincident_misaligned_edges':sum(float(x['center_distance'])<=.02 and float(x['edge_error_min'])>.05 for x in pairs)==19,
 '590_pairs_within_10':len(pairs)==590,
 '3_strips_with_orientation_flips':sum(int(x['winding_flips'])>0 for x in rs)==3,
 'T07_35_world_unit_step':any(x['mission']=='T07.MSN' and x['offset']=='0xcd5a' and float(x['max_step'])==35 for x in rs),
 'S04_958_samples':any(x['mission']=='S04.MSN' and x['offset']=='0x91c2' and int(x['sample_count'])==958 for x in rs),
 '251_endpoint_material_mismatches':len(bad)==251,
 'endpoint_odef_proximity_is_complete':len(obj)==len(e)==1300,
 'T05_zero_record':any(x['mission']=='T05.MSN' and x['kind']=='3072' and int(x['sample_count'])==0 for x in rs),
 'v16_reference_available':(pathlib.Path('/mnt/data/i76_editor_terrain_roads_materials_v16_research_checkpoint.zip').exists()),
 'retail_tar_available':(pathlib.Path('/mnt/data/i76_base(1).tar').exists()),
}
for x in e:
 if x['material_equivalent']=='False':assert any(b['mission']==x['mission'] and b['road']==x['road'] and b['end']==x['end'] for b in bad)
asserts['bad_endpoint_membership']=True
for a in asserts: assert asserts[a],a
out={'checks':asserts,'passed':len(asserts),'total':len(asserts),'v16_all_center_mismatches':739,'v17_endpoint_center_mismatches':251,'v17_interior_center_mismatches':739-251,'endpoint_material_mismatch_rate':251/1300,'interior_material_mismatch_rate':(739-251)/(89595-1300),'relative_endpoint_risk':(251/1300)/((739-251)/(89595-1300)), 'method_note':'Checks source-dependent frozen outputs; not runtime execution. v16 independent full-center total used for comparison.'}
(R/'v17_validation.json').write_text(json.dumps(out,indent=2)+'\n');print(f"{len(asserts)}/{len(asserts)} static checks passed. Endpoint mismatch rate {out['endpoint_material_mismatch_rate']:.4%}; interior {out['interior_material_mismatch_rate']:.4%}")
