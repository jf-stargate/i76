# Interstate '76 v17 — retail road endpoints, intersections and seam edge cases

**Date:** 2026-10-21. **Research focus:** original public editor road authoring limitations, retail baked RSEG geometry and physical surface-material seams. **Method:** independent Python byte decoding of the original user-supplied game archive, manual comparison, and reuse of frozen native editor/game decompilation/assembly evidence from the v16 research checkpoint. No code reconstruction, game execution, binary modification or Ghidra database mutation.

## Executive conclusions

1. **Keep authoring connectivity separate from baked geometry.** The original editor stores a connected graph of straight/cubic segments as 0x50-byte workspace records and exports sampled 24-byte RSEG cross sections; the game does not receive the authoring graph. A new editor should preserve that graph as its own editable source model and check *both* curve endpoint/tangent continuity and resulting left/right edge alignment.
2. **Coincident centers do not guarantee seamless pavement.** In 40 retail missions, 650 nonempty RSEG strips yield 1,300 first/last endpoints. Exactly **27 distinct inter-strip endpoint pairs** have coincident 2D centers (within 0.02 world unit). **Only eight** also have their best-corresponding two pavement edges within 0.05 world unit; **19** have greater edge differences. Largest best-paired edge difference **6.7720 world units** (S02 at 0xC462/0x16722). For all 27 pairs, the *outgoing-to-interior* endpoint tangent angle lies between **166.29° and 180°**, indicating mostly near-collinear seam geometry even where edges disagree. Some joins may be intentionally overlapped or concealed by meshes; a visual crack is not proved without runtime rendering.
3. **Most nearby endpoints are not coincident.** Among 590 distinct inter-strip endpoint pairs whose centers lie at most 10 world units apart, 354 are separated by ~**7.07107** (5 units in both X/Z), 208 by **10**, 27 by **0**, and one by **5**. These discrete spacings track the 5-unit grid and 10-unit road width. They cannot be interpreted as defective links merely because they are near; they may be different arms of intersections, parallel strips, deliberate gaps, or ends that terminate at an independent world object. Two-dimensional nearest-neighbor snapping would create false connections.
4. **The original retail road corpus itself contains geometric pathological cases.** Three road strips have sign reversals in their local directed cross-section orientation: M03 0x6C2A (sample 11→13 includes two consecutive 180° centerline reversals); S04 0x91C2 (958-sample strip, local turns of 106° and 150.48° with four orientation flips); T07 0xCD5A (180° reverse, followed by a **35.0-unit** centerline step and one orientation flip). These are byte-grounded candidate fold/self-overlap defects. Their visible impact and whether they are driven over remain untested.
5. **Physical road-surface agreement degrades sharply at the strip endpoints.** Reusing the v16 nearest-grid-cell algorithm (`round(X/5), round(Z/5)`, ZMAP indexing), 251 of the 1,300 terminal cross-section centers (**19.31%**) have a `.TER` surface index other than the road kind's expected material or a known parameter-equivalent alias (6→2 and 7→3). Compare 488 mismatches across the remaining 88,295 interior cross sections (**0.553%**), a **34.9× mismatch-rate concentration** at strip ends. These are physical material *classification mismatches*, not all proven traction differences: some indices may intentionally cover intersections or transitions, and terrain index conversion uses an approximate x87 rounding model. The prior independent v16 material census records 739 mismatches out of all 89,595 cross-section centers, consistent with this split.
6. **Intersections are separate resource-backed ODEF objects, not automatic junction geometry.** The contemporary `BUILDER.DOC` explicitly says road endpoints must be placed against intersection models; near-road snapping and tangent alignment require manual care. Our independent ODEF proximity census found 220 of 1,300 strip endpoints within 30 world units of a class-4 object, including common class-4 resource keys `sstop_1`, `sdxin_1`, and `sedet_1`. **Class-4 proximity alone does not prove a particular mesh fits the road opening**. Establishing the actual intersection mesh footprint and snapping sockets requires decoding/verifying the relevant SDF geometry, which was not part of v17.
7. **Road format/loader quirks matter.** The game `004B8780` splits long RSEG sample runs into runtime nodes, with a segment-size reduction loop and overlap. Shipped minimum populated length is **3 samples**, and **T05** retains a single `RSEG` chunk with **0** samples and kind **3072** (per rendering variant). A future writer should validate node-count and short-strip behavior, preserve long-strip continuity, and not invent an additional public road type from that anomalous chunk. Original editor has a 10/20-unit width branch; *all shipped populated RSEG records are nominally 10 units wide*. The four-lane controls are described as removed in the 1997 documentation.

## Evidence distinction and limitations

* **Direct retail-byte facts:** road endpoint/edge coordinates, quantized inter-endpoint distances, sample-step lengths, strip-direction reversals, OBJ placement coordinates, and `.TER` material samples. These were decoded directly from original `i76_base(1).tar`, 40 distinct missions in `miss8`. Since v16 established byte-identical RDEF and `.TER` across `miss8`/`miss16`, duplicating the count would not create independent evidence.
* **Direct original-editor observations, as established in v16:** `00415CA0` writes ROAD editable nodes, `00402550` dispatches straight/cubic sampling, `004030C0` generates strip edge pairs, `00421070` computes road surface material classes, `0040E3C0` renders/grades in several passes, `0041AAA0` packs terrain; game `004B8780` splits/loads RSEG, `0048E1A0` recomputes Y from terrain, and wheel contact samples `.TER` material via `004927B0`. Retained evidence windows are copied from the frozen v16 research, not freshly obtained v17 Ghidra runs.
* **Period manual observations:** intersections are independent objects, badly aligned intersection endpoints yield cracks, and tangents at straight/curve joins must match. `BUILDER.DOC` is bundled in the separately delivered original environment checkpoint; this package references but does not copy the retail manual.
* **Inference:** local winding sign reversals or edge mismatch can create rendering problems. Confirmation of an actual screen-space seam requires rendered game inspection, original SDF intersection mesh parsing, and/or terrain-aware geometry simulation.
* **Approximation:** material lookup uses Python `round(world/5)` to select a grid cell, as in the v16 audit; x87 tie and boundary behavior have not been reconstructed to bit-perfect precision. If a sample lies exactly at a half-cell boundary, a small number of classifications could change with accurate game-side rounding.

## Method: measured geometric join and material condition

For each nonempty RSEG, define cross-section center `C_i=(A_i+B_i)/2` and width vector `W_i=B_i-A_i`, using **X/Z only**. The two candidate ends are `C_0` and `C_(N-1)`; outward-to-interior tangent is `C_1-C_0` or `C_(N-2)-C_(N-1)`.

For any two *different* RSEG records within a mission:

- center gap `g=|C_a-C_b|`;
- optimal edge alignment `e=min(max(|A_a-A_b|,|B_a-B_b|), max(|A_a-B_b|,|B_a-A_b|))`, allowing reversed sample orientation;
- tangent angle `theta=acos(normalize(interior_a)·normalize(interior_b))`; near 180° implies a continuation where the interior directions point away from opposite sides of the junction.

A strict `g<=0.02` groups 27 coincident-center pairs, of which eight have `e<=0.05`. The 0.02 and 0.05 tolerances are **analysis diagnostics**, not proven engine acceptance tolerances; the game does not use these pairwise link tests when consuming baked strips.

Per strip, adjacent centerline differences `D_i=C_(i+1)-C_i` are measured. Winding sign uses `cross(D_i,W_i)`. Changes in its nonzero sign indicate local reversal/twist, though they are not equivalent to a full 3D triangle intersection proof.

The endpoint `TER` material comparison samples 1,300 endpoint centers. The expected index maps type 0→2, 1→3, 2→4, with 6 accepted as a parameter-equivalent form of 2 and 7 of 3. 251 endpoints differ; 88,295 non-endpoint cross sections have 488 mismatches under the same v16 rule. Note that some endpoint centers lie near 10-unit intersections where a different class is intentionally used; this is not proof of a game physics defect.

## Examples worth visual investigation

| Mission | RSEG pair or record | Direct evidence | Priority |
|---|---|---|---|
| S02 | `0xC462` ↔ `0x16722` | Same center `(2025,48015)`, best edge difference `6.7720`, outgoing angle `170.89°` | High, likely asymmetric seam/overlap |
| M06 | `0x4272` ↔ `0xA322` | Same center `(2460,49090)`, best edge difference `5.3730`, angle `178.73°` | High, almost straight but discontinuous boundaries |
| M03 | `0x6C2A` | local reversing samples (two 180° direction changes) | High, folded/degenerate road geometry |
| S04 | `0x91C2` | 958 samples; 106° and 150.48° local angle changes; four winding sign flips | High, curving road self-overlap risk |
| T07 | `0xCD5A` | 180° reversal and 35-unit step in 9-sample strip | High, short-road/terminal anomaly |
| T05 | `0x1B992` (miss8) | RSEG has 0 samples, kind 3072; one equivalent in miss16 | Parser robustness/sentinel case |

## Implications for a future editor (requirements research, not implementation)

**Store a source road graph.** In the editor's own project data retain cubic Bézier handles, start/end associations, road kind, nominal lane/width subtype, intended intersection attachment, and material/grade intent. Baking `RSEG` is a one-way lossy operation; importing a retail RSEG reconstructs only a sampled strip, not canonical source controls.

**Validate separate categories.** A useful validator should report (a) graph endpoint connectivity, (b) exact left/right pavement edge seam error, (c) tangential continuity, (d) local strip inversion/large turn/large sample spacing, (e) intersection model sockets once geometry is decoded, (f) road strip versus `.TER` material over the full width and at the terminal section, and (g) terrain height discontinuity in both road edges. Report each separately; do not auto-correct a 7.071-unit near point as a snapped link.

**Avoid overpromising road-width support.** The existing exporter has a 20-unit branch, but retail exemplars are all ~10 units wide, and the original builder manual states four-lane controls were cut. Treat 20-unit use as an unverified runtime/editor behavior to test rather than as validated.

**Retain shipped anomalies as negative fixtures.** Original retail missions are not perfect positive examples. M03/S04/T07 abnormal strips should serve as deliberately *flagged* examples to validate the diagnostic engine; the other 647 retail populated strips still have diverse curve/sampling cases to compare against.

## Further binary/data investigations

1. Trace `ROAD` workspace links and original endpoint snap radius in editor move/connect routines; check whether a stale link can survive disconnect and whether branching degree is bounded to two pointers.
2. Parse the `SDF/SGEO` resources for the class-4 road/intersection objects, identify mesh footprint boundaries/sockets and correlate their transformed edges to nearest RSEG terminals. Do not assume the nearest class-4 object actually owns a given terminal.
3. Cross-check whether the visual `RSEG` strips overlap or stop short of static intersection geometry; then test vertical seam after game's per-edge terrain-height sampling.
4. Decode the final 0x1000 `.TER` marker, surface 6/7 handling across **all** runtime consumers, and precise x87 terrain-grid rounding, especially for road endpoints.
5. Check game `004B8780` minimum-count and long-record splitting against malformed/short output, and investigate the shipped zero-sample T05 record.
6. Audit editor `ROAD` graph saver/load assembly with an actual editable `.I76` workspace once one becomes available. No `.I76` source file is present in our retail corpus, so byte-for-byte authoring round-trip is still unverified.

## Artifact inventory

- `v17_road_endpoints_and_intersections.py`: original mission decoder/endpoint geometry/terrain tests.
- `v17_intersection_object_audit.py`: cross-check original ODEF placements with road endpoints; proximity only.
- `v17_anomalous_sample_windows.py`: independent exact-source local geometry windows for three winding examples.
- `v17_road_endpoint_inventory.tsv`, `v17_near_endpoint_pairs.tsv`, `v17_road_strip_winding_spacing.tsv`, `v17_road_end_material_mismatches.tsv`: all observed quantitative outputs.
- `v17_road_end_class4_proximity.tsv`, `v17_endpoint_near_world_objects.tsv`: independent placed-object proximity checks, not proof of geometry.
- `v17_winding_anomaly_sample_windows.tsv`: all cross-section steps in the suspect strips.
- `v17_road_seam_metrics.json`, `v17_intersection_object_proximity.json`: summary and exact thresholds.
- `V17_SOURCE_LAYOUT_LEDGER.tsv`: provisional original editor/game translation-unit neighborhoods inherited from v16 and annotated for roadmap.
- `v17_validate.py`, `v17_validation.json`: reproducible consistency checks. The underlying Ghidra code evidence is supplied in the v16 checkpoint rather than represented as a new v17 headless execution.

**No original executable or copyrighted mission payload is redistributed in the report archive.** Original files are read-only input prerequisites for reproducing these outputs.
