# Interstate '76 original-code mission-loader emulator — v0.6.0

Original retail x86 instructions are executed in Ghidra 12.1.4. This checkpoint extends v0.5.0 from the generic BWD2 parser into the **selected-mission wrapper suffix, nested ADEF dispatch, and actual empty/nonempty FSM importer and finalizer**. It does not run a Windows game or reimplement mission parsing.

Read `ORIGINAL_MISSION_LOADER_EMULATION_REPORT.md` first for the exact emulated boundary and all caveats. `CONTRACT_ADDENDUM.md` records the new contract observations without replacing the earlier architecture specification.

## Prerequisites

- Ghidra 12.1.4 with a project containing the annotated retail program `i76_mission_v97_verified_names` (or identical matching retail program), MD5 `a640ea0097dbb62e0c77b7f2847c7161`.
- User-supplied unmodified retail `miss8/M06.MSN` and `miss8/T01.MSN`. **These files are not included.**
- Java 21, Python 3 for verification.

## Reproduce

```bash
GHIDRA=/path/to/ghidra_12.1.4_PUBLIC
PROJECT=/path/to/projects
SCRIPTS=/path/to/i76_parser_emulation_v0.6.0/scripts
OUTPUT=/path/to/i76_parser_emulation_v0.6.0

# M06: seven independent single-load cases and three preserved-memory pairs
"$GHIDRA/support/analyzeHeadless" "$PROJECT" retail \
  -process i76_mission_v97_verified_names -readOnly -noanalysis \
  -scriptPath "$SCRIPTS" \
  -postScript I76_MissionWrapper_OriginalCodeEmulator.java \
   "$OUTPUT/results" '/path/to/miss8/M06.MSN' \
  -log "$OUTPUT/results/ghidra.log" > "$OUTPUT/results/ghidra.stdout" 2>&1

# T01: one nonempty original FSM callback/importer/finalizer
"$GHIDRA/support/analyzeHeadless" "$PROJECT" retail \
  -process i76_mission_v97_verified_names -readOnly -noanalysis \
  -scriptPath "$SCRIPTS" \
  -postScript I76_MissionWrapper_OriginalCodeEmulator.java \
   "$OUTPUT/results_nonempty" '/path/to/miss8/T01.MSN' nonempty \
  -log "$OUTPUT/results_nonempty/ghidra.log" > "$OUTPUT/results_nonempty/ghidra.stdout" 2>&1

python3 "$OUTPUT/tools/validate_wrapper.py" --root "$OUTPUT" \
  --game-tar '/path/to/user-retail-game-archive.tar'
```

The `--game-tar` argument adds the original PE/fixture hash/size checks and is optional. No `bsearch` substitute ever reports a media asset as found; nonempty T01 diagnostic counts therefore reflect deliberately absent runtime services, not failed stock game content.

## Scope protection

- Emulated input mutations never alter retail files on disk.
- The annotated Ghidra project and canonical original executable are read-only.
- The callback hook boundaries are logged. A result of `1` from the wrapper is not a mission-loaded Boolean.
- Paired calls preserve original descriptor memory but stub FSM import; full mission teardown has not been simulated.
