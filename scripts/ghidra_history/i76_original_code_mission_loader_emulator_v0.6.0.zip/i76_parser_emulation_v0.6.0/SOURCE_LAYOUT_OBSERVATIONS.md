# Provisional translation-unit/source-layout addendum — v0.6.0

This note updates earlier source-layout *hypotheses*. It is not a recovered list of original .c/.h files.

- `004B3DB0` generic tagged-descriptor machine groups with `004B41E0` generic loader and nearby resource parsing helpers. Native nested parser dispatch and shared descriptor data at `00500328` and `00500D20` support a common resource/descriptor module. Confidence: medium for grouping, high for functional linkage.
- `004B42B0–004B4540` selected-mission wrapper and `004B45F0`, `004B4610`, `004B4790`, `004B89B0` section wrappers/revision and nested ADEF parser constitute a mission resource adapter around the generic parser. Cross-module separation is plausible, but cannot be proven from native adjacency. Confidence: medium-low for file boundary.
- `00409740` FSM chunk bootstrap and `00410720` table reader and `004125C0` finalizer are downstream, semantically distinct from BWD2 descriptor traversal. The emulation confirmed these units link by direct calls and preserve ordered table counts. Confidence: high for dependency; medium for separate original source unit.
- There is no reason to rename any function or infer exact historical filenames from these outcomes. The v97 Ghidra symbol baseline remains unchanged.
