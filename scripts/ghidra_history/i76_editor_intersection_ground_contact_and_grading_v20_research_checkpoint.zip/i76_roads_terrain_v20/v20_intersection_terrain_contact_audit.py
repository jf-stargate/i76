#!/usr/bin/env python3
"""Read-only original-resource audit: terrain wheel-contact height vs placed intersection GEO faces.
Research diagnostics only. NOT an editor, physics emulator, collision solver or game-format implementation.
"""
import csv, pathlib, sys, tarfile, struct, math, collections, statistics, json, hashlib
P=pathlib.Path(__file__).resolve().parent
sys.path[:0]=[str(P),'/mnt/data/i76_roads_terrain_v19','/mnt/data/i76_roads_terrain_v18']
from v19_face_socket_vertical_audit import transform, sample_ter, rd
from v19_geo_decode import load_pak
from v18_intersection_geometry_audit import sdf_info,read_mission
from v16_road_ground_surface_alignment import read_chunks

def inside(x,z,poly):
    ok=False
    for (xa,za),(xb,zb) in zip(poly,poly[1:]+poly[:1]):
        if (za>z)!=(zb>z) and x<xa+(z-za)*(xb-xa)/(zb-za):ok=not ok
    return ok

def material_at(x,z,ter,zm):
    # Retail 004927B0 rounds x/5,z/5 to nearest integral terrain cell; Python half-ties may differ.
    i=round(x/5);k=round(z/5)
    if not(0<=i<10240 and 0<=k<10240):return None
    zone=zm[(k//128)*80+(i//128)]
    if zone==255:return None
    offset=zone*32768+(k%128)*256+(i%128)*2
    if offset+2>len(ter):return None
    return struct.unpack_from('<H',ter,offset)[0]>>13

def y_at(x,z,poly):
    # Plane from any non-collinear X/Z triangle of the face. Do not confuse GEO plane coefficients
    # with a collision surface; these are rendered face vertices.
    for a in range(len(poly)-2):
        x0,z0,y0=poly[a]
        for b in range(a+1,len(poly)-1):
            x1,z1,y1=poly[b]
            for c in range(b+1,len(poly)):
                x2,z2,y2=poly[c]
                det=(x1-x0)*(z2-z0)-(x2-x0)*(z1-z0)
                if abs(det)>1e-6:
                    u=((x-x0)*(z2-z0)-(x2-x0)*(z-z0))/det
                    v=((x1-x0)*(z-z0)-(x-x0)*(z1-z0))/det
                    return y0+u*(y1-y0)+v*(y2-y0)
    return None

def write(name,rows,headers=None):
    with (P/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=headers or list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)

def main():
    aliases={r['alias_sdf'][:-4]:r['real_geometry_provider'][:-5] for r in rd(P/'v18_sdf_geometry_aliases.tsv')}
    inventory=rd(P/'v18_intersection_sdf_geometry_inventory.tsv')
    loaded={}
    for r in inventory:
        key=r['resource'][:-4];sf=sdf_info(key);geo=[g for g in load_pak(aliases.get(key,key)) if g['name']==sf['components'][0]['name']][0]
        loaded[key]=(sf,geo)
    placements=[];examples=[];rows=[];total=0
    with tarfile.open('/mnt/data/i76_base(1).tar') as t:
        names=sorted(n for n in t.getnames() if '/miss8/' in n.lower() and n.lower().endswith('.msn'))
        for n in names:
            mission=n.rsplit('/',1)[-1];b=t.extractfile(n).read();ter=t.extractfile(n[:-3]+'TER').read()
            o,p,_=next((o,p,s) for o,p,s in read_chunks(b,b'TDEF') if o==b'ZMAP')
            zm=b[p+9:p+9+6400]
            objs,roads=read_mission(b,mission)
            for obj in objs:
                if obj['key'] not in loaded:continue
                sf,geo=loaded[obj['key']]
                ox,oy,oz=obj['pos'];ry=sample_ter(ox,oz,ter,zm)
                vertices=transform({**obj,'pos':(ox,ry,oz)},sf,geo)
                spots={};face_areas=[]
                for face in geo['faces']:
                    poly=[vertices[i] for i in face['vertices']]
                    pxz=[(v[0],v[1]) for v in poly]
                    xmn=min(v[0] for v in poly);xmx=max(v[0] for v in poly)
                    zmn=min(v[1] for v in poly);zmx=max(v[1] for v in poly)
                    # Spatially oversample 5-unit terrain grid to capture interpolation / within-cell variations.
                    for ix in range(math.floor(xmn/2.5),math.ceil(xmx/2.5)+1):
                        x=ix*2.5
                        for iz in range(math.floor(zmn/2.5),math.ceil(zmx/2.5)+1):
                            z=iz*2.5
                            if not inside(x,z,pxz):continue
                            fp=y_at(x,z,poly)
                            if fp is None:continue
                            h=sample_ter(x,z,ter,zm)
                            mat=material_at(x,z,ter,zm)
                            spots[(ix,iz)]=(x,z,h,fp,mat,h-fp)
                if not spots:
                    examples.append((mission,obj['key'],obj['offset']))
                    continue
                total+=len(spots)
                samples=list(spots.values());gaps=[v[5] for v in samples];mg=[abs(g) for g in gaps]
                mats=collections.Counter(str(v[4]) for v in samples)
                row=dict(mission=mission,resource=obj['key'],object_offset=obj['offset'],samples=len(samples),x=obj['pos'][0],z=obj['pos'][2],runtime_root_y=ry,max_absolute_height_gap=max(mg),mean_abs_gap=sum(mg)/len(mg),median_abs_gap=statistics.median(mg),max_height_above_mesh=max(gaps),max_height_below_mesh=-min(gaps),fraction_abs_gap_over_0_1=sum(x>.1 for x in mg)/len(mg),fraction_abs_gap_over_0_25=sum(x>.25 for x in mg)/len(mg),fraction_abs_gap_over_0_5=sum(x>.5 for x in mg)/len(mg),surface_materials=';'.join(f'{k}:{v}' for k,v in sorted(mats.items())),fraction_road_material=sum(v for k,v in mats.items() if k in ('2','3','4','6','7'))/len(samples),fraction_paved_material=sum(v for k,v in mats.items() if k in ('2','6'))/len(samples))
                placements.append(row)
                if max(mg)>.25:
                    worst=max(samples,key=lambda v:abs(v[5]));examples.append(dict(mission=mission,resource=obj['key'],object_offset=obj['offset'],world_x=worst[0],world_z=worst[1],terrain_y=worst[2],mesh_y=worst[3],terrain_minus_mesh=worst[5],material=worst[4]))
    write('v20_intersection_footprint_per_placement.tsv',placements)
    write('v20_largest_footprint_discrepancies.tsv',sorted((x for x in examples if isinstance(x,dict)),key=lambda x:-abs(x['terrain_minus_mesh'])),headers=list(next(x for x in examples if isinstance(x,dict))))
    g=lambda k:[r[k] for r in placements]
    allg=g('max_absolute_height_gap')
    summary=dict(missions=len(names),intersection_placements=len(placements),footprint_samples=total,uncovered_placements=[x for x in examples if not isinstance(x,dict)],max_footprint_discrepancy=max(allg),median_placement_max_discrepancy=statistics.median(allg),placements_max_over_0_1=sum(v>.1 for v in allg),placements_max_over_0_25=sum(v>.25 for v in allg),placements_max_over_0_5=sum(v>.5 for v in allg),placements_max_over_1=sum(v>1 for v in allg),placements_wholly_paved_material=sum(r['fraction_paved_material']==1 for r in placements),placements_wholly_roadtype_material=sum(r['fraction_road_material']==1 for r in placements),placements_with_nonroad_material=sum(r['fraction_road_material']<1 for r in placements),total_samples_road_material_estimate=sum(r['fraction_road_material']*r['samples'] for r in placements)/total,top_cases=sorted(placements,key=lambda r:-r['max_absolute_height_gap'])[:15],caveats=['Footprint is an inferred visualization surface from first-level indexed GEO face polygons; no proof of collision mesh.','Samples 2.5 world units apart at world-aligned positions inside face polygons; not actual wheel trajectories.','Terrain height is bilinear from four packed low-12-bit TER samples scaled by 0.1; x87 exact rounding not emulated.','Material index uses nearest 5-unit terrain grid cell, replicating a separate lookup mechanism; Python round differs at exact half ties.','This is a research-only scanner; no original binaries or resources are modified.'])
    (P/'v20_intersection_footprint_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='top_cases'},indent=2));print('TOP');[print(r['mission'],r['resource'],r['object_offset'],r['max_absolute_height_gap'],r['surface_materials']) for r in summary['top_cases']]
if __name__=='__main__':main()
