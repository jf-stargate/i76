# v20 Road/Intersection Contact and Grading Research

Read `V20_INTERSECTION_CONTACT_TERRAIN_GRADE_AND_SURFACE_COMPATIBILITY.md` first.

`v20_intersection_terrain_contact_audit.py` recreates the intersection-footprint census from **original retail assets** at `/mnt/data/i76_base(1).tar` and existing v18/v19 read-only SDF/GEO decoding support. This is an offline research scanner; it does not produce a replacement editor or engine. Outputs are existing sampled terrain/mesh comparisons, not observed vehicle physics.

`v20_intersection_footprint_per_placement.tsv`: all 386 placements, per-polygon samples, max height discrepancy and sampled material mix.
`v20_largest_footprint_discrepancies.tsv`: worst sampled point in each high-discrepancy placement.
`v20_intersection_footprint_summary.json`: counts/metrics and explicit methodological caveats.
`v20_*_native_asm.txt`: GNU objdump from original retail PE images, independently checked MD5; executable bytes are not bundled.
`V20_SOURCE_NEIGHBORHOOD_LEDGER.tsv`: provisional translation-unit and subsystem localities, not proved original source files.
`v20_validate.py`, `v20_validation.json`: static verification. Run `python3 v20_validate.py` with the original PE byte inputs and v19 data available.

Both original annotated Ghidra programs were left untouched. No actual gameplay was measured or executable run. The original 1997 public builder's terrain algorithm and the game engine's potentially separate mesh collider are not yet fully reconstructed.
