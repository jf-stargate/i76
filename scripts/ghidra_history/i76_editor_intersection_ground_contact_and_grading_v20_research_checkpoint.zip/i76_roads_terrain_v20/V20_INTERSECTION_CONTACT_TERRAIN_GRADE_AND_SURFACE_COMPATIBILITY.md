# Interstate '76 — v20: Intersection contact, terrain grading, and physically relevant surface seams

**Research date:** 2026-10-21. **Scope:** original retail game and the original public level editor, with 40 unique shipped retail mission-geometry sets (`miss8`; the `miss16` road/terrain variants were already proven byte-identical in v19). **Method:** cross-check frozen v16/v19 Ghidra decompilation against independent disassembly of the actual retail PE images; scan the original SDF/GEO, ODEF, and TER data. No executables run, no annotated Ghidra databases modified, no source reimplementation.

## Executive findings

1. **Vehicle ground contact is explicitly terrain-driven.** Game function `00440740` transforms four wheel probes into world coordinates and calls the terrain height sampler `00493550` during the contact search. It subsequently calls `004931C0` for the packed terrain word and feeds contact state into `00438FD0`. The terrain-material index accessor `004927B0` and material-friction accessor `00492770` are separate from the RSEG strip renderer `0048E900`. The terrain sample's *height* and *material* lookup use different operations (bilinear versus nearest grid cell). This is proven for the inspected wheel-contact path; it is **not a proof that no other object/mesh collision occurs**.
2. **Intersection classes `0x50`, `0x52`, `0x53` follow a separate scene-geometry path.** ODEF handler `004B7AC0` does not call `004572B0` active-world registry insertion for those classes. It composes a child transform, invokes `004925F0` to calculate bounds and link the child into global scene geometry, and releases the temporary root. That global scene list might be accessed by rendering and/or collision; the use of the actual face polygons by collision remains **unproven**.
3. **Original editor grading is staged and nontrivial.** Editor `0040E3C0` processes base terrain, painted terrain, separate grading lines, object position/height refresh, *road chain grading*, object refresh, **four** passes of `00422870` smoothing, plane merge, cliff/special marking, and final object-height refresh. The smoothing routine gates modification on height availability and road-material codes 2–4; it averages neighborhood heights (the cell itself plus up to eight neighbors), so the operation is distinct from laying a flat polygon over the terrain.
4. **New original-resource measurement:** across **386 intersection placements** and **13,661 points** inside their *indexed first-LOD GEO face polygons*, median of the largest absolute terrain-to-visible-face difference per placement is ~**0.001** world units, yet **68** placements have a maximum discrepancy >0.1, **19** >0.25, **6** >0.5, and **3** >1.0. Maximum **1.4000006** in A01 (`ijd27t1`). All placements had usable interior samples.
5. **Terrain material differs from appearance inside many intersections.** Among these 13,661 polygon-interior points, 12,301 (90.04%) sample terrain materials 2, 3, 4, 6, or 7 (road types plus material-parameter aliases), and 1,360 sample other materials. Of 386 placements, 192 have road-type terrain throughout this sampled grid; 194 have at least one nonroad terrain sample. This is **not** a statement about the prefab's visible texture or a measured wheel route.

## Original game: contact lookup path (native assembly verified)

| Caller/site | Call target | Meaning supported by evidence |
| --- | --- | --- |
| `00440740` at `004407DE` | `00438810` | Calculates/upgrades contact-related normals/vectors; internal object geometry interaction is not fully reversed |
| `00440740` at `0044089C`, `004409B1`, `00440C32` | `00493550` | Repeated terrain-height sampling during four-point wheel contact search |
| `00440740` at `00440B8E` | `004931C0` | Reads packed terrain-cell data used in returned contact record |
| `00438FD0` | `00440740` | Vehicle ground contact and dynamics integration |
| `0043D240` | `00492770` | Terrain material friction used by vehicle runtime state |
| `0048E900` | RSEG runtime polygon list | Renders baked roads; no verified wheel-height registration in this path |

The native `00438810` routine calls object-transform/helper operations at `00461ED0`, `00494DA0`, and `00458C70`. Their complete semantics must be established before claiming that a wheel is *only* sensitive to heightfield data. **The ground-search comparisons themselves are demonstrably against `00493550` terrain height**, independently of what other normal/collision dispatchers do. Also note that an engine collision can move the vehicle independently of these four wheel probes; this pass did not exhaust the complete rigid-body collision graph.

The material lookup `004927B0` uses a 5-world-unit terrain grid and returns the high three bits of the fetched packed word. The wheel-ground height uses interpolation among terrain-height cells and height factor ~0.1. Hence the wheel can encounter a **traction discontinuity** at a surface-cell boundary even where its **height interpolation is continuous**. The known 6→2 and 7→3 *material-parameter* aliases are specifically equivalent in the sampled shipped `WRLD` records; they are not evidence that the surface *index* is equal.

### Intersection scene list is not active-world entity registration

The game ODEF native branch at `004B7D29–004B7DB4` uses active-world registration `004572B0` and instance lookup/ID registration `00457610` for ordinary class IDs. Classes `0x50`, `0x52`, and `0x53` divert at `004B7DB5`, compose the child transform at `00494E20`, then call `004925F0` at `004B7DE8` and release the temporary root at `004B7E0D`. The `004925F0` native routine updates bounding values, then links the geometry node under global list head `00644200` through `+0x60` pointers. **No inference that this list is rendering-only or collision-only is justified by this membership alone.** Its readers are the next high-priority investigation.

## Original editor: road grading versus placed intersections

Editor `0040E3C0` actual stage order, verified against the archived Ghidra decompile and native PE:

1. Initialize/render heightfield and rasterized zones.
2. Merge base terrain with painted terrain (`004125F0`).
3. Process independent grading lines.
4. Refresh placed objects' zone and height state.
5. Grade the linked road graph (`00420EE0 → 00421070 → {004215C0,00421830} → 00421DF0`).
6. Refresh objects again.
7. Apply **four** passes of road smoothing via thunk `004013CF → 00422870`, once per active zone per pass.
8. Merge graded maps, set special/cliff bits, and refresh object positions and views.

`00421DF0` uses separate passes (internal selector values 0–5) to initialize grading, rasterize road-footprint strips, write height through `0041F3A0`, write surface type through `0041F4A0`, and interpolate surrounding cells through `00421BE0`. Road kind 0 maps to terrain index 2, kind 1 to 3, kind 2 to 4 (an additional internal 3→2 switch exists, not evidence that public UI accepts kind 3).

The road smoothing at `00422870` checks source height != `0x8000` and terrain-material class >1 and <5. It gathers up to nine heights from the selected road cell and neighbors; a full-pass output buffer prevents sequential in-place changes during the pass. The decompiled integer rounding path merits further exact FPU analysis, so this study **does not** purport to reproduce each packed output bit. The original editor's explicit *four*-pass scheduling, however, is unambiguous.

**Not established:** Whether each intersection SDF prefab *itself* triggers polygon-footprint leveling in a separate object-grading helper. The public editor exposes placed intersections as objects, but visible intersection geometry alone does not imply that its surface contour is directly rasterized into the height plane. The 386-prefab terrain survey below proves retail levels contain both close fits and outliers; it does not prove which authoring action caused each outlier.

## New intersection-footprint measurement

The `v20_intersection_terrain_contact_audit.py` read-only scanner uses **the original retail resources**, *not* the historical GitHub format scripts as authorities:

- Resolve all 54 intersection SDF definitions to their first-LOD GEO geometry using the 40 real geometry packages and 14 proven shared aliases from v19.
- Parse the SDF child transform and indexed polygon faces; transform each face through its parent ODEF rotation, position and **terrain-projected root Y**.
- Sample world-aligned points every **2.5 world units** that fall inside a face's X/Z polygon. A repeated point shared by multiple faces of the same prefab is deduplicated.
- Compare bilinearly interpolated TER world height against the height of the transformed GEO polygon plane at each interior X/Z point.
- Retrieve the separate nearest-grid terrain material index. The diagnostic scanner uses Python rounding; exact half-cell ties may differ from original x87 behavior. Face coverage is a geometric proxy, **not a physics raycast**.

### Aggregate results

| Measurement | Result |
| --- | ---: |
| Distinct missions | 40 |
| Intersection objects with usable first-LOD faces | 386 |
| Total interior polygon probes | 13,661 |
| Median of per-prefab max absolute elevation difference | ~0.001 |
| Prefabs with max >0.10 | 68 |
| Prefabs with max >0.25 | 19 |
| Prefabs with max >0.50 | 6 |
| Prefabs with max >1.00 | 3 |
| Greatest reconstructed difference | ~1.400001 |
| Footprint samples with terrain road-class 2/3/4/6/7 | 12,301 (90.04%) |
| Samples in nonroad terrain classes | 1,360 (9.96%) |
| Prefabs exclusively sampled on terrain road classes | 192 |
| Prefabs with at least one nonroad sample | 194 |

### High-value source-derived fixtures

| Mission | GEO resource | ODEF OBJ offset | Terrain minus pavement at worst point | Material at that point |
| --- | --- | --- | ---: | ---: |
| A01 | `ijd27t1` | `0x938E` | +1.400001 | 0 |
| S03 | `ita21_1` | `0x10CAE` | −1.251000 | 2 |
| S04 | `ija2171` | `0x14C26` | +1.199000 | 1 |
| S04 | `ijd27t1` | `0x14BBA` | +0.800000 | 1 |
| T01 | `ijd27t1` | `0x13C56` | −0.599999 | 1 |
| S06 | `iyd27_1` | `0x185EE` | +0.550003 | 1 |
| T15 | `ild27_1` | `0x1C472` | +0.499993 | 0 |
| T07 | `ixd27_1` | `0xFAAE` | +0.399000 | 7 |

**A01 example:** The maximum occurs at `(X,Z)=(1617.5,49030.0)`; reconstructed wheel terrain is Y≈44.6 and placed pavement face is Y≈43.2. The first component's scene polygon is visually flat, but the underlying terrain is substantially higher at this point. The sampled material index is 0 rather than 2/3/4/6/7. An actual car crossing that exact point *could* experience height/contact and traction differences if its wheel probes follow the heightfield path; no runtime car trajectory has been measured.

**S03 example:** At `(2447.5,50252.5)`, the terrain height is ~21.95 and the face is ~23.201, so a car following only terrain height could appear visually below the intersection pavement. This illustrates why the sign of the height difference matters, not only the absolute magnitude.

Many nonroad material samples are likely near the exterior boundary or reflect intentional authoring and broader dirt transitions, but the purpose of these assignments is **not proven**. The investigation must not indiscriminately repaint official content.

## Practical implications for a future scratch-written editor (guidance, not implementation)

- Maintain separate authoring and validation layers for **road spline/mesh**, **intersection visible polygon**, **packed terrain-height**, and **terrain wheel-contact material**. Do not derive one from the others implicitly.
- Implement distinct warnings for endpoint socket X/Z mismatch, visible edge-vs-terrain Y gap, footprint-interior terrain displacement, and physical surface material discontinuity. Original content shows that these have different distributions.
- Keep official shipped anomalies as compatibility fixtures. Do not auto-correct the official 0.349-unit oblique family offsets, the up-to-0.5 exact-socket vertical mismatches, or the newly discovered up-to-1.4 interior mismatch without explicit user action.
- For preview, display both the visible prefab face and the terrain surface that the retail wheel-height routine probes. A generic rendered-mesh collision view would misrepresent part of the game's actual handling.
- When generating terrain material, honor the original kind mapping and separate nearest-cell material quantization from interpolated height; test at four wheel positions rather than centerline alone.
- Treat the game's potential separate static-geometry collision interaction as an open research dependency. Do not assert the first-LOD GEO polygons are the sole collision geometry.

## Validation, reproducibility and boundaries

`v20_validate.py` checks the two original retail PE MD5 identities, direct native contact call sites, static intersection scene-registration branch, editor four-pass schedule, all input placement and terrain-sample counts, height outliers, material distribution and cross-version v19 baseline. Artifacts intentionally exclude original game/editor executables, mission and TER payloads, packed SDF/PAK files, ZFS cache, and any vendor Ghidra runtime.

Frozen Ghidra material comes from the previous v16 checkpoint. This pass **did not complete a fresh Ghidra headless reanalysis**; native disassembly was performed independently on the verified original executable bytes. No original executable was run or modified.

### Next technically decisive research

Trace readers of the global geometry list rooted at `00644200`, including how `004925F0`'s bounds fields are consumed, and connect it to the game's rigid-body/environment collision routines. Separately, follow the editor's *object grading* callback invoked before and after road rasterization to determine whether intersection placements deliberately change terrain elevation or only inherit the already-graded heightfield. Both are necessary to establish the original collision and grading contract conclusively.
