#!/usr/bin/env python3
"""Static evidence validation for v20. Checks original byte identities and derived results."""
import pathlib,csv,json,hashlib,collections,sys,math
P=pathlib.Path(__file__).resolve().parent
checks=[]
def check(label,ok,detail=''):
    checks.append({'check':label,'pass':bool(ok),'detail':detail})
    if not ok:print('FAIL',label,detail)
def rows(n):return list(csv.DictReader(open(P/n,newline=''),delimiter='\t'))
def md5(p):return hashlib.md5(pathlib.Path(p).read_bytes()).hexdigest()
editor=P/'__retail_editor_tmp.exe';game=pathlib.Path('/mnt/data/i76_roads_terrain_v19/__retail_exe_not_for_distribution.exe')
check('editor original MD5',editor.exists() and md5(editor)=='4c7ed9e8a54fcadbf1895f34aa9918fe')
check('retail game original MD5',game.exists() and md5(game)=='a640ea0097dbb62e0c77b7f2847c7161')
a=(P/'v20_wheel_contact_native_asm.txt').read_text()
for site,target in [('4407de','438810'),('44089c','493550'),('4409b1','493550'),('440b8e','4931c0'),('440c32','493550')]:
    lines=[ln for ln in a.splitlines() if ln.lstrip().startswith(site+':')]
    check('wheel contact native call '+site+' -> '+target,len(lines)==1 and 'call' in lines[0] and '0x'+target in lines[0])
a=(P/'v20_intersection_static_scene_native_asm.txt').read_text()
for site,target in [('4b7d6d','4572b0'),('4b7da0','457610'),('4b7dc5','494e20'),('4b7de8','4925f0'),('4b7e0d','45ed70'),('4b82b5','493550')]:
    lines=[ln for ln in a.splitlines() if ln.lstrip().startswith(site+':')]
    check('SDF/ODEF native call '+site+' -> '+target,len(lines)==1 and 'call' in lines[0] and '0x'+target in lines[0])
for site,val in [('4b7d2c','0x50'),('4b7d35','0x52'),('4b7d3a','0x53')]:
    lines=[ln for ln in a.splitlines() if ln.lstrip().startswith(site+':')];check('special class discriminant '+site,len(lines)==1 and val in lines[0])
a=(P/'v20_static_geometry_registration_native_asm.txt').read_text()
for site in ['492694','492698','4926a4','4926a8','4926b1']:
    check('scene global linked list opcode '+site,any(ln.lstrip().startswith(site+':') for ln in a.splitlines()))
a=(P/'v20_editor_grading_order_native_asm.txt').read_text()
for site,target in [('40e488','401249'),('40e4d9','40150f'),('40e605','401249'),('40e63c','40e790'),('40e6a3','40124e')]:
    lines=[ln for ln in a.splitlines() if ln.lstrip().startswith(site+':')]
    check('editor terrain scheduler '+site,len(lines)==1 and 'call' in lines[0] and '0x'+target in lines[0])
check('v16 frozen editor decomp has four smoothing messages',(P/'editor_targeted_decomp.txt').read_text().count('s_Smoothing_Roads___Pass_')>=3)
check('native road smoothing contains source sentinel', '0x8000' in (P/'v20_editor_road_smoothing_native_asm.txt').read_text())
q=rows('v20_intersection_footprint_per_placement.tsv'); d=rows('v20_largest_footprint_discrepancies.tsv'); s=json.loads((P/'v20_intersection_footprint_summary.json').read_text())
check('one result per 386 placements',len(q)==386 and s['intersection_placements']==386)
check('40 missions scanned, 32 have identified intersection placements',len({v['mission'] for v in q})==32 and s['missions']==40)
check('13,661 footprint samples',sum(int(v['samples']) for v in q)==13661==s['footprint_samples'])
check('every placement has usable samples',min(int(v['samples']) for v in q)>0 and not s['uncovered_placements'])
check('all sample gap scalars finite',all(math.isfinite(float(v['max_absolute_height_gap'])) for v in q))
for t,n in [(0.1,68),(0.25,19),(0.5,6),(1,3)]:check('count height gap > '+str(t),sum(float(v['max_absolute_height_gap'])>t for v in q)==n)
check('maximum height gap ~1.4',abs(max(float(v['max_absolute_height_gap']) for v in q)-1.40000060260369)<1e-6)
check('source-derived A01 1.4 case',any(v['mission']=='A01.MSN' and v['resource']=='ijd27t1' and v['object_offset']=='0x938e' and abs(float(v['max_absolute_height_gap'])-1.4)<.0001 for v in q))
check('source-derived S03 1.25 case',any(v['mission']=='S03.MSN' and v['resource']=='ita21_1' and v['object_offset']=='0x10cae' and abs(float(v['max_absolute_height_gap'])-1.251)<.0001 for v in q))
check('source-derived S04 1.2 case',any(v['mission']=='S04.MSN' and v['resource']=='ija2171' and v['object_offset']=='0x14c26' and abs(float(v['max_absolute_height_gap'])-1.199)<.0001 for v in q))
check('12,301 samples in road-class materials',sum(round(float(v['fraction_road_material'])*int(v['samples'])) for v in q)==12301)
check('192 road-material-only placements',sum(float(v['fraction_road_material'])==1 for v in q)==192)
check('194 mixed placements',sum(float(v['fraction_road_material'])<1 for v in q)==194)
check('all highest-discrepancy cases include record coords',len(d)>=19 and all('world_x' in v and 'terrain_y' in v for v in d))
check('known v19 762 socket exact baseline',json.loads((P/'v19_true_polygon_3d_summary.json').read_text())['both_road_corners_match_true_boundary_within_005']==762)
check('old source ledger frozen from evidence',(P/'V20_SOURCE_NEIGHBORHOOD_LEDGER.tsv').exists())
result={'version':'v20','date':'2026-10-21','passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks),'checks':checks,'source_qualification':'Native PE assembly plus frozen Ghidra and original retail resources; no live runtime execution.'}
(P/'v20_validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(f"{result['passed']}/{len(checks)} static evidence checks pass")
sys.exit(1 if result['failed'] else 0)
