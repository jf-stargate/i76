# v18 intersection geometry research checkpoint

Contains derived geometry measurements and reproducible parsers, **not** retail game files. Read `V18_INTERSECTION_SDF_PAK_MESH_AND_ROAD_SOCKET_ALIGNMENT.md` before using the tables.

Requirements: original user-provided retail TAR at `/mnt/data/i76_base(1).tar`; Python 3.11+, system `liblzo2`, matplotlib only for optional diagrams. The SDF geometry probe reads ZFS directly from the TAR if the private scratch ZFS cache is absent.

Suggested run order: `python v18_intersection_geometry_audit.py`; `python v18_polygon_socket_audit.py`; `python v18_alias_and_anomalies.py`; `python v18_validate.py`. Optionally run `python v18_make_geometry_diagrams.py`. Each writes into its script directory, without modifying source assets.

The name-based SDF↔PAK geometry alias correspondence is *not* a verified runtime alias loading behavior. The polygon metric uses projected convex-hull boundaries, not parsed polygon-face topology. All stated tolerances are researcher-defined, not engine rules.
