#!/usr/bin/env python3
"""Geometric RSEG-vs-SDF/PAK polygon-hull boundary checks, read-only retail artifacts."""
from __future__ import annotations
import csv,math,collections,json,statistics,pathlib
from v18_intersection_geometry_audit import shape
P=pathlib.Path(__file__).resolve().parent
V17=P
def rd(path):return list(csv.DictReader(open(path,newline=''),delimiter='\t'))
def wr(name,rows,fields=None):
 with (P/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields or list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
def hull(pts):
 pts=sorted(set((round(x,5),round(y,5)) for x,y in pts))
 if len(pts)<=2:return pts
 def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
 lo=[]
 for p in pts:
  while len(lo)>=2 and cross(lo[-2],lo[-1],p)<=1e-6:lo.pop()
  lo.append(p)
 hi=[]
 for p in reversed(pts):
  while len(hi)>=2 and cross(hi[-2],hi[-1],p)<=1e-6:hi.pop()
  hi.append(p)
 return lo[:-1]+hi[:-1]
def distseg(p,a,b):
 dx=b[0]-a[0];dy=b[1]-a[1];den=dx*dx+dy*dy
 if den<1e-12:return math.dist(p,a)
 t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/den))
 return math.dist(p,(a[0]+dx*t,a[1]+dy*t))
def vdot(a,b):return a[0]*b[0]+a[1]*b[1]
def main():
 inventory={r['resource'][:-4]:r for r in rd(P/'v18_intersection_sdf_geometry_inventory.tsv')}
 placements=rd(P/'v18_intersection_placements.tsv')
 endpoints=rd(V17/'v18_prior_road_endpoint_inventory.tsv')
 cache={}; by_m=collections.defaultdict(list)
 for p in placements:
  key=p['resource'];sp=shape(key,cache)
  if not sp:continue
  ox=float(p['placement_x']);oz=float(p['placement_z']);r00=float(p['rotation_r00']);r02=float(p['rotation_r02']);r20=float(p['rotation_r20']);r22=float(p['rotation_r22'])
  pts=[(ox+r00*x+r20*z,oz+r02*x+r22*z) for x,z in sp['tile_local_vertices']]
  pg=hull(pts)
  if len(pg)<3:continue
  bb=(min(x for x,y in pg),max(x for x,y in pg),min(y for x,y in pg),max(y for x,y in pg))
  o=dict(placement=p,poly=pg,bbox=bb,segments=list(zip(pg,pg[1:]+pg[:1])),center=(sum(x for x,y in pg)/len(pg),sum(y for x,y in pg)/len(pg)),area=abs(sum(x1*y2-y1*x2 for (x1,y1),(x2,y2) in zip(pg,pg[1:]+pg[:1]))/2))
  by_m[p['mission']].append(o)
 joined=[];best=[];class_stats=collections.Counter()
 for e in endpoints:
  cx=float(e['x']);cz=float(e['z']);ap=(float(e['edge_ax']),float(e['edge_az']));bp=(float(e['edge_bx']),float(e['edge_bz']))
  away=(float(e['away_dx']),float(e['away_dz']))
  mm=e['mission'];cb=[]
  for o in by_m[mm]:
   bx=o['bbox']
   if not (bx[0]-15<=cx<=bx[1]+15 and bx[2]-15<=cz<=bx[3]+15):continue
   segments=o['segments']; dcenter=min(distseg((cx,cz),a,b) for a,b in segments)
   same=min(max(distseg(ap,a,b),distseg(bp,a,b)) for a,b in segments)
   if dcenter>15:continue
   dist_on=min(math.dist((cx,cz),a) for a in o['poly'])
   cc=o['center'];out=(cx-cc[0],cz-cc[1]); sign=vdot(out,away)
   cb.append(dict(mission=mm,road=e['road'],end=e['end'],x=cx,z=cz,resource=o['placement']['resource'],obj_offset=o['placement']['offset'],object_class=o['placement']['odef_class'],center_to_polygon_edge=dcenter,whole_road_edge_to_one_polygon_segment=same,road_interior_outward_dot=sign,nearest_polygon_vertex=dist_on,road_material=e.get('material',''),material_expected=e.get('expected_material',''),material_equivalent=e.get('material_equivalent',''),mesh_area=o['area'],mesh_vertex_count=len(o['poly'])))
  if cb:
   choice=min(cb,key=lambda x:(x['whole_road_edge_to_one_polygon_segment'],x['center_to_polygon_edge']))
   best.append(choice)
   joined.extend(cb)
 exact=[v for v in best if v['whole_road_edge_to_one_polygon_segment']<.05 and v['center_to_polygon_edge']<.05]
 center=[v for v in best if v['center_to_polygon_edge']<.05]
 # assess material mismatches at strict snapped endpoints vs all other endpoints
 exact_keys={(v['mission'],v['road'],v['end']) for v in exact}
 with_mat=[r for r in endpoints if r['material']!='']
 mmatch=lambda r: r['material_equivalent'].lower()=='false'
 m_tot=sum(mmatch(r) for r in with_mat)
 pair=[]
 for label,sub in [('geometrically_exact',[r for r in with_mat if (r['mission'],r['road'],r['end']) in exact_keys]),('other_road_ends',[r for r in with_mat if (r['mission'],r['road'],r['end']) not in exact_keys])]:
  pair.append(dict(group=label,terminal_count=len(sub),material_mismatches=sum(mmatch(r) for r in sub),rate=sum(mmatch(r) for r in sub)/len(sub) if sub else 0))
 wr('v18_polygon_socket_candidates.tsv',best)
 wr('v18_polygon_socket_material_correlation.tsv',pair)
 # per shape kind / subtype, verified boundary match rates
 per=[]
 by_key=collections.defaultdict(list)
 for x in best:by_key[x['resource']].append(x)
 for k,ls in sorted(by_key.items()):
  per.append(dict(resource=k,matched_endpoints=len(ls),polygon_full_edge_matches=sum(x['whole_road_edge_to_one_polygon_segment']<.05 and x['center_to_polygon_edge']<.05 for x in ls),loose_near_intersection=sum(x['whole_road_edge_to_one_polygon_segment']<1. for x in ls),mean_polygon_area=statistics.mean(x['mesh_area'] for x in ls)))
 wr('v18_polygon_socket_by_resource.tsv',per)
 out=dict(missions=len(by_m),intersections=sum(map(len,by_m.values())),terminal_total=len(endpoints),matched_any_near_mesh=len(best),terminal_centers_within_005_of_convex_mesh_outline=len(center),full_road_edge_to_single_hull_segment_within_005=len(exact),full_road_edge_to_single_hull_segment_within_05=sum(x['whole_road_edge_to_one_polygon_segment']<.5 for x in best),on_edge_and_away_direction_outward=sum(x['road_interior_outward_dot']>0 for x in exact),on_edge_and_away_direction_nonoutward=sum(x['road_interior_outward_dot']<=0 for x in exact),material_by_geometry_group=pair,intersection_resource_matches=len(by_key),notes=['This uses the convex hull of decoded first-LOD PAK geometry; concave polygon holes/negative space are not yet reconstructed.','All distances are X/Z plane; terrain height sampling and Y seam remain to be checked.','The selection is the best full-edge distance among nearby model objects, not a documented editor socket lookup.'])
 (P/'v18_polygon_socket_summary.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
 print('EXACT/examples')
 for x in exact[:5]:print(x)
 print('FAIL examples')
 for x in sorted((v for v in best if v['whole_road_edge_to_one_polygon_segment']>.1),key=lambda x:-x['whole_road_edge_to_one_polygon_segment'])[:10]:print(x)
if __name__=='__main__':main()
