#!/usr/bin/env python3
import csv,collections,json,math,pathlib
from v18_intersection_geometry_audit import sdf_info
P=pathlib.Path(__file__).resolve().parent
def read(n):return list(csv.DictReader(open(P/n),delimiter='\t'))
def write(n,rows):
 with open(P/n,'w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
rows=read('v18_intersection_sdf_geometry_inventory.tsv'); owners={r['geometry_name']:r['resource'][:-4] for r in rows if int(r['pak_vertices'])}
alias=[]
for r in rows:
 if int(r['pak_vertices']):continue
 k=r['resource'][:-4];owner=owners[r['geometry_name']]
 a=sdf_info(k)['components'][0];b=sdf_info(owner)['components'][0]
 transdiff=max(abs(x-y) for x,y in zip(a['trans'],b['trans']))
 matdiff=max(abs(x-y) for x,y in zip(a['matrix'],b['matrix']))
 alias.append(dict(alias_sdf=r['resource'],real_geometry_provider=owner+'g.pak',shared_sgeo_component=r['geometry_name'],sdf_local_transform_max_diff=transdiff,sdf_class_id_alias=a['cls'],sdf_class_id_provider=b['cls'],exact_transform_and_class=(transdiff==0 and matdiff==0 and a['cls']==b['cls'])))
write('v18_sdf_geometry_aliases.tsv',alias)
ends=read('v18_polygon_socket_candidates.tsv')
others=[]
for p in read('v18_intersection_placements.tsv'):
 a=math.degrees(math.atan2(-float(p['rotation_r02']),float(p['rotation_r00'])))%360
 deviation=min(abs((a-k+180)%360-180) for k in (0,90,180,270))
 if deviation<=1:continue
 cands=[q for q in ends if q['mission']==p['mission'] and q['obj_offset']==p['offset']]
 others.append(dict(mission=p['mission'],resource=p['resource'],odef_offset=p['offset'],rotation_degrees=a,nearest_cardinal_error_degrees=deviation,placement_x=p['placement_x'],placement_z=p['placement_z'],road_endpoints_nearby=len(cands),closest_road_center_to_polygon=min((float(q['center_to_polygon_edge']) for q in cands),default=float('nan')),closest_whole_edge_error=min((float(q['whole_road_edge_to_one_polygon_segment']) for q in cands),default=float('nan'))))
write('v18_noncardinal_intersection_placements.tsv',others)
print('aliases',len(alias),'all exact',all(q['exact_transform_and_class'] for q in alias),'noncardinal intersection placements',len(others))
