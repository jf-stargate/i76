#!/usr/bin/env python3
"""Re-run data relationship assertions on derived tables and the original retail archive."""
import csv,math,tarfile,struct,json,pathlib,hashlib,collections
P=pathlib.Path(__file__).resolve().parent
TAR=pathlib.Path('/mnt/data/i76_base(1).tar')
checks={}
def ck(label,test):
 checks[label]=bool(test)
 if not test:raise AssertionError(label)
def table(name):return list(csv.DictReader(open(P/name,newline=''),delimiter='\t'))
sdf=table('v18_intersection_sdf_geometry_inventory.tsv');pl=table('v18_intersection_placements.tsv');fits=table('v18_polygon_socket_candidates.tsv');aliases=table('v18_sdf_geometry_aliases.tsv');anom=table('v18_noncardinal_intersection_placements.tsv');mission=table('v18_intersection_mission_summary.tsv');mat=table('v18_polygon_socket_material_correlation.tsv')
b=json.loads((P/'v18_intersection_geometry_summary.json').read_text());s=json.loads((P/'v18_polygon_socket_summary.json').read_text())
ck('40_mission_files',len(mission)==40)
ck('54_intersection_sdf',len(sdf)==54)
ck('40_direct_sdf_pak_pairs',sum(int(x['pak_vertices'])>0 for x in sdf)==40)
ck('14_geometry_aliases',len(aliases)==14)
ck('all_alias_sgeo_transforms_and_classes_exact',all(x['exact_transform_and_class']=='True' for x in aliases))
ck('only_SDFC_intersection_title',all(x['sdfc_title'].startswith('Intersection') for x in sdf))
ck('303_placed_objects',len(pl)==303)
ck('1300_road_endpoints',sum(int(x['road_endpoints']) for x in mission)==1300)
ck('placed_class_domain',set(int(x['odef_class']) for x in pl)=={80,82,83})
ck('class_count_80',sum(x['odef_class']=='80' for x in pl)==178)
ck('class_count_82',sum(x['odef_class']=='82' for x in pl)==123)
ck('class_count_83',sum(x['odef_class']=='83' for x in pl)==2)
ck('number_near_polygon_hull',len(fits)==764)
ck('617_exact_road_socket_matches',sum(float(x['whole_road_edge_to_one_polygon_segment'])<.05 and float(x['center_to_polygon_edge'])<.05 for x in fits)==617)
ck('674_center_on_polygon_edge',sum(float(x['center_to_polygon_edge'])<.05 for x in fits)==674)
ck('all_strict_socket_tangents_point_away',all(float(x['road_interior_outward_dot'])>0 for x in fits if float(x['whole_road_edge_to_one_polygon_segment'])<.05 and float(x['center_to_polygon_edge'])<.05))
ck('material_total',sum(int(x['terminal_count']) for x in mat)==1300)
ck('material_mismatches_251',sum(int(x['material_mismatches']) for x in mat)==251)
ck('material_mismatches_on_exact_intersections_105',mat[0]['group']=='geometrically_exact' and int(mat[0]['terminal_count'])==617 and int(mat[0]['material_mismatches'])==105)
ck('three_off_cardinal_rotations',len(anom)==3)
ck('all_three_off_cardinal_have_discontinuous_socket',all(float(x['closest_whole_edge_error'])>1.5 for x in anom))
# Use the raw retail file for an independently grounded A01 geometric endpoint check.
with tarfile.open(TAR) as t:
 data=t.extractfile('interstate 76/miss8/A01.MSN').read()
for off,want in [(0x1ada,(1795.0,50370.0,1805.0,50370.0)),(0x22ca,(1610.0,49030.0,1610.0,49040.0))]:
 cnt=struct.unpack_from('<I',data,off+12)[0];i=cnt-1 if off==0x1ada else 0
 va=struct.unpack_from('<6f',data,off+16+i*24)
 ck('A01_raw_road_edge_'+hex(off),all(abs(a-b)<1e-5 for a,b in zip((va[0],va[2],va[3],va[5]),want)))
ck('summaries_agree',b['intersection_placements']==len(pl) and s['full_road_edge_to_single_hull_segment_within_005']==617)
with tarfile.open(TAR) as t:
 raw=t.extractfile('interstate 76/I76.ZFS').read()
 ck('zfs_digest_matches_analysis',hashlib.sha256(raw).hexdigest()==b['retail_source_sha256'])
report=dict(scope='v18 read-only static data tests; no runtime or editor gameplay tested',checks_passed=sum(checks.values()),checks_total=len(checks),all_passed=all(checks.values()),checks=checks)
(P/'v18_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(f"V18_VALIDATION_OK {report['checks_passed']}/{report['checks_total']}")
