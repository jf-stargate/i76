#!/usr/bin/env python3
"""Source-faithful deterministic top-down diagrams, not original textures or game captures."""
import pathlib,tarfile,struct,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from v18_intersection_geometry_audit import read_mission,shape,world_points
from v18_polygon_socket_audit import hull
P=pathlib.Path(__file__).resolve().parent
with tarfile.open('/mnt/data/i76_base(1).tar') as t:
 b=t.extractfile('interstate 76/miss8/A01.MSN').read()
 objs,_=read_mission(b,'A01.MSN')
 cache={}
 for res,road,idx,out in [('itd27_1','0x1ada',-1,'v18_A01_itd27_1_socket.png'),('ijd27t1','0x22ca',0,'v18_A01_ijd27t1_socket.png')]:
  obj=next(o for o in objs if o['key']==res)
  sh=shape(res,cache)
  mesh=hull(world_points(obj,sh))
  addr=int(road,16);n=struct.unpack_from('<I',b,addr+12)[0]
  samples=[]
  chosen=range(max(0,n-5),n) if idx<0 else range(0,min(5,n))
  for j in chosen:
   ax,ay,az,bx,by,bz=struct.unpack_from('<6f',b,addr+16+24*j)
   samples.append(((ax,az),(bx,bz)))
  fig,ax=plt.subplots(figsize=(7,7))
  xs=[x for x,y in mesh]+[mesh[0][0]];ys=[y for x,y in mesh]+[mesh[0][1]]
  ax.fill(xs,ys,alpha=.17,label='Intersection mesh convex outline')
  ax.plot(xs,ys,linewidth=2,label='Transformed intersection geometry')
  for j,(a,c) in enumerate(samples):
   ax.plot([a[0],c[0]],[a[1],c[1]],linewidth=1.2 if j!=len(samples)-1 else 2.0,alpha=.7)
  aa,cc=samples[-1] if idx<0 else samples[0]
  ax.plot([aa[0],cc[0]],[aa[1],cc[1]],linewidth=3,label='Terminal RSEG cross-section')
  ax.scatter([aa[0],cc[0]],[aa[1],cc[1]],s=40,label='Exact road-edge endpoints')
  ax.set_aspect('equal', adjustable='datalim');ax.grid(alpha=.3)
  ax.set_xlabel('World X');ax.set_ylabel('World Z')
  ax.set_title(f'A01.MSN: {res} × RSEG {road} ({"last" if idx<0 else "first"})')
  ax.legend(fontsize=8,loc='best');fig.tight_layout();fig.savefig(P/out,dpi=170);plt.close(fig)
  print(out,'mesh bbox',min(xs),max(xs),min(ys),max(ys),'terminal edges',aa,cc)
