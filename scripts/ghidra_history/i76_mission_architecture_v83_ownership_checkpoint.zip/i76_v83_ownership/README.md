# v83 object ownership research checkpoint

Ghidra 12.1.4 headless, `-readOnly -noanalysis`, named v81 program `i76.exe(1)` in `i76_mission_symbols_v81`; original retail MD5 `a640ea0097dbb62e0c77b7f2847c7161`. Start with `V83_OBJECT_OWNERSHIP_ARCHITECTURE.md`. This is analysis evidence, not new engine source or a Ghidra database edit.

Reproduce by placing both `.java` scripts into a Ghidra script folder, then invoking `support/analyzeHeadless PROJECT_DIR i76_mission_symbols_v81 -process 'i76.exe(1)' -readOnly -noanalysis -scriptPath SCRIPT_FOLDER -postScript i76_mission_v83_object_ownership_audit.java OUTPUT_FOLDER`, followed by the same call with `i76_mission_v83_ownership_boundary_followup.java` (both scripts require one output-dir argument).

Verification JSON checks explicit decompiled-code properties; its PASS does not imply gameplay validation. Names inherited from the v81 program are retained for lookup, including potentially misleading historic names. The original named project and GZF were not modified.
