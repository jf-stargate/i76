// @category I76
// v83 read-only targeted owner/observer boundary decompilation.
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.program.model.listing.*;
import java.io.*;
public class i76_mission_v83_ownership_boundary_followup extends GhidraScript {
 static final String[] ADDR={"00412830","0040A8A0","0040BA60","0040A740","004571A0","00457630","00465370","00461970","00461570","00461B80","00461C80","00461D50","004A0AE0","0049F5C0","004B7AC0","004B8F70","0045F250"};
 @Override public void run()throws Exception{
 if(!"a640ea0097dbb62e0c77b7f2847c7161".equalsIgnoreCase(currentProgram.getExecutableMD5()))throw new IllegalStateException("Wrong executable");
 File d=new File(getScriptArgs()[0]); d.mkdirs(); DecompInterface dc=new DecompInterface();dc.openProgram(currentProgram);
 try(PrintWriter out=new PrintWriter(new File(d,"v83_ownership_additional_native_decomp.txt"),"UTF-8")){
 for(String s:ADDR){Function f=currentProgram.getFunctionManager().getFunctionAt(toAddr(s));out.println("\n===== "+s+" "+(f==null?"UNDEFINED":f.getName())+" =====");
 if(f!=null){DecompileResults r=dc.decompileFunction(f,70,monitor);out.println(r.decompileCompleted()?r.getDecompiledFunction().getC():"FAILED "+r.getErrorMessage());}
 }}finally{dc.dispose();}println("V83_FOLLOWUP_OK");
 }
}
