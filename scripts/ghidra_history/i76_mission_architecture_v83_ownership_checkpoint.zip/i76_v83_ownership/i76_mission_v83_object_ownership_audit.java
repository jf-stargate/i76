// @category I76
// v83 read-only ownership and lifetime investigation against the v81 named retail image.
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.address.*;
import ghidra.program.model.symbol.*;
import java.io.*;
import java.util.*;

public class i76_mission_v83_object_ownership_audit extends GhidraScript {
 static final String[] PROBES={
 "0045EBD0","0045ED00","0045ED70","0045EE80","0045EF70","0045F0C0","0045F0F0","0045F260","0045F2D0",
 "00457270","00457290","004572B0","00457420","00409850","00409980","00409BD0","0040A010","0040A030",
 "00409740","00410720","004105A0","00412400","004125C0","0040AFF0","0040B0F0","0040B1F0",
 "004157A0","00415640","0040B9E0","004A0990","004149F0","00412500","004A0410","0045F410"};
 static final String[] REF_TARGETS={"0045ED00","0045ED70","0045EE80","0045EF70","0045F0C0","0045F0F0","004572B0","00457420","00409850","00409980","0040AFF0","0040B0F0","0040B1F0"};
 static final String[] GLOBALS={"0051F620","0051F624","0051F628","0051F62C","00507DA0","0051F5D0","00524550","0051F5B4"};
 String clean(String v){ return v==null?"":v.replace('\t',' ').replace('\n',' ').replace('\r',' '); }
 String caller(Address a){Function f=currentProgram.getFunctionManager().getFunctionContaining(a);return f==null?"NO_FUNCTION":f.getEntryPoint()+":"+f.getName();}
 @Override public void run() throws Exception {
  String md5=currentProgram.getExecutableMD5();
  if(!"a640ea0097dbb62e0c77b7f2847c7161".equalsIgnoreCase(md5))throw new IllegalStateException("MD5 " + md5);
  File dir=new File(getScriptArgs()[0]);dir.mkdirs();
  FunctionManager fm=currentProgram.getFunctionManager(); Listing li=currentProgram.getListing();
  try(PrintWriter w=new PrintWriter(new File(dir,"v83_function_targets.tsv"),"UTF-8")){
   w.println("address\tdefined\tcontaining_function\tname\tstart\tend\tbytes");
   for(String s:PROBES){Address a=toAddr(s);Function f=fm.getFunctionAt(a);Function con=fm.getFunctionContaining(a);
    w.println(s+"\t"+(f!=null)+"\t"+(con==null?"":con.getName())+"\t"+(f==null?"":f.getName())+"\t"+(f==null?"":f.getEntryPoint())+"\t"+(f==null?"":f.getBody().getMaxAddress())+"\t"+(f==null?0:f.getBody().getNumAddresses()));
   }
  }
  try(PrintWriter w=new PrintWriter(new File(dir,"v83_ownership_callers.tsv"),"UTF-8")){
   w.println("target\ttarget_name\treference_address\tcontaining_function\treference_type\toperand");
   for(String s:REF_TARGETS){Address a=toAddr(s);Function f=fm.getFunctionAt(a);
    for(Reference r: currentProgram.getReferenceManager().getReferencesTo(a)){
     Instruction i=li.getInstructionContaining(r.getFromAddress());w.println(s+"\t"+(f==null?"UNDEFINED":f.getName())+"\t"+r.getFromAddress()+"\t"+caller(r.getFromAddress())+"\t"+r.getReferenceType()+"\t"+clean(i==null?"":i.toString()));
    }
   }
  }
  try(PrintWriter w=new PrintWriter(new File(dir,"v83_runtime_global_refs.tsv"),"UTF-8")){
   w.println("global\tsymbol\treference_address\tcontaining_function\treference_type\tinstruction");
   for(String s:GLOBALS){Address a=toAddr(s);Symbol sym=currentProgram.getSymbolTable().getPrimarySymbol(a);
    for(Reference r:currentProgram.getReferenceManager().getReferencesTo(a)){
     Instruction i=li.getInstructionContaining(r.getFromAddress());
     w.println(s+"\t"+(sym==null?"":clean(sym.getName()))+"\t"+r.getFromAddress()+"\t"+caller(r.getFromAddress())+"\t"+r.getReferenceType()+"\t"+clean(i==null?"":i.toString()));
    }
   }
  }
  DecompInterface dc=new DecompInterface();dc.openProgram(currentProgram);
  try(PrintWriter w=new PrintWriter(new File(dir,"v83_object_ownership_native_decomp.txt"),"UTF-8")){
   for(String s:PROBES){Function f=fm.getFunctionAt(toAddr(s));w.println("\n===== "+s+" "+(f==null?"UNDEFINED":f.getName())+" =====");
    if(f!=null){DecompileResults r=dc.decompileFunction(f,75,monitor);w.println(r.decompileCompleted()?r.getDecompiledFunction().getC():"FAILED "+r.getErrorMessage());}
   }
  }finally {dc.dispose();}
  println("V83_OBJECT_OWNERSHIP_AUDIT_OK");
 }
}
