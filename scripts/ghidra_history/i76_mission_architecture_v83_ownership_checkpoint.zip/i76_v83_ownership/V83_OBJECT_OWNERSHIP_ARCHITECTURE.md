# Interstate '76 — v83 world-object and mission ownership audit

Date: 2026-10-20. Research-only. Program: retail `i76.exe` MD5 `a640ea0097dbb62e0c77b7f2847c7161`. Ghidra 12.1.4 headless, read-only against the v81 named working program. Evidence in this package is native Ghidra decompilation, reference listings and explicit machine-checkable assertions. No gameplay execution, memory tracing or replacement engine code was performed.

## Executive determination

I76 uses **an intrusive, tree-propagated reference count**, not independent modern shared_ptr-like per-object ownership. Its object system distinguishes (a) references keeping a world-object tree alive, (b) registries that hold those references, (c) non-owning pointers into other registries, and (d) cached/event pointers that do not themselves retain objects. It also distinguishes **logical removal** from actual memory reclamation: removed objects may remain allocated while other owners still retain references.

The engine's most misleading existing function name is `0045F0F0 release_world_object_tree_reference`. When `object+0x08 != 1`, this function **returns the object unchanged without decrementing its reference count**. When `object+0x08 == 1`, it **returns NULL**, decrementing a remaining hold or freeing the object/subtree on the last reference. In common callsites it is best modeled as **validate-live-object-and-retire-dead-reference**, not an unconditional `release`. This conclusion is direct from the branch and all return statements in `0045F0F0`; it corrects any earlier description of *every* call as a release.

## Physical world-object allocation and intrusive links

- `0045EBD0 allocate_world_object_node` allocates **0xB0 bytes** through `HeapAlloc(g_world_object_node_heap, HEAP_ZERO_MEMORY, 0xB0)`. It initializes `object+0x08` to 0 (live) and root `object+0x0C` to 1. A newly attached child inherits the parent's `+0x08` status and `+0x0C` count rather than taking an independent +1.
- `object+0x64` is **first child** and `object+0x60` is **next sibling**. `object+0x68` is an **intrusive predecessor/backlink**, *not invariably a parent pointer*. The allocator sets the new first child's +0x68 to the parent and rewrites the previous first child's +0x68 to the new first child; `0045F260` does the same. Treat it as `parent_or_previous_sibling` until helper semantics are fully typed.
- `0045ED00 increment_refcount_recursive_for_object_tree` increments the node's `+0x0C` count and descendants. Its recursion guard changes sibling traversal: a top-level call does not blindly increment all peer siblings. `0045F0C0` decrements descendants; `0045F2D0` propagates an explicit count delta when attaching subtrees.
- `0045ED70` (explicit unlink) and `0045EF70` (drop counted hold, possibly finalize) can set `+0x08=1` and free class/geometry/texture/light payloads followed by `HeapFree` at count zero. `0045EE80` applies decrements recursively to subtree nodes. `0045F0F0` also implements final reclamation, but **only on the `+0x08==1` branch**.

### Essential distinction for source reconstruction

Do **not** represent +0x68 as a fixed parent pointer, and do **not** treat `0045F0F0` as unconditional decrement. Both mistakes would distort source-level traversal and VM argument lifetime semantics.

## Ownership matrix (binary-proven effects versus inference)

| Holder / reference | Representative writer | How hold is acquired | How released / invalidated | Confidence |
|---|---|---|---|---|
| World-object root and descendants | `0045EBD0`, `0045F260` | Root initializes count=1; child inherits/propagates parent's count | `0045ED70`, `0045EF70`, `0045EE80`, `0045F0F0` | High for code; complete external root custody needs wider scan |
| Active-world registration slot | `004572B0` | Calls `0045ED00` before storing object in 0x78-byte slot | `00457420` invokes removal callbacks, then `0045EF70`, clears slot; bulk teardown `004571A0` also sends callbacks | High |
| Class callback queue | `00461970` | Calls `0045ED00` before enqueueing | `00461B80` drops its counted hold where queue callbacks are exhausted; class pre/post dispatch retire dead-object queue records | High for sampled paths; all branches not yet fully classified |
| FSM 8×64 team buckets | `00409850` | Stores pointer to **active-world entry**, no `0045ED00` in callback | `00409980` compacts team bucket before active slot is zeroed | High: non-owning registry view |
| Serialized/dynamic FSM actor `record+0x58` | `00412400` plus `0040AFF0`, `0040B0F0`, `0040B1F0`, `0040A8A0`, `0040BA60` | On successful binding, calls `0045ED00`; dynamic helpers reuse existing pointer when found | `00409980` drops via `0045EF70`, nulls pointer; actor count not decremented | High |
| AI state `AI+A9B4` target | `00412830` | Retargeting releases old target and increments new target | `00412830` retarget/null, `00409980` unregister; `0045F0F0` retires logically removed object | High |
| AI state `AI+A944` cached target | `00412830` | Writes pointer for comparison, no local addref on this field | Changed on retarget/state reset; no independent ownership demonstrated | Moderate: appears borrowed, audit other users/writers |
| AI state `AI+A990` weapon target | `00412CE0` opcode `0x30` | Stores pointer without paired local increment at setter | Lifetime ownership not established | Moderate/unknown |
| AI damage source fields `AI+A6E4/A6E8/A6EC` | `004157A0` | Stores source pointer **without incref** | AI construction initializes NULL; `00409980` does not explicitly clear these fields | High for producer/cleanup instructions; eventual deallocation safety unresolved |
| Pending FSM execution nodes | `00410490`/`00412500`, `004149F0` | Serialized/allocated under **FSM-specific heap**, linked at node+0x10B8 | Completed node `HeapFree(FSM heap)`; bulk `0040A030` destroys FSM heap | High for separate allocator model |

`004572B0` returns an **active registry entry** (array stride 0x78), not necessarily a raw world-object pointer. Its slot owns the counted object reference. The cached current-player global points to this entry, not directly to the world node. The FSM team buckets likewise point to registry **entries**, so `*bucket_entry` yields the world-object pointer. The callback ordering in `00457420` is `unregister callbacks → counted object release → slot zero`, allowing callbacks to inspect the still-retained object before the registry's final hold is dropped. `004571A0` has a corresponding bulk callback-first teardown path.

## FSM actor acquisition: v82 inventory was incomplete

The previous pass established three dynamic actor-append helpers. Ghidra's direct calls to `0045ED00` and native decompilation have now confirmed **at least five** mission-context helpers that append a `NoLabel_<count>` actor entry on a cache miss:

| Function | Source or selection | Counted actor binding |
|---|---|---|
| `0040AFF0` `fsm_query_who_rammed` | AI `+A6E4` | Yes |
| `0040B0F0` `fsm_query_who_shot` | AI `+A6E8` | Yes |
| `0040B1F0` `fsm_query_who_attacked` | AI `+A6EC` | Yes |
| `0040A8A0` `fsm_format_default_label_name` (misleading broad name) | Nearest qualifying actor from FSM team buckets | Yes on successful dynamic selection |
| `0040BA60` `fsm_find_nearest_enemy` | Nearest eligible effect-target world object | Yes on successful dynamic selection |

`0040A8A0` also has a **no-target** branch that writes a NULL binding at the next actor-record offset and returns that index **without incrementing actor count**. This branch is not an owning acquisition and merits separate index/bounds review.

The loader (`004105A0`) reserves `(serialized_actor_count + 200) × 0x60` bytes, yet these five append implementations do not locally test remaining capacity before incrementing count. Unregistration nulls bindings without decreasing count. Therefore dynamic append capacity is a shared **mission-level resource**, not three separate 200-entry pools. No actual overflow or exploit has been demonstrated; upstream controls, mission reachability and full actor-count writer coverage remain to be examined.

## AI ownership / event-lifetime crossover

`00412830` precisely balances its primary target `AI+A9B4`: if target differs from stored value, it drops the previous counted reference, acquires a new counted reference when non-NULL, and writes the new pointer. It then checks `0045F0F0` against the proposed target. On logical removal, that routine consumes the held reference and returns NULL, causing the AI to clear `A9B4` and brake. This is not a use-after-free by itself: the code retains the object before checking it, then relinquishes the hold when it finds a removed node.

In contrast, `004157A0` writes `A6E4/A6E8/A6EC` as **unretained source identities**. The consumption predicates only clear epoch fields `A6D4/A6D8/A6DC`. If a script later calls `who*`, it may acquire a counted mission actor reference from the stored source pointer; however, if the source was unregistered in the interim, whether the pointer remains valid depends on other owners. The existing unregister callback does not explicitly zero damage-source fields, but **a stale pointer that is actually dereferenced has not been observed**. Tracing future producer ordering and all remaining writers/cleanup paths is necessary before classifying this as a defect.

## Logical removal and ownership transitions

1. **Construct:** `0045EBD0` allocates a root or child node; root starts live with count 1, child inherits the tree count.
2. **Retain:** active entry registration, class callback queue, mission actor record, AI target, and various effects subsystems can each add counted holds via `0045ED00`, propagating into descendants.
3. **Reference lookup:** consumers often call `0045F0F0` to test a stored pointer. Live `+0x08!=1`: return unchanged. Removed `+0x08==1`: drop/count possibly free, and return NULL so caller can clear its cached slot.
4. **Unregister:** active registry dispatches callbacks first; FSM callback releases mission actors and AI-owned target references, and compacts its non-owning team bucket. Only then does registry release its own reference and clear its 0x78-byte slot.
5. **Destruct:** explicit unlink/drop helpers walk the intrusive subtree, mark removed nodes, decrement propagated counts, and free payloads and nodes at zero.
6. **Bulk cleanup:** `004571A0` iterates active-world slots and invokes the same removal callback list before slot retirement; `0040A030` separately calls `HeapDestroy` for the FSM allocations. Their precise ordering in every top-level shutdown route remains to be verified.

`00465370` demonstrates a mode-dependent vehicle cleanup: one branch performs `unregister_active_world_object_entry_and_release` and then `unlink_and_release_world_object_node_refcounted`; another branch marks status flags and performs visual/effect cleanup without that exact immediate unregister/unlink sequence. Thus **vehicle destruction is not synonymous with immediate world-object memory reclamation**.

## Remaining uncertainties and next reverse-engineering steps

**High priority:** classify all other holders of tree references, particularly radar/audio/ordnance, by pairing their addref and release sites; verify callback ordering in complete shutdown paths and event-pointer cleanup; enumerate all actor-record count changes and identify whether serialized/control-flow constraints guard the `+200` reserve.

**Specific data-structure task:** recover a typed WorldObject header (`+08` lifecycle state, `+0C` propagated count, `+60/+64/+68` intrusive links, `+6C` class, `+70` class runtime) and active entry (`0x78` stride, raw object at `+0`, data pointer at `+0x18` where applicable). Preserve `+0x68` as ambiguous/backlink, not universally `parent`. Distinguish the FSM heap allocation graph from object-tree reference ownership.

**Behavioral test specifications for later** (not executed): root/child count inheritance; registration/callback-before-release; repeated identical dynamic actor query does not double-retain; object removal while AI target and mission actor both hold it; dead-object lookup drops reference and nulls result; source pointer after unregistration; actor append at capacity boundaries; mixed-mode vehicle destruction paths. These are proposed tests, not an implementation.

## Source layout ledger (hypothesis only)

`0045EBD0–0045F307` is a strong **source-neighborhood candidate** for low-level world-object node/ownership manipulation: allocation, incref, release/unlink, subtree recursion, reference validation, and attach/refcount propagation appear consecutively. Do not conclude it was exactly one `.c/.cpp` file; compiler section layout and object-file boundaries are not recovered. `00457270–004574D3` forms a separate active-world registry/callback neighborhood. FSM runtime's ownership adaptors lie near `00409740–0040BB99`, while AI retargeting is at `00412830`. This layout supports modular boundaries, not recovered header names.

## Reproducibility

See `v83_object_ownership_native_decomp.txt` and `v83_ownership_additional_native_decomp.txt` for complete selected decompilations; `v83_ownership_callers.tsv` for every Ghidra indexed direct reference to 13 ownership/mission helper targets; `v83_runtime_global_refs.tsv` for selected global references; `v83_function_targets.tsv` for named definitions and bounds; two standalone `.java` scripts, read-only Ghidra headless logs, and `v83_static_validation.json`. The user-supplied GZF and v81 named baseline have not been modified. Claims about the absence of writes are scoped to verified functions, not all possible indirect or alias-based accesses.
